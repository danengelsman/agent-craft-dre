import { createContext, useContext, useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const PlanAccessContext = createContext(null);

export function PlanAccessProvider({ children, user }) {
  const [simulatedTier, setSimulatedTier] = useState(null);
  const [isSimulatingUserView, setIsSimulatingUserView] = useState(false);

  // Fetch user's subscription
  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const subs = await base44.entities.UserSubscription.filter({ user_email: user.email });
      return subs[0] || { tier: "free", status: "active" };
    },
    enabled: !!user?.email,
    staleTime: 60000,
  });

  // Fetch all plan configurations
  const { data: planConfigs = [] } = useQuery({
    queryKey: ['planConfigurations'],
    queryFn: () => base44.entities.PlanConfiguration.list(),
    staleTime: 300000, // Cache for 5 minutes
  });

  // Determine active tier (simulated or real)
  const activeTier = simulatedTier || subscription?.tier || "free";
  
  // Get plan configuration for active tier
  const planConfig = planConfigs.find(config => config.tier === activeTier) || {
    tier: "free",
    unlocked_abilities: ["basic_chat"],
    unlocked_features: [],
    max_agents: 3,
    max_messages_per_month: 100,
    support_level: "community",
    can_export_agents: true,
    can_sell_marketplace: false
  };

  // Determine if user has admin role (simulated or real)
  const isAdmin = user?.role === 'admin' && !isSimulatingUserView;

  const value = {
    // Current tier info
    tier: activeTier,
    subscription,
    planConfig,
    
    // Access checks
    hasAbility: (abilityId) => planConfig.unlocked_abilities?.includes(abilityId) || false,
    hasFeature: (featureId) => planConfig.unlocked_features?.includes(featureId) || false,
    canCreateAgent: (currentCount) => planConfig.max_agents === -1 || currentCount < planConfig.max_agents,
    
    // Admin simulation controls
    isAdmin,
    simulatedTier,
    setSimulatedTier,
    isSimulatingUserView,
    setIsSimulatingUserView,
    isSimulating: !!simulatedTier || isSimulatingUserView,
    
    // Quick access
    maxAgents: planConfig.max_agents,
    maxMessages: planConfig.max_messages_per_month,
    supportLevel: planConfig.support_level,
    canExport: planConfig.can_export_agents,
    canSellMarketplace: planConfig.can_sell_marketplace
  };

  return (
    <PlanAccessContext.Provider value={value}>
      {children}
    </PlanAccessContext.Provider>
  );
}

export function usePlanAccess() {
  const context = useContext(PlanAccessContext);
  if (!context) {
    throw new Error("usePlanAccess must be used within PlanAccessProvider");
  }
  return context;
}