import { usePlanAccess } from "./PlanAccessProvider";
import { Button } from "@/components/ui/button";
import { Shield, User, X, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AdminSimulationControls() {
  const { 
    isAdmin, 
    simulatedTier, 
    setSimulatedTier, 
    isSimulatingUserView, 
    setIsSimulatingUserView,
    tier 
  } = usePlanAccess();

  // Only show for actual admins
  if (!isAdmin && !simulatedTier && !isSimulatingUserView) {
    return null;
  }

  const handleTierChange = (newTier) => {
    if (newTier === tier && !simulatedTier) {
      setSimulatedTier(null);
    } else {
      setSimulatedTier(newTier);
    }
  };

  const handleResetSimulation = () => {
    setSimulatedTier(null);
    setIsSimulatingUserView(false);
  };

  return (
    <>
      {/* Simulation Banner */}
      <AnimatePresence>
        {(simulatedTier || isSimulatingUserView) && (
          <motion.div
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="fixed top-0 left-0 right-0 z-[60] bg-gradient-to-r from-amber-500 to-orange-600 text-white py-3 px-6 shadow-lg"
          >
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5" />
                <div className="text-sm font-semibold">
                  {isSimulatingUserView && "Simulating Normal User View"}
                  {simulatedTier && !isSimulatingUserView && `Viewing as ${simulatedTier.toUpperCase()} Tier User`}
                  {simulatedTier && isSimulatingUserView && ` • ${simulatedTier.toUpperCase()} Tier`}
                </div>
              </div>
              <button
                onClick={handleResetSimulation}
                className="flex items-center gap-2 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors text-sm font-medium"
              >
                <X className="w-4 h-4" />
                Exit Simulation
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Admin Control Panel - Only for real admins */}
      {isAdmin && !isSimulatingUserView && (
        <div className="mb-6 p-6 rounded-2xl border-2 border-purple-200 bg-purple-50">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-purple-600" />
            <h3 className="font-bold text-purple-900">Admin Testing Controls</h3>
          </div>
          
          {/* Tier Simulation */}
          <div className="mb-4">
            <label className="text-sm font-semibold text-purple-900 mb-2 block">
              Simulate User Tier:
            </label>
            <div className="flex gap-2">
              {["free", "pro", "business"].map((tierOption) => (
                <Button
                  key={tierOption}
                  onClick={() => handleTierChange(tierOption)}
                  variant={simulatedTier === tierOption ? "default" : "outline"}
                  size="sm"
                  className={simulatedTier === tierOption ? "bg-purple-600 text-white" : ""}
                >
                  {tierOption.charAt(0).toUpperCase() + tierOption.slice(1)}
                </Button>
              ))}
              {simulatedTier && (
                <Button
                  onClick={() => setSimulatedTier(null)}
                  variant="outline"
                  size="sm"
                  className="text-gray-600"
                >
                  Reset
                </Button>
              )}
            </div>
          </div>

          {/* User View Simulation */}
          <div>
            <label className="text-sm font-semibold text-purple-900 mb-2 block">
              Admin View:
            </label>
            <Button
              onClick={() => setIsSimulatingUserView(true)}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <User className="w-4 h-4" />
              View as Normal User
            </Button>
          </div>
        </div>
      )}

      {/* Return to Admin View - Only when simulating */}
      {isSimulatingUserView && (
        <div className="mb-6 p-6 rounded-2xl border-2 border-amber-200 bg-amber-50">
          <Button
            onClick={() => setIsSimulatingUserView(false)}
            className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700"
          >
            <Shield className="w-4 h-4" />
            Return to Admin View
          </Button>
        </div>
      )}
    </>
  );
}