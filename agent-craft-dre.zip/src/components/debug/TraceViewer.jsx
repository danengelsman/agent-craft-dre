import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ChevronDown, ChevronRight, CheckCircle, XCircle, Clock, 
  Zap, Bot, GitBranch, Code, Copy, ExternalLink
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const STEP_ICONS = {
  llm_call: Bot,
  action: Zap,
  workflow: GitBranch,
  condition: Code,
  default: Zap
};

const STATUS_COLORS = {
  completed: "text-green-600 bg-green-50",
  running: "text-blue-600 bg-blue-50",
  failed: "text-red-600 bg-red-50"
};

export default function TraceViewer({ trace, onClose }) {
  const [expandedSteps, setExpandedSteps] = useState({});

  if (!trace) return null;

  const toggleStep = (stepId) => {
    setExpandedSteps(prev => ({
      ...prev,
      [stepId]: !prev[stepId]
    }));
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(typeof text === 'string' ? text : JSON.stringify(text, null, 2));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        className="bg-white rounded-2xl max-w-4xl w-full max-h-[85vh] overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b bg-gray-50">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-xl font-bold">Trace Details</h2>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_COLORS[trace.status]}`}>
                  {trace.status}
                </span>
              </div>
              <p className="text-sm text-gray-500 font-mono">{trace.trace_id || trace.id}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>✕</Button>
          </div>

          {/* Summary Stats */}
          <div className="flex items-center gap-6 mt-4 text-sm">
            <div className="flex items-center gap-1">
              <Bot className="w-4 h-4 text-purple-500" />
              <span>{trace.agent_name}</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4 text-gray-500" />
              <span>{trace.duration_ms || 0}ms</span>
            </div>
            <div className="flex items-center gap-1">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>{trace.total_tokens || 0} tokens</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-green-600 font-medium">
                ${((trace.total_cost_cents || 0) / 100).toFixed(4)}
              </span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Input/Output */}
          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Input</span>
                <button onClick={() => copyToClipboard(trace.user_input)} className="text-gray-400 hover:text-gray-600">
                  <Copy className="w-3 h-3" />
                </button>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg text-sm">
                {trace.user_input}
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Output</span>
                <button onClick={() => copyToClipboard(trace.final_output)} className="text-gray-400 hover:text-gray-600">
                  <Copy className="w-3 h-3" />
                </button>
              </div>
              <div className="p-3 bg-green-50 rounded-lg text-sm max-h-32 overflow-y-auto">
                {trace.final_output || "—"}
              </div>
            </div>
          </div>

          {/* Error */}
          {trace.error_message && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 text-red-700 font-medium mb-1">
                <XCircle className="w-4 h-4" />
                Error
              </div>
              <p className="text-sm text-red-600">{trace.error_message}</p>
            </div>
          )}

          {/* Steps Timeline */}
          <div>
            <h3 className="font-semibold mb-4">Execution Steps ({trace.steps?.length || 0})</h3>
            <div className="space-y-2">
              {trace.steps?.map((step, index) => {
                const Icon = STEP_ICONS[step.step_type] || STEP_ICONS.default;
                const isExpanded = expandedSteps[step.step_id];
                const isSuccess = step.status === 'completed' || step.status === 'success';

                return (
                  <div key={step.step_id || index} className="border rounded-lg overflow-hidden">
                    <button
                      onClick={() => toggleStep(step.step_id || index)}
                      className="w-full flex items-center gap-3 p-3 hover:bg-gray-50 text-left"
                    >
                      {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        isSuccess ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        <Icon className={`w-3 h-3 ${isSuccess ? 'text-green-600' : 'text-red-600'}`} />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{step.step_name || step.step_type}</div>
                        <div className="text-xs text-gray-500">
                          {step.duration_ms}ms • {step.tokens_used || 0} tokens
                        </div>
                      </div>
                      {isSuccess ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-500" />
                      )}
                    </button>

                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0 }}
                          animate={{ height: "auto" }}
                          exit={{ height: 0 }}
                          className="overflow-hidden"
                        >
                          <div className="p-4 bg-gray-50 border-t space-y-3">
                            {step.input && (
                              <div>
                                <div className="text-xs font-medium text-gray-500 mb-1">Input</div>
                                <pre className="text-xs bg-white p-2 rounded border overflow-x-auto max-h-32">
                                  {JSON.stringify(step.input, null, 2)}
                                </pre>
                              </div>
                            )}
                            {step.output && (
                              <div>
                                <div className="text-xs font-medium text-gray-500 mb-1">Output</div>
                                <pre className="text-xs bg-white p-2 rounded border overflow-x-auto max-h-32">
                                  {typeof step.output === 'string' ? step.output : JSON.stringify(step.output, null, 2)}
                                </pre>
                              </div>
                            )}
                            {step.error && (
                              <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                                {step.error}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}

              {(!trace.steps || trace.steps.length === 0) && (
                <div className="text-center py-8 text-gray-500">
                  No execution steps recorded
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t bg-gray-50 flex items-center justify-between">
          <div className="text-xs text-gray-500">
            {trace.created_date && new Date(trace.created_date).toLocaleString()}
          </div>
          <Button variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}