
import { MessageSquare, Brain, Search, FileText, Zap, Users } from "lucide-react";

export const FEATURE_ICONS = [
  {
    id: "chat",
    icon: MessageSquare,
    label: "Smart Conversations",
    description: "Natural AI dialogue"
  },
  {
    id: "memory",
    icon: Brain,
    label: "Remembers Context",
    description: "Learns as you chat"
  },
  {
    id: "search",
    icon: Search,
    label: "Web Search",
    description: "Real-time info"
  },
  {
    id: "files",
    icon: FileText,
    label: "File Handling",
    description: "Works with docs"
  },
  {
    id: "automation",
    icon: Zap,
    label: "Task Automation",
    description: "Saves you time"
  },
  {
    id: "collaboration",
    icon: Users,
    label: "Team Ready",
    description: "Share agents"
  }
];
