import { Card, CardContent } from "@/components/ui/Card";
import { FEATURE_ICONS } from "./FeatureIcons";

export default function FeatureIconGrid() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {FEATURE_ICONS.map((feature) => {
        const Icon = feature.icon;
        return (
          <Card key={feature.id} className="text-center">
            <CardContent className="p-6">
              <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-gray-100 flex items-center justify-center">
                <Icon className="w-6 h-6 text-gray-900" />
              </div>
              <h3 className="font-semibold text-sm mb-1">{feature.label}</h3>
              <p className="text-xs ui-muted">{feature.description}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}