import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star, X } from "lucide-react";
import { motion } from "framer-motion";

export default function ReviewSubmission({ agent, user, onClose, hasPurchased }) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const queryClient = useQueryClient();

  const submitReviewMutation = useMutation({
    mutationFn: async () => {
      // Create the review initially
      const review = await base44.entities.AgentReview.create({
        agent_id: agent.id,
        rating: rating,
        review_text: reviewText, // Using reviewText directly as per outline
        reviewer_name: user.full_name || "Anonymous",
        is_verified_purchase: hasPurchased
      });

      let submissionOutcomeStatus = "approved"; // Default status for the review submission outcome
      let moderationCheckResult = null; // To store moderation analysis if performed

      // Run content moderation check on review text if present and sufficient length (e.g., > 10 chars)
      if (reviewText && reviewText.length > 10) {
        moderationCheckResult = await base44.integrations.Core.InvokeLLM({
          prompt: `You are a content moderation AI. Analyze this product review for any inappropriate or harmful content.

Review Text: ${reviewText}
Rating: ${rating} stars

Score this content from 0-100 where:
- 0-30: Safe, appropriate review
- 31-70: Potentially problematic, needs human review
- 71-100: Clearly inappropriate, should be blocked

Consider:
1. Inappropriate language or harassment
2. Spam or fake reviews
3. Off-topic or irrelevant content
4. Personal attacks
5. Misleading information

Return ONLY a JSON object with your analysis.`,
          response_json_schema: {
            type: "object",
            properties: {
              score: { type: "number" },
              reasons: {
                type: "array",
                items: { type: "string" }
              }
            }
          }
        });

        // Determine the submission outcome status based on moderation score
        if (moderationCheckResult.score > 70) {
          submissionOutcomeStatus = "blocked";
          // If blocked, delete the review immediately from AgentReview entity
          await base44.entities.AgentReview.delete(review.id);
        } else if (moderationCheckResult.score > 30) {
          submissionOutcomeStatus = "pending_review";
          // If pending, the review remains in the DB but won't trigger public agent average update yet.
        }
        // If score <= 30, submissionOutcomeStatus remains "approved"

        // Create a ContentModeration record for this submission
        await base44.entities.ContentModeration.create({
          content_type: "review",
          content_id: review.id, // Reference the originally created review ID
          content_preview: `${rating} stars: ${reviewText.substring(0, 100)}`, // Using reviewText directly
          moderation_score: moderationCheckResult.score,
          status: submissionOutcomeStatus, // Status of this particular moderation event
          auto_decision: true,
          moderation_reasons: moderationCheckResult.reasons || [],
          author_email: user.email || "unknown@example.com" // Ensure user.email is available or provide fallback
        });

        // Return early based on moderation outcome to prevent agent stats update
        if (submissionOutcomeStatus === "blocked") {
          return { review: null, status: "blocked" }; // Review object is null if blocked
        } else if (submissionOutcomeStatus === "pending_review") {
          return { review: review, status: "pending_review" };
        }
      }

      // Update agent's average rating and review count ONLY if the review is approved
      // This section is reached only if `submissionOutcomeStatus` is "approved" (either passed moderation or no moderation was triggered).
      const allReviews = await base44.entities.AgentReview.filter({ agent_id: agent.id });

      // Calculate average rating from all reviews currently in the database for this agent.
      // Note: Reviews marked 'pending_review' but not deleted will be included in this calculation.
      // If 'pending_review' reviews should not contribute to the public average, `allReviews` would need further filtering (e.g., by a moderation_status field on AgentReview).
      const totalRating = allReviews.reduce((sum, r) => sum + r.rating, 0);
      const reviewCount = allReviews.length;
      const avgRating = reviewCount > 0 ? totalRating / reviewCount : 0;

      await base44.entities.Agent.update(agent.id, {
        average_rating: avgRating,
        review_count: reviewCount
      });

      return { review: review, status: "approved" }; // Explicitly return approved status here
    },
    onSuccess: (data) => {
      // Invalidate relevant queries to refetch data after review submission
      queryClient.invalidateQueries({ queryKey: ['publicAgents'] });
      queryClient.invalidateQueries({ queryKey: ['allReviews'] }); // Invalidate all reviews

      // Display appropriate alerts based on the submission outcome status
      if (data.status === "blocked") {
        alert("⚠️ Your review was blocked due to policy violations. Please keep reviews respectful and on-topic.");
      } else if (data.status === "pending_review") {
        alert("⏳ Your review is under review. It will be visible once approved.");
      } else { // data.status === "approved"
        alert("Review submitted successfully! 🎉");
      }

      onClose(); // Close the submission modal
    },
  });

  const handleSubmit = () => {
    if (rating === 0) {
      alert("Please select a rating");
      return;
    }
    submitReviewMutation.mutate();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="premium-card max-w-md w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">Write a Review</h2>
            <p className="text-sm text-gray-600">{agent.name}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Star Rating */}
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-900 mb-3">
            Your Rating
          </label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                onClick={() => setRating(star)}
                className="transition-transform hover:scale-125"
              >
                <Star
                  className={`w-10 h-10 ${
                    star <= (hoverRating || rating)
                      ? 'fill-amber-500 text-amber-500'
                      : 'text-gray-300'
                  }`}
                />
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-600 mt-2">
            {rating === 0 ? 'Click to rate' :
             rating === 1 ? 'Poor' :
             rating === 2 ? 'Fair' :
             rating === 3 ? 'Good' :
             rating === 4 ? 'Very Good' :
             'Excellent'}
          </p>
        </div>

        {/* Review Text */}
        <div className="mb-6">
          <label className="block text-sm font-semibold text-gray-900 mb-2">
            Your Review (Optional)
          </label>
          <Textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Share your experience with this agent..."
            rows={4}
          />
        </div>

        {hasPurchased && (
          <div className="mb-4 p-3 rounded-lg bg-green-50 border border-green-200">
            <p className="text-sm text-green-800 flex items-center gap-2">
              <Star className="w-4 h-4 fill-green-700" />
              Verified Purchase
            </p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={rating === 0 || submitReviewMutation.isLoading}
            className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
          >
            {submitReviewMutation.isLoading ? 'Submitting...' : 'Submit Review'}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}