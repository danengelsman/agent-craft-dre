import { format } from "date-fns";
import { CheckCircle2, XCircle, Loader2, Clock, Zap } from "lucide-react";

const STATUS_CONFIG = {
  queued: { icon: Clock, color: 'text-gray-600', bg: 'bg-gray-100', label: 'Queued' },
  initializing: { icon: Loader2, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Initializing', spin: true },
  training: { icon: Zap, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Training', pulse: true },
  validating: { icon: Loader2, color: 'text-purple-600', bg: 'bg-purple-50', label: 'Validating', spin: true },
  completed: { icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50', label: 'Completed' },
  failed: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', label: 'Failed' },
  cancelled: { icon: XCircle, color: 'text-gray-600', bg: 'bg-gray-100', label: 'Cancelled' }
};

export default function TrainingJobCard({ job, agents, datasets }) {
  const statusConfig = STATUS_CONFIG[job.status];
  const StatusIcon = statusConfig.icon;
  
  const agent = agents.find(a => a.id === job.agent_id);
  const dataset = datasets.find(d => d.id === job.dataset_id);

  return (
    <div className={`p-6 rounded-2xl ${statusConfig.bg}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-lg font-semibold text-gray-900">{job.job_name}</h3>
            <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${statusConfig.bg} ${statusConfig.color}`}>
              <StatusIcon className={`w-3 h-3 ${statusConfig.spin ? 'animate-spin' : ''}`} />
              {statusConfig.label}
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>Agent: {agent?.name || 'Unknown'}</span>
            <span>•</span>
            <span>Dataset: {dataset?.name || 'Unknown'}</span>
            <span>•</span>
            <span className="capitalize">{job.strategy.replace('_', ' ')}</span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      {['training', 'validating'].includes(job.status) && (
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
            <span>Epoch {job.current_epoch} of {job.total_epochs}</span>
            <span>{job.progress_percentage}%</span>
          </div>
          <div className="h-2 bg-white rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 transition-all duration-500"
              style={{ width: `${job.progress_percentage}%` }}
            />
          </div>
        </div>
      )}

      {/* Metrics */}
      {job.loss !== undefined && (
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="p-3 bg-white rounded-xl">
            <div className="text-xs text-gray-600 mb-1">Loss</div>
            <div className="text-lg font-semibold text-gray-900">
              {job.loss.toFixed(4)}
            </div>
          </div>
          {job.validation_accuracy !== undefined && (
            <div className="p-3 bg-white rounded-xl">
              <div className="text-xs text-gray-600 mb-1">Accuracy</div>
              <div className="text-lg font-semibold text-gray-900">
                {(job.validation_accuracy * 100).toFixed(1)}%
              </div>
            </div>
          )}
          {job.estimated_completion && (
            <div className="p-3 bg-white rounded-xl">
              <div className="text-xs text-gray-600 mb-1">Est. completion</div>
              <div className="text-sm font-medium text-gray-900">
                {format(new Date(job.estimated_completion), 'h:mm a')}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Timestamps */}
      <div className="flex items-center gap-4 text-xs text-gray-500">
        {job.started_at && (
          <span>Started {format(new Date(job.started_at), 'MMM d, h:mm a')}</span>
        )}
        {job.completed_at && (
          <>
            <span>•</span>
            <span>Completed {format(new Date(job.completed_at), 'MMM d, h:mm a')}</span>
          </>
        )}
      </div>

      {/* Error Message */}
      {job.error_message && (
        <div className="mt-4 p-3 bg-red-100 rounded-xl text-sm text-red-800">
          {job.error_message}
        </div>
      )}
    </div>
  );
}