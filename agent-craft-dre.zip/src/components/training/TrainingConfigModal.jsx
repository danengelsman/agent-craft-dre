import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Loader2, Zap } from "lucide-react";

export default function TrainingConfigModal({ dataset, agents, onClose }) {
  const [jobName, setJobName] = useState(`${dataset.name} - Training`);
  const [selectedAgent, setSelectedAgent] = useState(agents[0]?.id || "");
  const [strategy, setStrategy] = useState("lora");
  const [parameters, setParameters] = useState({
    learning_rate: 0.0001,
    epochs: 3,
    batch_size: 4,
    temperature: 0.7
  });
  const queryClient = useQueryClient();

  const startTrainingMutation = useMutation({
    mutationFn: async (data) => {
      const job = await base44.entities.TrainingJob.create(data);
      
      // Simulate training progress
      const totalEpochs = data.parameters.epochs;
      const simulateProgress = async () => {
        for (let epoch = 1; epoch <= totalEpochs; epoch++) {
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          const progress = (epoch / totalEpochs) * 100;
          const loss = 2.5 - (epoch * 0.5) + (Math.random() * 0.2);
          const accuracy = 0.5 + (epoch / totalEpochs) * 0.4 + (Math.random() * 0.05);
          
          await base44.entities.TrainingJob.update(job.id, {
            status: epoch < totalEpochs ? 'training' : 'validating',
            current_epoch: epoch,
            progress_percentage: Math.floor(progress),
            loss: loss,
            validation_accuracy: accuracy
          });
        }
        
        await base44.entities.TrainingJob.update(job.id, {
          status: 'completed',
          progress_percentage: 100,
          completed_at: new Date().toISOString(),
          model_checkpoint_url: `checkpoint_${job.id}`
        });
      };
      
      setTimeout(() => simulateProgress(), 1000);
      
      return job;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training_jobs'] });
      onClose();
    }
  });

  const handleSubmit = () => {
    if (!selectedAgent) return;

    startTrainingMutation.mutate({
      agent_id: selectedAgent,
      dataset_id: dataset.id,
      job_name: jobName,
      strategy: strategy,
      parameters: parameters,
      total_epochs: parameters.epochs,
      status: "initializing",
      started_at: new Date().toISOString(),
      estimated_completion: new Date(Date.now() + parameters.epochs * 5 * 60 * 1000).toISOString()
    });
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-semibold text-gray-900">Configure training</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Job name
              </Label>
              <Input
                value={jobName}
                onChange={(e) => setJobName(e.target.value)}
                className="h-11"
              />
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Select agent
              </Label>
              <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {agents.map((agent) => (
                    <SelectItem key={agent.id} value={agent.id}>
                      {agent.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Fine-tuning strategy
              </Label>
              <Select value={strategy} onValueChange={setStrategy}>
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lora">LoRA (Recommended)</SelectItem>
                  <SelectItem value="full_finetune">Full Fine-tune</SelectItem>
                  <SelectItem value="prompt_tuning">Prompt Tuning</SelectItem>
                  <SelectItem value="few_shot">Few-Shot</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="p-6 bg-gray-50 rounded-2xl space-y-4">
              <h4 className="font-semibold text-gray-900 mb-4">Training parameters</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-gray-700 mb-2 block">Learning rate</Label>
                  <Input
                    type="number"
                    step="0.00001"
                    value={parameters.learning_rate}
                    onChange={(e) => setParameters({...parameters, learning_rate: parseFloat(e.target.value)})}
                    className="h-10"
                  />
                </div>
                <div>
                  <Label className="text-sm text-gray-700 mb-2 block">Epochs</Label>
                  <Input
                    type="number"
                    min="1"
                    max="10"
                    value={parameters.epochs}
                    onChange={(e) => setParameters({...parameters, epochs: parseInt(e.target.value)})}
                    className="h-10"
                  />
                </div>
                <div>
                  <Label className="text-sm text-gray-700 mb-2 block">Batch size</Label>
                  <Input
                    type="number"
                    min="1"
                    max="16"
                    value={parameters.batch_size}
                    onChange={(e) => setParameters({...parameters, batch_size: parseInt(e.target.value)})}
                    className="h-10"
                  />
                </div>
                <div>
                  <Label className="text-sm text-gray-700 mb-2 block">Temperature</Label>
                  <Input
                    type="number"
                    step="0.1"
                    min="0"
                    max="2"
                    value={parameters.temperature}
                    onChange={(e) => setParameters({...parameters, temperature: parseFloat(e.target.value)})}
                    className="h-10"
                  />
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 rounded-xl">
              <p className="text-sm text-blue-900">
                <strong>Estimated duration:</strong> {parameters.epochs * 5} minutes
              </p>
            </div>
          </div>

          <div className="flex gap-3 mt-8">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 h-12"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!selectedAgent || startTrainingMutation.isPending}
              className="flex-1 h-12 bg-black hover:bg-gray-800 text-white"
            >
              {startTrainingMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Starting...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Start training
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}