import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Upload, Loader2, FileText, CheckCircle2 } from "lucide-react";

export default function DatasetUploader({ onClose }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [datasetType, setDatasetType] = useState("documents");
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const queryClient = useQueryClient();

  const createDatasetMutation = useMutation({
    mutationFn: async (data) => {
      const dataset = await base44.entities.TrainingDataset.create(data);
      
      // Simulate processing with LLM
      const analysisPrompt = `Analyze this training dataset and provide statistics.
Dataset Type: ${data.dataset_type}
Number of Files: ${data.file_urls.length}

Generate realistic statistics for:
- Total training examples (records)
- Approximate token count
- Data quality assessment

Return ONLY a JSON object.`;

      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            total_records: { type: "number" },
            total_tokens: { type: "number" },
            quality_score: { type: "number" }
          }
        }
      });

      await base44.entities.TrainingDataset.update(dataset.id, {
        status: "ready",
        total_records: analysis.total_records,
        total_tokens: analysis.total_tokens,
        metadata: { quality_score: analysis.quality_score }
      });

      return dataset;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training_datasets'] });
      onClose();
    }
  });

  const handleFileSelect = async (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
    setUploading(true);

    const urls = [];
    for (const file of selectedFiles) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }

    setUploadedFiles(urls);
    setUploading(false);
  };

  const handleSubmit = () => {
    if (!name || uploadedFiles.length === 0) return;

    createDatasetMutation.mutate({
      name,
      description: description || `Training dataset: ${name}`,
      dataset_type: datasetType,
      file_urls: uploadedFiles,
      status: "processing"
    });
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-semibold text-gray-900">Upload training data</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Dataset name
              </Label>
              <Input
                placeholder="Customer support FAQs"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-11"
              />
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Description
              </Label>
              <Textarea
                placeholder="What does this dataset contain?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="h-20"
              />
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Dataset type
              </Label>
              <Select value={datasetType} onValueChange={setDatasetType}>
                <SelectTrigger className="h-11">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="documents">Documents (PDFs, text files)</SelectItem>
                  <SelectItem value="faqs">FAQs (Q&A pairs)</SelectItem>
                  <SelectItem value="conversations">Conversation logs</SelectItem>
                  <SelectItem value="mixed">Mixed content</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">
                Upload files
              </Label>
              <label className="block">
                <input
                  type="file"
                  multiple
                  accept=".txt,.pdf,.json,.csv,.docx"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <div className="border-2 border-dashed border-gray-300 rounded-2xl p-12 text-center hover:border-gray-400 transition-colors cursor-pointer">
                  {uploading ? (
                    <Loader2 className="w-8 h-8 animate-spin text-gray-400 mx-auto mb-4" />
                  ) : uploadedFiles.length > 0 ? (
                    <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-4" />
                  ) : (
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-4" />
                  )}
                  <p className="text-base text-gray-600 mb-1">
                    {uploading
                      ? 'Uploading...'
                      : uploadedFiles.length > 0
                      ? `${uploadedFiles.length} files uploaded`
                      : 'Click to upload files'}
                  </p>
                  <p className="text-sm text-gray-500">
                    PDF, TXT, JSON, CSV, DOCX
                  </p>
                </div>
              </label>

              {files.length > 0 && (
                <div className="mt-4 space-y-2">
                  {files.map((file, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl"
                    >
                      <FileText className="w-5 h-5 text-gray-600" />
                      <span className="text-sm text-gray-900 flex-1">{file.name}</span>
                      {uploadedFiles[idx] && (
                        <CheckCircle2 className="w-4 h-4 text-green-600" />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-3 mt-8">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 h-12"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!name || uploadedFiles.length === 0 || createDatasetMutation.isPending}
              className="flex-1 h-12 bg-black hover:bg-gray-800 text-white"
            >
              {createDatasetMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create dataset'
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}