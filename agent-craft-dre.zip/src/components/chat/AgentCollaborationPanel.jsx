import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/badge";
import { Loader2, ArrowRight, CheckCircle2, AlertCircle, Users } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AgentCollaborationPanel({ 
  activeCollaborations = [], 
  onDismiss 
}) {
  if (activeCollaborations.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="mb-4"
      >
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                <CardTitle className="text-base">Agent Collaboration Active</CardTitle>
              </div>
              {onDismiss && (
                <Button variant="ghost" size="sm" onClick={onDismiss}>
                  Dismiss
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {activeCollaborations.map((collab, idx) => (
              <div key={idx} className="flex items-center gap-3 p-3 bg-white rounded-lg border">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-sm">{collab.from_agent}</span>
                    <ArrowRight className="w-4 h-4 text-gray-400" />
                    <span className="font-medium text-sm">{collab.to_agent}</span>
                  </div>
                  <p className="text-xs text-gray-600">{collab.content}</p>
                </div>
                <div>
                  {collab.status === "processing" && (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  )}
                  {collab.status === "completed" && (
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  )}
                  {collab.status === "failed" && (
                    <AlertCircle className="w-4 h-4 text-red-600" />
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}