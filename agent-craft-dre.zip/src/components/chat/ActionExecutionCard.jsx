import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, CheckCircle, XCircle, Loader2, ChevronDown, ChevronUp, Mail, Globe, MessageSquare, Calendar, Database, Code, Clock } from "lucide-react";
import { motion } from "framer-motion";

const ACTION_TYPE_ICONS = {
  send_email: Mail,
  http_request: Globe,
  slack_message: MessageSquare,
  calendar_event: Calendar,
  database_query: Database,
  custom_function: Code
};

const ACTION_TYPE_LABELS = {
  send_email: 'Email Sent',
  http_request: 'API Call',
  slack_message: 'Slack Message',
  calendar_event: 'Calendar Event',
  database_query: 'Database Query',
  custom_function: 'Function Call'
};

export default function ActionExecutionCard({ execution, isExecuting, actionType }) {
  const [expanded, setExpanded] = useState(false);

  if (isExecuting) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200"
      >
        <Loader2 className="w-4 h-4 animate-spin text-amber-600" />
        <span className="text-sm text-amber-700">Executing action...</span>
      </motion.div>
    );
  }

  if (!execution) return null;

  const isSuccess = execution.status === 'success';
  const ActionIcon = ACTION_TYPE_ICONS[actionType] || Zap;
  const actionLabel = ACTION_TYPE_LABELS[actionType] || 'Action';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className={`overflow-hidden ${isSuccess ? 'border-green-200' : 'border-red-200'}`}>
        <button
          onClick={() => setExpanded(!expanded)}
          className={`w-full px-4 py-3 flex items-center justify-between transition-colors hover:bg-opacity-70 cursor-pointer ${
            isSuccess ? 'bg-green-50' : 'bg-red-50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isSuccess ? 'bg-green-100' : 'bg-red-100'
            }`}>
              <ActionIcon className={`w-4 h-4 ${isSuccess ? 'text-green-600' : 'text-red-600'}`} />
            </div>
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-2">
                <span className={`text-sm font-semibold ${isSuccess ? 'text-green-700' : 'text-red-700'}`}>
                  {execution.action_name || actionLabel}
                </span>
                {isSuccess ? (
                  <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                ) : (
                  <XCircle className="w-3.5 h-3.5 text-red-600" />
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Clock className="w-3 h-3" />
                <span>{execution.execution_time_ms}ms</span>
              </div>
            </div>
          </div>
          {expanded ? (
            <ChevronUp className="w-4 h-4 text-gray-400 transition-transform" />
          ) : (
            <ChevronDown className="w-4 h-4 text-gray-400 transition-transform" />
          )}
        </button>

        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t bg-white"
          >
            <div className="p-4 text-xs space-y-3">
              {execution.output_data && (
                <div>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                    <span className="font-semibold text-gray-700">Result</span>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 overflow-auto max-h-32">
                    <pre className="text-gray-700 whitespace-pre-wrap font-mono text-xs">
                      {typeof execution.output_data === 'string' 
                        ? execution.output_data 
                        : JSON.stringify(execution.output_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
              {execution.input_data && Object.keys(execution.input_data).length > 0 && (
                <div>
                  <span className="font-semibold text-gray-600 text-xs">Input Parameters</span>
                  <div className="mt-1.5 p-2.5 bg-gray-50 rounded-lg border border-gray-200 overflow-auto max-h-24">
                    <pre className="text-gray-600 whitespace-pre-wrap font-mono text-xs">
                      {JSON.stringify(execution.input_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}
              {execution.error_message && (
                <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                  <div className="flex items-start gap-2">
                    <XCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-red-700 block mb-1">Error</span>
                      <span className="text-red-600">{execution.error_message}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </Card>
    </motion.div>
  );
}