import * as React from "react";
import { useLocation } from "react-router-dom";
import { useAuth } from "./auth/useAuth";

// Simple in-memory history (survives until refresh)
const NAV_HISTORY = [];

function now() {
  return Date.now();
}

function formatEvent(e) {
  const t = new Date(e.ts).toLocaleTimeString();
  const full = `${e.path}${e.search}${e.hash}`;
  return `${t}  ${full}`;
}

function pushEvent(e, max = 25) {
  NAV_HISTORY.push(e);
  if (NAV_HISTORY.length > max) NAV_HISTORY.shift();
}

function detectLoop(windowMs, samePathThreshold) {
  const cutoff = now() - windowMs;
  const recent = NAV_HISTORY.filter((e) => e.ts >= cutoff);
  if (recent.length < samePathThreshold) return null;

  const lastPath = recent[recent.length - 1]?.path;
  if (!lastPath) return null;

  const count = recent.filter((e) => e.path === lastPath).length;
  if (count >= samePathThreshold) {
    return { lastPath, recent };
  }
  return null;
}

export function NavGuard({
  children,
  enabled = true,
  loopWindowMs = 4000,
  loopThreshold = 4,
}) {
  const location = useLocation();
  const [loop, setLoop] = React.useState(null);
  const { isAuthenticated, user } = useAuth();

  React.useEffect(() => {
    if (!enabled || loop) return;

    const e = {
      ts: now(),
      path: location.pathname,
      search: location.search,
      hash: location.hash,
    };

    pushEvent(e);

    // Console logging (useful in Base44 preview + browser devtools)
    // eslint-disable-next-line no-console
    console.log("[NAV]", formatEvent(e));

    const found = detectLoop(loopWindowMs, loopThreshold);
    if (found) setLoop(found);
  }, [location.pathname, location.search, location.hash, enabled, loop, loopThreshold, loopWindowMs]);

  if (loop) {
    return (
      <div style={{ background: "var(--bg-app)", minHeight: "100vh" }}>
        <div className="container-app py-10">
          <div className="ui-card p-6">
            <h1 className="text-xl font-semibold tracking-tight">🔄 Navigation loop detected</h1>
            <p className="mt-2 text-sm ui-muted">
              The app visited <span className="font-medium text-[color:var(--text-primary)]">{loop.lastPath}</span>{" "}
              {loop.recent.filter(e => e.path === loop.lastPath).length} times in {loopWindowMs}ms.
            </p>

            <div className="mt-5 grid md:grid-cols-2 gap-4">
              <div>
                <h2 className="text-sm font-semibold mb-2">🔐 Auth State</h2>
                <div className="ui-card p-4 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">isAuthenticated:</span>
                    <span className={`font-bold ${isAuthenticated ? "text-green-600" : "text-red-600"}`}>
                      {String(isAuthenticated)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">hasCompletedOnboarding:</span>
                    <span className={`font-bold ${user?.hasCompletedOnboarding ? "text-green-600" : "text-amber-600"}`}>
                      {String(user?.hasCompletedOnboarding || false)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">userId:</span>
                    <span className="font-mono">{user?.email || "null"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">currentPath:</span>
                    <span className="font-mono text-[10px]">{loop.lastPath}</span>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-sm font-semibold mb-2">🔍 Common Causes</h2>
                <div className="ui-card p-4 text-xs space-y-2 ui-muted">
                  <div>• useEffect(() =&gt; navigate(...), [auth])</div>
                  <div>• Guards redirecting to each other</div>
                  <div>• Query callbacks with navigate()</div>
                  <div>• Conditional render + navigate()</div>
                </div>
              </div>
            </div>

            <div className="mt-5">
              <h2 className="text-sm font-semibold mb-2">📍 Recent route trail</h2>
              <pre className="ui-card p-4 text-xs overflow-auto max-h-60">
{loop.recent.map(formatEvent).join("\n")}
              </pre>
            </div>

            <div className="mt-5 p-4 rounded-lg bg-amber-50 border border-amber-200">
              <p className="text-sm text-amber-900">
                <strong>Fix:</strong> Remove navigate() calls from useEffect, query callbacks, and conditional renders. 
                Navigation should only happen in route guards (RequireAuth, RequireOnboarding) and explicit user actions (button clicks).
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

// Optional helper to inspect nav history from console
export function getNavHistory() {
  return [...NAV_HISTORY];
}