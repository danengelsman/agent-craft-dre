import { Card } from "@/components/ui/card";
import { CheckCircle2, Circle, Loader2, XCircle, ArrowDown, User } from "lucide-react";
import { motion } from "framer-motion";

export default function WorkflowVisualization({ collaboration, agents }) {
  const steps = collaboration.steps || [];
  const orchestrator = agents.find(a => a.id === collaboration.orchestrator_agent);

  const getStepIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'running':
      case 'in_progress':
        return <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  if (steps.length === 0) {
    return (
      <Card className="p-8 text-center bg-gray-50">
        <Circle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-sm text-gray-600">Workflow not yet executed</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Orchestrator at the top */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="p-4 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-xs text-purple-600 font-semibold uppercase">Orchestrator</div>
              <div className="font-bold text-gray-900">{orchestrator?.name || 'Unknown'}</div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Arrow down */}
      <div className="flex justify-center">
        <ArrowDown className="w-5 h-5 text-gray-400" />
      </div>

      {/* Steps */}
      {steps.map((step, index) => {
        const agent = agents.find(a => a.id === step.agent_id);
        
        return (
          <div key={index}>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start gap-4">
                  {/* Step number and status */}
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-bold text-sm text-gray-700">
                      {step.step_number}
                    </div>
                    {getStepIcon(step.status)}
                  </div>

                  {/* Step content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <User className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">{agent?.name || 'Unknown Agent'}</div>
                        <div className="text-xs text-gray-500">{step.status}</div>
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-700 mb-2">
                      <span className="font-semibold">Action:</span> {step.action}
                    </div>

                    {step.output?.result && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                        <div className="text-xs font-semibold text-gray-500 uppercase mb-1">Output</div>
                        <div className="text-sm text-gray-700 line-clamp-3">
                          {typeof step.output.result === 'string' 
                            ? step.output.result 
                            : JSON.stringify(step.output.result)}
                        </div>
                      </div>
                    )}

                    {step.completed_at && (
                      <div className="mt-2 text-xs text-gray-500">
                        Completed: {new Date(step.completed_at).toLocaleString()}
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Arrow between steps */}
            {index < steps.length - 1 && (
              <div className="flex justify-center py-2">
                <ArrowDown className="w-5 h-5 text-gray-400" />
              </div>
            )}
          </div>
        );
      })}

      {/* Final output if completed */}
      {collaboration.status === 'completed' && collaboration.final_output && (
        <>
          <div className="flex justify-center">
            <ArrowDown className="w-5 h-5 text-gray-400" />
          </div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <div className="font-bold text-gray-900 mb-2">Final Output</div>
                  <div className="text-sm text-gray-700">
                    {typeof collaboration.final_output.summary === 'string'
                      ? collaboration.final_output.summary
                      : JSON.stringify(collaboration.final_output.summary)}
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </>
      )}
    </div>
  );
}