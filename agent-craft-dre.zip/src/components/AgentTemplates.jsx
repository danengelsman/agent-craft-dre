import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowRight, Star, Download, Clock, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Pre-built templates that are always available
const STARTER_TEMPLATES = [
  {
    id: "template_customer_support",
    name: "Customer Support Pro",
    description: "Handle customer inquiries, resolve issues, and provide excellent service 24/7",
    category: "customer_service",
    abilities: ["basic_chat", "knowledge_base_search", "sentiment_detection", "ticket_creation"],
    personality: "friendly",
    estimated_setup: "2 min",
    use_cases: ["Answer FAQs", "Resolve complaints", "Track orders"],
    icon: "💬",
    color: "from-blue-500 to-cyan-500"
  },
  {
    id: "template_sales_assistant",
    name: "Sales Assistant",
    description: "Qualify leads, answer product questions, and schedule demos automatically",
    category: "sales",
    abilities: ["basic_chat", "product_catalog", "calendar_booking", "crm_integration"],
    personality: "professional",
    estimated_setup: "3 min",
    use_cases: ["Lead qualification", "Product demos", "Pricing inquiries"],
    icon: "💼",
    color: "from-green-500 to-emerald-500"
  },
  {
    id: "template_content_writer",
    name: "Content Writer",
    description: "Generate blog posts, social media content, and marketing copy in your brand voice",
    category: "content",
    abilities: ["basic_chat", "content_templates", "brand_voice_library", "grammar_checker"],
    personality: "expert",
    estimated_setup: "2 min",
    use_cases: ["Blog posts", "Social media", "Email campaigns"],
    icon: "✍️",
    color: "from-purple-500 to-pink-500"
  },
  {
    id: "template_data_analyst",
    name: "Data Analyst",
    description: "Query databases, generate reports, and visualize insights from your data",
    category: "data",
    abilities: ["basic_chat", "database_query", "chart_generator", "statistical_analysis"],
    personality: "concise",
    estimated_setup: "5 min",
    use_cases: ["Sales reports", "User analytics", "Trend analysis"],
    icon: "📊",
    color: "from-amber-500 to-orange-500"
  },
  {
    id: "template_meeting_scheduler",
    name: "Meeting Scheduler",
    description: "Coordinate calendars, send invites, and manage meeting logistics automatically",
    category: "productivity",
    abilities: ["basic_chat", "calendar_integration", "availability_finder", "email_sender"],
    personality: "friendly",
    estimated_setup: "3 min",
    use_cases: ["Schedule meetings", "Send reminders", "Manage availability"],
    icon: "📅",
    color: "from-indigo-500 to-violet-500"
  },
  {
    id: "template_research_assistant",
    name: "Research Assistant",
    description: "Search the web, summarize articles, and compile research on any topic",
    category: "productivity",
    abilities: ["basic_chat", "web_search", "summarization", "citation_generator"],
    personality: "expert",
    estimated_setup: "2 min",
    use_cases: ["Market research", "Competitor analysis", "Topic deep-dives"],
    icon: "🔍",
    color: "from-teal-500 to-cyan-500"
  }
];

export default function AgentTemplates({ onSelectTemplate, compact = false }) {
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  
  // Fetch community templates (agents marked as templates)
  const { data: communityTemplates = [] } = useQuery({
    queryKey: ['communityTemplates'],
    queryFn: async () => {
      const templates = await base44.entities.Agent.filter({ 
        is_template: true, 
        is_public: true 
      }, '-download_count', 6);
      return templates;
    },
    staleTime: 300000,
  });
  
  const handleSelect = (template) => {
    setSelectedTemplate(template.id);
    if (onSelectTemplate) {
      onSelectTemplate(template);
    }
  };
  
  if (compact) {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-gray-900">Quick Start Templates</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {STARTER_TEMPLATES.slice(0, 6).map((template) => (
            <button
              key={template.id}
              onClick={() => handleSelect(template)}
              className={`p-4 rounded-xl text-left transition-all border-2 ${
                selectedTemplate === template.id
                  ? 'border-gray-900 bg-gray-50'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="text-2xl mb-2">{template.icon}</div>
              <h4 className="font-semibold text-sm text-gray-900">{template.name}</h4>
              <p className="text-xs text-gray-500 mt-1 line-clamp-2">{template.description}</p>
            </button>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="space-y-8">
      {/* Starter Templates */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Starter Templates</h2>
            <p className="text-gray-600">Pre-configured agents ready to customize</p>
          </div>
          <Link to={createPageUrl("GuidedBuilder")}>
            <Button variant="outline" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Build Custom
            </Button>
          </Link>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {STARTER_TEMPLATES.map((template, index) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className={`premium-card p-6 cursor-pointer transition-all ${
                selectedTemplate === template.id ? 'ring-2 ring-gray-900' : ''
              }`}
              onClick={() => handleSelect(template)}
            >
              <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center mb-4 text-2xl">
                {template.icon}
              </div>
              
              <h3 className="font-bold text-lg mb-2 text-gray-900">{template.name}</h3>
              <p className="text-sm text-gray-600 mb-4">{template.description}</p>
              
              <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {template.estimated_setup}
                </div>
                <div className="flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  {template.abilities.length} abilities
                </div>
              </div>
              
              <div className="space-y-1 mb-4">
                {template.use_cases.map((useCase, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-gray-600">
                    <span className="text-gray-900">•</span>
                    {useCase}
                  </div>
                ))}
              </div>
              
              <Button className="w-full bg-gray-900 hover:bg-gray-800 text-white" size="sm">
                Use Template
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Community Templates */}
      {communityTemplates.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Community Templates</h2>
              <p className="text-gray-600">Popular agents from the community</p>
            </div>
            <Link to={createPageUrl("Marketplace")}>
              <Button variant="outline" className="gap-2">
                View All
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {communityTemplates.map((template, index) => (
              <motion.div
                key={template.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="premium-card p-6"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-gray-900" />
                  </div>
                  {template.average_rating > 0 && (
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star className="w-4 h-4 fill-current" />
                      <span className="text-sm font-medium">{template.average_rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>
                
                <h3 className="font-bold text-lg mb-1 text-gray-900">{template.name}</h3>
                <p className="text-xs text-gray-500 mb-2">by {template.creator_name || 'Community'}</p>
                <p className="text-sm text-gray-600 mb-4 line-clamp-2">{template.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Download className="w-3 h-3" />
                    {template.download_count || 0} uses
                  </div>
                  <Button size="sm" variant="outline">
                    Use Template
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export { STARTER_TEMPLATES };