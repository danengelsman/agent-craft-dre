import { TrendingUp, TrendingDown } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function StatCard({ 
  title, 
  value, 
  change, 
  trend = 'up', 
  icon: Icon,
  color = 'from-purple-500 to-blue-600'
}) {
  return (
    <Card className="p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center overflow-hidden`}>
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/bd622c784_IMG_0015.jpeg"
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>
        {change && (
          <div className={`flex items-center gap-1 text-sm font-medium ${
            trend === 'up' ? 'text-green-600' : 'text-red-600'
          }`}>
            {trend === 'up' ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            {change}
          </div>
        )}
      </div>
      <div className="text-2xl font-bold text-gray-900 mb-1">{value}</div>
      <div className="text-sm text-gray-500">{title}</div>
    </Card>
  );
}