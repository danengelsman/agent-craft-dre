import { motion } from "framer-motion";

export default function FeatureCard({ 
  icon: Icon, 
  title, 
  description, 
  index = 0 
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="p-8 rounded-2xl bg-white border border-gray-200 hover:shadow-xl hover:border-purple-200 transition-all group"
    >
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform overflow-hidden">
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/f0259eb9b_IMG_0013.jpeg"
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </motion.div>
  );
}