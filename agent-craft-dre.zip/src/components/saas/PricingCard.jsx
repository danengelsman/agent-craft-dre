import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function PricingCard({
  name,
  description,
  price,
  period = 'month',
  features = [],
  cta = 'Get Started',
  popular = false,
  icon: Icon,
  color = 'from-purple-500 to-blue-600',
  onSelect,
  index = 0
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 * index }}
      className={`relative rounded-3xl p-8 ${
        popular 
          ? 'bg-gradient-to-br from-purple-600 to-blue-600 text-white shadow-xl scale-105' 
          : 'bg-white border border-gray-200'
      }`}
    >
      {popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="px-4 py-1 rounded-full bg-amber-400 text-amber-900 text-sm font-bold">
            Most Popular
          </span>
        </div>
      )}

      {Icon && (
        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${color} flex items-center justify-center mb-6 overflow-hidden ${popular ? 'bg-white/20' : ''}`}>
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/ab13e1317_IMG_0014.jpg"
            alt={name}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <h3 className={`text-2xl font-bold mb-2 ${popular ? 'text-white' : 'text-gray-900'}`}>
        {name}
      </h3>
      <p className={`mb-6 ${popular ? 'text-purple-100' : 'text-gray-600'}`}>
        {description}
      </p>

      <div className="mb-6">
        <span className={`text-5xl font-bold ${popular ? 'text-white' : 'text-gray-900'}`}>
          ${price}
        </span>
        <span className={popular ? 'text-purple-100' : 'text-gray-500'}>
          /{period}
        </span>
      </div>

      <Button 
        onClick={onSelect}
        className={`w-full h-12 text-lg font-semibold mb-8 ${
          popular 
            ? 'bg-white text-purple-600 hover:bg-gray-100' 
            : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'
        }`}
      >
        {cta}
      </Button>

      <ul className="space-y-4">
        {features.map((feature) => (
          <li key={feature.name} className="flex items-center gap-3">
            {feature.included ? (
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                popular ? 'bg-white/20' : 'bg-green-100'
              }`}>
                <Check className={`w-3 h-3 ${popular ? 'text-white' : 'text-green-600'}`} />
              </div>
            ) : (
              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                popular ? 'bg-white/10' : 'bg-gray-100'
              }`}>
                <X className={`w-3 h-3 ${popular ? 'text-purple-200' : 'text-gray-400'}`} />
              </div>
            )}
            <span className={`text-sm ${
              feature.included 
                ? (popular ? 'text-white' : 'text-gray-900') 
                : (popular ? 'text-purple-200' : 'text-gray-400')
            }`}>
              {feature.name}
            </span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}