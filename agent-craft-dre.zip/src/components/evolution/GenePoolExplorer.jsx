import { useState } from "react";
import { motion } from "framer-motion";
import { Dna, Sparkles, Check, TrendingUp, Beaker, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const GENE_TYPE_CONFIG = {
  personality_trait: { icon: Sparkles, color: "from-pink-500 to-rose-500", label: "Personality" },
  ability_combo: { icon: Zap, color: "from-amber-500 to-orange-500", label: "Ability Combo" },
  prompt_pattern: { icon: Beaker, color: "from-purple-500 to-indigo-500", label: "Prompt Pattern" },
  workflow_snippet: { icon: TrendingUp, color: "from-blue-500 to-cyan-500", label: "Workflow" },
  response_style: { icon: Dna, color: "from-green-500 to-emerald-500", label: "Response Style" }
};

export default function GenePoolExplorer({ genes, onApplyGene, currentAgentId }) {
  const [selectedGene, setSelectedGene] = useState(null);
  const [filterType, setFilterType] = useState("all");

  const filteredGenes = genes?.filter(gene => 
    filterType === "all" || gene.gene_type === filterType
  ) || [];

  return (
    <div>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => setFilterType("all")}
          className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
            filterType === "all"
              ? 'bg-gray-900 text-white'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          All Genes
        </button>
        {Object.entries(GENE_TYPE_CONFIG).map(([type, config]) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              filterType === type
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {config.label}
          </button>
        ))}
      </div>

      {filteredGenes.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <Dna className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>No genes in pool yet</p>
          <p className="text-sm">High-performing agent traits will appear here</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredGenes.map((gene, index) => {
            const config = GENE_TYPE_CONFIG[gene.gene_type] || GENE_TYPE_CONFIG.personality_trait;
            const Icon = config.icon;
            const isSelected = selectedGene?.id === gene.id;

            return (
              <motion.div
                key={gene.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => setSelectedGene(isSelected ? null : gene)}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  isSelected
                    ? 'border-purple-500 bg-purple-50 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
                }`}
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${config.color} flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-gray-900 truncate">{gene.name}</h4>
                    <p className="text-xs text-gray-500">{config.label}</p>
                  </div>
                  {gene.is_validated && (
                    <div className="w-6 h-6 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-green-600" />
                    </div>
                  )}
                </div>

                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                  {gene.description}
                </p>

                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <span className="text-gray-500">
                      Used {gene.times_used || 0}x
                    </span>
                    <span className={`font-medium ${
                      gene.effectiveness_score >= 70 ? 'text-green-600' :
                      gene.effectiveness_score >= 50 ? 'text-amber-600' : 'text-red-600'
                    }`}>
                      {gene.effectiveness_score}% effective
                    </span>
                  </div>
                </div>

                {isSelected && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-4 pt-4 border-t border-purple-200"
                  >
                    {gene.compatible_intents?.length > 0 && (
                      <div className="mb-3">
                        <p className="text-xs font-semibold text-gray-500 mb-1">Compatible with:</p>
                        <div className="flex flex-wrap gap-1">
                          {gene.compatible_intents.map(intent => (
                            <span key={intent} className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 text-xs">
                              {intent}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        onApplyGene(gene);
                      }}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                      size="sm"
                    >
                      <Dna className="w-4 h-4 mr-2" />
                      Apply Gene to Agent
                    </Button>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}