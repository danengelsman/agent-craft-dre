import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Dna, Zap, Shield, Clock, Settings, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const EVOLUTION_TYPES = [
  { id: "personality_refinement", label: "Personality Refinement", description: "Adjust tone and communication style" },
  { id: "prompt_tuning", label: "Prompt Tuning", description: "Optimize system prompts for better responses" },
  { id: "ability_optimization", label: "Ability Optimization", description: "Enable/disable abilities based on usage" },
  { id: "workflow_enhancement", label: "Workflow Enhancement", description: "Improve connected workflows" },
  { id: "hybrid_mutation", label: "Hybrid Mutation", description: "Combine traits from high-performing agents" }
];

const FREQUENCY_OPTIONS = [
  { id: "daily", label: "Daily" },
  { id: "weekly", label: "Weekly" },
  { id: "monthly", label: "Monthly" },
  { id: "on_threshold", label: "On Performance Drop" }
];

export default function EvolutionSettingsPanel({ settings, onSave, isLoading }) {
  const [localSettings, setLocalSettings] = useState({
    auto_evolve_enabled: false,
    evolution_frequency: "weekly",
    min_interactions_before_evolve: 50,
    performance_threshold: 70,
    allowed_evolution_types: ["personality_refinement", "prompt_tuning"],
    require_approval: true,
    max_generations: 10,
    rollback_on_regression: true,
    ...settings
  });

  useEffect(() => {
    if (settings) {
      setLocalSettings(prev => ({ ...prev, ...settings }));
    }
  }, [settings]);

  const toggleEvolutionType = (typeId) => {
    setLocalSettings(prev => ({
      ...prev,
      allowed_evolution_types: prev.allowed_evolution_types.includes(typeId)
        ? prev.allowed_evolution_types.filter(t => t !== typeId)
        : [...prev.allowed_evolution_types, typeId]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Auto-Evolve Toggle */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-50 to-blue-50 border border-purple-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
              <Dna className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-900">Auto-Evolution</h3>
              <p className="text-sm text-gray-600">Let your agent evolve automatically</p>
            </div>
          </div>
          <Switch
            checked={localSettings.auto_evolve_enabled}
            onCheckedChange={(checked) => setLocalSettings(prev => ({ ...prev, auto_evolve_enabled: checked }))}
          />
        </div>

        {localSettings.auto_evolve_enabled && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="pt-4 border-t border-purple-200"
          >
            <p className="text-sm text-purple-700">
              <Sparkles className="w-4 h-4 inline mr-1" />
              Your agent will continuously improve based on real interactions
            </p>
          </motion.div>
        )}
      </div>

      {/* Evolution Frequency */}
      <div className="p-5 rounded-xl border border-gray-200 bg-white">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-gray-600" />
          <h4 className="font-semibold text-gray-900">Evolution Frequency</h4>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {FREQUENCY_OPTIONS.map(option => (
            <button
              key={option.id}
              onClick={() => setLocalSettings(prev => ({ ...prev, evolution_frequency: option.id }))}
              className={`p-3 rounded-lg text-sm font-medium transition-all ${
                localSettings.evolution_frequency === option.id
                  ? 'bg-purple-100 text-purple-700 border-2 border-purple-500'
                  : 'bg-gray-50 text-gray-600 border-2 border-transparent hover:bg-gray-100'
              }`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      {/* Performance Threshold */}
      <div className="p-5 rounded-xl border border-gray-200 bg-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-gray-600" />
            <h4 className="font-semibold text-gray-900">Performance Threshold</h4>
          </div>
          <span className="text-lg font-bold text-purple-600">
            {localSettings.performance_threshold}%
          </span>
        </div>
        <Slider
          value={[localSettings.performance_threshold]}
          onValueChange={([value]) => setLocalSettings(prev => ({ ...prev, performance_threshold: value }))}
          min={30}
          max={95}
          step={5}
          className="mb-2"
        />
        <p className="text-xs text-gray-500">
          Evolution triggers when performance drops below this threshold
        </p>
      </div>

      {/* Minimum Interactions */}
      <div className="p-5 rounded-xl border border-gray-200 bg-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-gray-600" />
            <h4 className="font-semibold text-gray-900">Minimum Interactions</h4>
          </div>
          <span className="text-lg font-bold text-purple-600">
            {localSettings.min_interactions_before_evolve}
          </span>
        </div>
        <Slider
          value={[localSettings.min_interactions_before_evolve]}
          onValueChange={([value]) => setLocalSettings(prev => ({ ...prev, min_interactions_before_evolve: value }))}
          min={10}
          max={200}
          step={10}
          className="mb-2"
        />
        <p className="text-xs text-gray-500">
          Wait for this many interactions before considering evolution
        </p>
      </div>

      {/* Evolution Types */}
      <div className="p-5 rounded-xl border border-gray-200 bg-white">
        <h4 className="font-semibold text-gray-900 mb-4">Allowed Evolution Types</h4>
        <div className="space-y-3">
          {EVOLUTION_TYPES.map(type => (
            <label
              key={type.id}
              className={`flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                localSettings.allowed_evolution_types.includes(type.id)
                  ? 'bg-purple-50 border-2 border-purple-300'
                  : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
              }`}
            >
              <input
                type="checkbox"
                checked={localSettings.allowed_evolution_types.includes(type.id)}
                onChange={() => toggleEvolutionType(type.id)}
                className="mt-1 rounded"
              />
              <div>
                <p className="font-medium text-gray-900">{type.label}</p>
                <p className="text-xs text-gray-500">{type.description}</p>
              </div>
            </label>
          ))}
        </div>
      </div>

      {/* Safety Options */}
      <div className="p-5 rounded-xl border border-gray-200 bg-white">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-gray-600" />
          <h4 className="font-semibold text-gray-900">Safety Controls</h4>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900">Require Approval</p>
              <p className="text-xs text-gray-500">Review changes before they're applied</p>
            </div>
            <Switch
              checked={localSettings.require_approval}
              onCheckedChange={(checked) => setLocalSettings(prev => ({ ...prev, require_approval: checked }))}
            />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900">Auto-Rollback on Regression</p>
              <p className="text-xs text-gray-500">Revert if performance drops after evolution</p>
            </div>
            <Switch
              checked={localSettings.rollback_on_regression}
              onCheckedChange={(checked) => setLocalSettings(prev => ({ ...prev, rollback_on_regression: checked }))}
            />
          </div>
        </div>
      </div>

      {/* Save Button */}
      <Button
        onClick={() => onSave(localSettings)}
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white h-12"
      >
        {isLoading ? "Saving..." : "Save Evolution Settings"}
      </Button>
    </div>
  );
}