import { motion } from "framer-motion";
import { Dna, TrendingUp, TrendingDown, RotateCcw, Check, Clock, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

const STATUS_CONFIG = {
  pending: { icon: Clock, color: "text-amber-500", bg: "bg-amber-100" },
  applied: { icon: Check, color: "text-green-500", bg: "bg-green-100" },
  rolled_back: { icon: RotateCcw, color: "text-blue-500", bg: "bg-blue-100" },
  failed: { icon: AlertTriangle, color: "text-red-500", bg: "bg-red-100" }
};

const EVOLUTION_TYPE_LABELS = {
  personality_refinement: "Personality Refinement",
  ability_optimization: "Ability Optimization",
  workflow_enhancement: "Workflow Enhancement",
  prompt_tuning: "Prompt Tuning",
  hybrid_mutation: "Hybrid Mutation"
};

export default function EvolutionTimeline({ evolutions, onApply, onRollback }) {
  if (!evolutions || evolutions.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <Dna className="w-12 h-12 mx-auto mb-3 opacity-30" />
        <p>No evolution history yet</p>
        <p className="text-sm">Evolution events will appear here</p>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Timeline line */}
      <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-500 via-blue-500 to-green-500" />

      <div className="space-y-6">
        {evolutions.map((evolution, index) => {
          const StatusIcon = STATUS_CONFIG[evolution.status]?.icon || Clock;
          const improvement = evolution.improvement_percentage || 0;

          return (
            <motion.div
              key={evolution.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative pl-16"
            >
              {/* Timeline node */}
              <div className={`absolute left-4 w-5 h-5 rounded-full border-2 border-white shadow-lg ${STATUS_CONFIG[evolution.status]?.bg || 'bg-gray-100'} flex items-center justify-center`}>
                <StatusIcon className={`w-3 h-3 ${STATUS_CONFIG[evolution.status]?.color}`} />
              </div>

              <div className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-900">
                        Generation {evolution.generation}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_CONFIG[evolution.status]?.bg} ${STATUS_CONFIG[evolution.status]?.color}`}>
                        {evolution.status}
                      </span>
                      {evolution.auto_applied && (
                        <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-700">
                          Auto
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">
                      {EVOLUTION_TYPE_LABELS[evolution.evolution_type] || evolution.evolution_type}
                    </p>
                  </div>
                  
                  {improvement !== 0 && (
                    <div className={`flex items-center gap-1 px-3 py-1 rounded-full ${
                      improvement > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {improvement > 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      <span className="font-bold text-sm">
                        {improvement > 0 ? '+' : ''}{improvement.toFixed(1)}%
                      </span>
                    </div>
                  )}
                </div>

                {/* Changes */}
                {evolution.changes_applied?.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Changes</p>
                    <div className="space-y-1">
                      {evolution.changes_applied.slice(0, 3).map((change, i) => (
                        <div key={i} className="text-sm text-gray-600 flex items-start gap-2">
                          <span className="text-purple-500">•</span>
                          <span>{change.reason || `Updated ${change.field}`}</span>
                        </div>
                      ))}
                      {evolution.changes_applied.length > 3 && (
                        <p className="text-xs text-gray-400">
                          +{evolution.changes_applied.length - 3} more changes
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Performance comparison */}
                {evolution.performance_before && evolution.performance_after && (
                  <div className="grid grid-cols-2 gap-4 p-3 bg-gray-50 rounded-lg mb-3">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Before</p>
                      <p className="font-bold text-gray-700">
                        {(evolution.performance_before.success_rate * 100).toFixed(0)}% success
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">After</p>
                      <p className="font-bold text-green-600">
                        {(evolution.performance_after.success_rate * 100).toFixed(0)}% success
                      </p>
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-400">
                    {new Date(evolution.created_date).toLocaleDateString()} at{' '}
                    {new Date(evolution.created_date).toLocaleTimeString()}
                  </p>
                  <div className="flex gap-2">
                    {evolution.status === 'pending' && onApply && (
                      <Button
                        size="sm"
                        onClick={() => onApply(evolution)}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        Apply
                      </Button>
                    )}
                    {evolution.status === 'applied' && onRollback && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onRollback(evolution)}
                      >
                        <RotateCcw className="w-3 h-3 mr-1" />
                        Rollback
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}