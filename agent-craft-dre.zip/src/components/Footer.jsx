import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Mail } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-gray-200 bg-white mt-auto">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col items-center justify-center md:flex-row md:justify-between gap-6">
          <div className="text-sm text-gray-600 text-center md:text-left">
            © {currentYear} Agentic Solutions. All rights reserved. Made with love in Grand Rapids, Michigan.
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm">
            <Link 
              to={createPageUrl("Privacy")} 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              Privacy Policy
            </Link>
            <Link 
              to={createPageUrl("Terms")} 
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              Terms of Service
            </Link>
            <Link 
              to={createPageUrl("Contact")} 
              className="text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1"
            >
              <Mail className="w-4 h-4" />
              Contact
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}