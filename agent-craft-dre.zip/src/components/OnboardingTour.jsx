import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { X, ArrowRight, ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const TOUR_STEPS = [
  {
    target: "[data-tour='sidebar']",
    title: "Welcome to AgentCraft! 👋",
    content: "Let's take a quick tour to get you started. This is your navigation sidebar where you can access all features.",
    position: "right"
  },
  {
    target: "[data-tour='builder']",
    title: "Build Your AI Agents",
    content: "Click here to create custom AI agents with different abilities and personalities. No coding required!",
    position: "right"
  },
  {
    target: "[data-tour='chat']",
    title: "Chat with Your Agents",
    content: "Once you create an agent, chat with it here. Your agents can help with tasks, answer questions, and more.",
    position: "right"
  },
  {
    target: "[data-tour='learn']",
    title: "Learn & Level Up",
    content: "Complete lessons to unlock new abilities for your agents. Earn XP and level up your skills!",
    position: "right"
  },
  {
    target: "[data-tour='marketplace']",
    title: "Discover & Earn Money 💰",
    content: "Browse agents created by the community, or publish your own to earn money. Keep 85% of every sale!",
    position: "right"
  },
  {
    target: "[data-tour='home']",
    title: "Your Dashboard",
    content: "Track your progress, view analytics, and access quick actions from your personalized dashboard.",
    position: "right"
  },
  {
    target: "[data-tour='monetization']",
    title: "Start Earning",
    content: "Ready to monetize? Create quality agents, list them on the marketplace, and watch your earnings grow!",
    position: "bottom",
    optional: true
  }
];

export default function OnboardingTour({ user }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [targetPosition, setTargetPosition] = useState(null);
  const queryClient = useQueryClient();

  const { data: onboarding } = useQuery({
    queryKey: ['onboarding', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      try {
        const existing = await base44.entities.OnboardingProgress.filter({ user_email: user.email });
        if (existing.length > 0) return existing[0];
        
        // Create onboarding progress
        return await base44.entities.OnboardingProgress.create({
          user_email: user.email,
          tour_step: 0
        });
      } catch (error) {
        console.error("Error loading onboarding:", error);
        return null;
      }
    },
    enabled: !!user?.email,
    retry: 1,
    staleTime: 60000,
  });

  const updateOnboardingMutation = useMutation({
    mutationFn: (data) => {
      if (!onboarding?.id) return Promise.reject("No onboarding record");
      return base44.entities.OnboardingProgress.update(onboarding.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding'] });
    },
    retry: 1,
  });

  useEffect(() => {
    if (onboarding && !onboarding.has_completed_tour && !onboarding.dismissed_tour) {
      setCurrentStep(onboarding.tour_step || 0);
      setIsActive(true);
    }
  }, [onboarding]);

  useEffect(() => {
    if (isActive) {
      const step = TOUR_STEPS[currentStep];
      const element = document.querySelector(step.target);
      if (element) {
        const rect = element.getBoundingClientRect();
        setTargetPosition(rect);
      }
    }
  }, [currentStep, isActive]);

  const handleNext = async () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      const nextStep = currentStep + 1;
      setCurrentStep(nextStep);
      if (onboarding) {
        await updateOnboardingMutation.mutateAsync({ tour_step: nextStep });
      }
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      const prevStep = currentStep - 1;
      setCurrentStep(prevStep);
      if (onboarding) {
        updateOnboardingMutation.mutate({ tour_step: prevStep });
      }
    }
  };

  const handleComplete = async () => {
    if (onboarding) {
      await updateOnboardingMutation.mutateAsync({
        has_completed_tour: true,
        tour_step: TOUR_STEPS.length,
        completed_at: new Date().toISOString()
      });
    }
    setIsActive(false);
  };

  const handleDismiss = () => {
    if (onboarding) {
      updateOnboardingMutation.mutate({ dismissed_tour: true });
    }
    setIsActive(false);
  };

  if (!isActive || !targetPosition) return null;

  const step = TOUR_STEPS[currentStep];

  return (
    <>
      {/* Overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
        onClick={handleDismiss}
      />

      {/* Highlight */}
      <motion.div
        className="fixed z-40 rounded-2xl border-4 border-white shadow-2xl pointer-events-none"
        animate={{
          top: targetPosition.top - 8,
          left: targetPosition.left - 8,
          width: targetPosition.width + 16,
          height: targetPosition.height + 16,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
      />

      {/* Tooltip */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed z-50 premium-card p-6 max-w-md"
        style={{
          top: targetPosition.top + targetPosition.height / 2 - 100,
          left: step.position === "right" 
            ? targetPosition.right + 20 
            : targetPosition.left - 320 - 20,
        }}
      >
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-lg text-gray-900">{step.title}</h3>
            <div className="text-xs text-gray-500">
              Step {currentStep + 1} of {TOUR_STEPS.length}
            </div>
          </div>
        </div>

        <p className="text-gray-600 mb-6">{step.content}</p>

        <div className="flex justify-between items-center">
          <Button
            onClick={handlePrev}
            disabled={currentStep === 0}
            variant="outline"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="flex gap-1">
            {TOUR_STEPS.map((_, idx) => (
              <div
                key={idx}
                className={`w-2 h-2 rounded-full transition-all ${
                  idx === currentStep ? 'bg-gray-900 w-4' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          <Button
            onClick={handleNext}
            className="bg-gray-900 hover:bg-gray-800 text-white"
          >
            {currentStep === TOUR_STEPS.length - 1 ? 'Finish' : 'Next'}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </motion.div>
    </>
  );
}