import * as React from "react";
import { cn } from "./cn";

export function Textarea({ className, ...props }) {
  return (
    <textarea
      className={cn(
        "ui-control resize-none transition-all duration-200 hover:border-gray-400 focus:border-gray-900 focus:shadow-sm cursor-text",
        className
      )}
      {...props}
    />
  );
}