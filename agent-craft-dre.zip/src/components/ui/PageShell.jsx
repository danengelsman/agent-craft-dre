import * as React from "react";
import { cn } from "./cn";

export function PageShell({
  title,
  subtitle,
  actions,
  children,
  className,
}) {
  return (
    <div className={cn("min-h-screen", className)} style={{ background: "var(--bg-app)" }}>
      <div className="container-app py-8">
        {(title || subtitle || actions) && (
          <div className="mb-6 flex items-start justify-between gap-4">
            <div>
              {title && <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>}
              {subtitle && <p className="mt-1 text-sm ui-muted">{subtitle}</p>}
            </div>
            {actions && <div className="flex items-center gap-2">{actions}</div>}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}