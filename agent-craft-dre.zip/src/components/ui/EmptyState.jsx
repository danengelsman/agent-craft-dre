import * as React from "react";

export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="text-center py-20">
      {Icon && (
        <div className="w-24 h-24 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-6">
          <Icon className="w-12 h-12" />
        </div>
      )}
      {title && <h2 className="text-2xl font-bold mb-2">{title}</h2>}
      {description && <p className="ui-muted mb-6">{description}</p>}
      {action && <div>{action}</div>}
    </div>
  );
}