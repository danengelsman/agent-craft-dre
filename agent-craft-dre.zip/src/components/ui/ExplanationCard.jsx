import { Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";

export default function ExplanationCard({ title, children, icon: Icon = Info }) {
  return (
    <Card className="bg-blue-50 border-blue-200 hover:border-blue-300 transition-colors duration-200">
      <CardContent className="p-4">
        <div className="flex gap-3">
          <div className="flex-shrink-0 mt-0.5">
            <Icon className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            {title && <h4 className="font-semibold text-blue-900 mb-1">{title}</h4>}
            <p className="text-sm text-blue-800">{children}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}