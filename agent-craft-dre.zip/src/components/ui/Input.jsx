import * as React from "react";
import { cn } from "./cn";

export const Input = React.forwardRef(function Input(
  { className, ...props },
  ref
) {
  return (
    <input
      ref={ref}
      className={cn(
        "ui-control w-full px-3 py-2.5 text-sm placeholder:text-[color:var(--text-muted)]",
        "transition-all duration-200 hover:border-gray-400 focus:border-gray-900 focus:shadow-sm cursor-text",
        className
      )}
      {...props}
    />
  );
});