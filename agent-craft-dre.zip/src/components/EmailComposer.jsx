import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Mail, Send, Loader2, Sparkles, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function EmailComposer({ agent, onClose, prefilledData = {} }) {
  const [to, setTo] = useState(prefilledData.to || "");
  const [subject, setSubject] = useState(prefilledData.subject || "");
  const [body, setBody] = useState(prefilledData.body || "");
  const [isSending, setIsSending] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerateWithAI = async () => {
    if (!subject && !body) {
      alert("Please provide at least a subject or some body text to enhance with AI");
      return;
    }

    setIsGenerating(true);
    try {
      let systemPrompt = `You are ${agent?.name || "an email assistant"} helping to write a professional email.`;
      
      if (agent?.personality) {
        systemPrompt += ` Your personality: ${agent.personality}`;
      }

      const prompt = `${systemPrompt}

${subject ? `Subject: ${subject}` : ""}
${body ? `Draft: ${body}` : ""}

Please ${body ? 'improve and expand this email draft' : 'write a complete professional email based on the subject'}. Make it clear, professional, and well-structured. Return ONLY the email body text, no subject line.`;

      const enhancedBody = await base44.integrations.Core.InvokeLLM({
        prompt: prompt
      });

      setBody(enhancedBody);
    } catch (error) {
      console.error("Error generating email:", error);
      alert("Failed to generate email. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSend = async () => {
    if (!to || !subject || !body) {
      alert("Please fill in all fields (To, Subject, and Body)");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(to)) {
      alert("Please enter a valid email address");
      return;
    }

    setIsSending(true);
    try {
      await base44.integrations.Core.SendEmail({
        from_name: agent?.name || "AgentCraft Assistant",
        to: to,
        subject: subject,
        body: body
      });

      alert("✉️ Email sent successfully!");
      onClose?.();
    } catch (error) {
      console.error("Error sending email:", error);
      alert("Failed to send email. Please try again.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="p-6 md:p-8 bg-white shadow-2xl">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Compose Email</h2>
                {agent && (
                  <p className="text-sm text-gray-600">with {agent.name}</p>
                )}
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Form */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="to" className="text-sm font-semibold text-gray-700 mb-2 block">
                To
              </Label>
              <Input
                id="to"
                type="email"
                placeholder="recipient@example.com"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="h-12"
              />
            </div>

            <div>
              <Label htmlFor="subject" className="text-sm font-semibold text-gray-700 mb-2 block">
                Subject
              </Label>
              <Input
                id="subject"
                placeholder="Email subject..."
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="h-12"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label htmlFor="body" className="text-sm font-semibold text-gray-700">
                  Message
                </Label>
                <Button
                  onClick={handleGenerateWithAI}
                  disabled={isGenerating || (!subject && !body)}
                  variant="ghost"
                  size="sm"
                  className="text-gray-900 hover:text-gray-700 hover:bg-gray-100"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Enhancing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Enhance with AI
                    </>
                  )}
                </Button>
              </div>
              <Textarea
                id="body"
                placeholder="Write your email here... or use AI to help you!"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                className="min-h-64 resize-none"
                disabled={isGenerating}
              />
            </div>

            {/* Info Box */}
            <div className="p-4 rounded-xl bg-blue-50 border border-blue-100">
              <p className="text-sm text-blue-900">
                💡 <strong>Tip:</strong> Write a draft or just add a subject, then click "Enhance with AI" 
                to get help writing a professional email!
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mt-6">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 h-12"
              disabled={isSending}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSend}
              disabled={isSending || !to || !subject || !body}
              className="flex-1 h-12 bg-gray-900 hover:bg-gray-800 text-white"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5 mr-2" />
                  Send Email
                </>
              )}
            </Button>
          </div>
        </Card>
      </motion.div>
    </motion.div>
  );
}