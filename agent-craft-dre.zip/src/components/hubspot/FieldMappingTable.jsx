import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, CheckCircle2, Loader2 } from "lucide-react";

const DEFAULT_MAPPINGS = {
  contact: [
    { local: 'email', hubspot: 'email', type: 'email', required: true },
    { local: 'first_name', hubspot: 'firstname', type: 'string', required: false },
    { local: 'last_name', hubspot: 'lastname', type: 'string', required: false },
    { local: 'phone', hubspot: 'phone', type: 'phone', required: false },
    { local: 'company', hubspot: 'company', type: 'string', required: false },
    { local: 'job_title', hubspot: 'jobtitle', type: 'string', required: false },
    { local: 'city', hubspot: 'city', type: 'string', required: false },
    { local: 'state', hubspot: 'state', type: 'string', required: false },
    { local: 'country', hubspot: 'country', type: 'string', required: false },
  ],
  company: [
    { local: 'name', hubspot: 'name', type: 'string', required: true },
    { local: 'domain', hubspot: 'domain', type: 'string', required: false },
    { local: 'industry', hubspot: 'industry', type: 'string', required: false },
  ],
  deal: [
    { local: 'deal_name', hubspot: 'dealname', type: 'string', required: true },
    { local: 'amount', hubspot: 'amount', type: 'number', required: true },
  ]
};

export default function FieldMappingTable({ fieldMappings }) {
  const [selectedObjectType, setSelectedObjectType] = useState("contact");
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMapping, setNewMapping] = useState({
    local_field: "",
    hubspot_field: "",
    field_type: "string",
    is_required: false
  });
  const queryClient = useQueryClient();

  const createMappingMutation = useMutation({
    mutationFn: (mappingData) => base44.entities.HubSpotFieldMapping.create(mappingData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hubspot_field_mappings'] });
      setShowAddForm(false);
      setNewMapping({ local_field: "", hubspot_field: "", field_type: "string", is_required: false });
    }
  });

  const deleteMappingMutation = useMutation({
    mutationFn: (mappingId) => base44.entities.HubSpotFieldMapping.delete(mappingId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hubspot_field_mappings'] });
    }
  });

  const initializeDefaultMappings = async () => {
    const defaults = DEFAULT_MAPPINGS[selectedObjectType];
    
    for (const mapping of defaults) {
      await base44.entities.HubSpotFieldMapping.create({
        object_type: selectedObjectType,
        local_field: mapping.local,
        hubspot_field: mapping.hubspot,
        field_type: mapping.type,
        is_required: mapping.required,
        is_active: true
      });
    }
    
    queryClient.invalidateQueries({ queryKey: ['hubspot_field_mappings'] });
  };

  const handleAddMapping = () => {
    if (!newMapping.local_field || !newMapping.hubspot_field) return;

    createMappingMutation.mutate({
      object_type: selectedObjectType,
      ...newMapping,
      is_active: true
    });
  };

  const filteredMappings = fieldMappings.filter(
    m => m.object_type === selectedObjectType && m.is_active
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-semibold text-gray-900 mb-2">Field mappings</h2>
          <p className="text-base text-gray-600">
            Define how your fields map to HubSpot properties
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedObjectType} onValueChange={setSelectedObjectType}>
            <SelectTrigger className="w-32 h-10">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="contact">Contacts</SelectItem>
              <SelectItem value="company">Companies</SelectItem>
              <SelectItem value="deal">Deals</SelectItem>
            </SelectContent>
          </Select>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            variant="outline"
            className="h-10"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add mapping
          </Button>
        </div>
      </div>

      {showAddForm && (
        <div className="p-6 bg-gray-50 rounded-2xl">
          <h4 className="font-semibold text-gray-900 mb-4">New mapping</h4>
          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Local field</Label>
              <Input
                placeholder="e.g., first_name"
                value={newMapping.local_field}
                onChange={(e) => setNewMapping({ ...newMapping, local_field: e.target.value })}
                className="h-10"
              />
            </div>
            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">HubSpot field</Label>
              <Input
                placeholder="e.g., firstname"
                value={newMapping.hubspot_field}
                onChange={(e) => setNewMapping({ ...newMapping, hubspot_field: e.target.value })}
                className="h-10"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleAddMapping}
              disabled={createMappingMutation.isPending}
              className="h-10 bg-black hover:bg-gray-800 text-white"
            >
              {createMappingMutation.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                'Save'
              )}
            </Button>
            <Button onClick={() => setShowAddForm(false)} variant="outline" className="h-10">
              Cancel
            </Button>
          </div>
        </div>
      )}

      {filteredMappings.length === 0 ? (
        <div className="text-center py-20 bg-gray-50 rounded-2xl">
          <p className="text-gray-600 mb-4">No mappings configured</p>
          <Button onClick={initializeDefaultMappings} variant="outline">
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Initialize defaults
          </Button>
        </div>
      ) : (
        <div className="bg-gray-50 rounded-2xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left p-4 text-[15px] font-semibold text-gray-900">Local field</th>
                <th className="text-left p-4 text-[15px] font-semibold text-gray-900">HubSpot field</th>
                <th className="text-left p-4 text-[15px] font-semibold text-gray-900">Type</th>
                <th className="text-left p-4 text-[15px] font-semibold text-gray-900">Required</th>
                <th className="text-left p-4 text-[15px] font-semibold text-gray-900"></th>
              </tr>
            </thead>
            <tbody>
              {filteredMappings.map((mapping) => (
                <tr key={mapping.id} className="border-b border-gray-200 last:border-0">
                  <td className="p-4 font-mono text-sm text-gray-900">{mapping.local_field}</td>
                  <td className="p-4 font-mono text-sm text-gray-600">{mapping.hubspot_field}</td>
                  <td className="p-4 text-sm text-gray-600">{mapping.field_type}</td>
                  <td className="p-4 text-sm">{mapping.is_required ? '✓' : '—'}</td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => deleteMappingMutation.mutate(mapping.id)}
                      className="text-gray-400 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}