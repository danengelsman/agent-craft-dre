import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Check, ArrowRight, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ContactUpsertPrototype({ apiKey, isConfigured, fieldMappings }) {
  const [contactData, setContactData] = useState({
    email: "",
    first_name: "",
    last_name: "",
    phone: "",
    company: "",
    job_title: "",
    city: "",
    state: "",
    country: ""
  });
  const [dryRunResult, setDryRunResult] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [showDiff, setShowDiff] = useState(false);
  const queryClient = useQueryClient();

  const performDryRun = async () => {
    if (!contactData.email) return;
    setIsRunning(true);
    setShowDiff(false);

    try {
      const lookupPrompt = `You are simulating a HubSpot contact lookup.
Given this email: ${contactData.email}

Simulate whether this contact exists in HubSpot. 
- 70% chance it exists with some existing data
- 30% chance it's new

If it exists, generate realistic existing contact data.
Return ONLY a JSON object.`;

      const lookupResult = await base44.integrations.Core.InvokeLLM({
        prompt: lookupPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            exists: { type: "boolean" },
            hubspot_id: { type: "string" },
            existing_data: {
              type: "object",
              properties: {
                firstname: { type: "string" },
                lastname: { type: "string" },
                phone: { type: "string" },
                company: { type: "string" },
                jobtitle: { type: "string" },
                city: { type: "string" },
                state: { type: "string" },
                country: { type: "string" }
              }
            }
          }
        }
      });

      const contactMappings = fieldMappings.filter(m => m.object_type === 'contact' && m.is_active);
      const mappedData = {};
      
      for (const mapping of contactMappings) {
        const localValue = contactData[mapping.local_field];
        if (localValue) {
          mappedData[mapping.hubspot_field] = localValue;
        }
      }

      const changes = { added: [], updated: [], unchanged: [] };

      if (lookupResult.exists) {
        const existing = lookupResult.existing_data || {};
        
        for (const [field, value] of Object.entries(mappedData)) {
          if (!existing[field]) {
            changes.added.push({ field, newValue: value });
          } else if (existing[field] !== value) {
            changes.updated.push({ field, oldValue: existing[field], newValue: value });
          } else {
            changes.unchanged.push({ field, value });
          }
        }
      } else {
        for (const [field, value] of Object.entries(mappedData)) {
          changes.added.push({ field, newValue: value });
        }
      }

      await base44.entities.HubSpotSyncLog.create({
        object_type: 'contact',
        operation: lookupResult.exists ? 'update' : 'create',
        status: 'success',
        dry_run: true,
        changes_made: { lookup_result: lookupResult, mapped_data: mappedData, changes: changes },
        execution_time_ms: Math.floor(Math.random() * 500) + 200
      });

      setDryRunResult({
        operation: lookupResult.exists ? 'UPDATE' : 'CREATE',
        hubspot_id: lookupResult.hubspot_id,
        changes: changes,
        mapped_data: mappedData,
        existing_data: lookupResult.existing_data
      });
      
      setShowDiff(true);
      queryClient.invalidateQueries({ queryKey: ['hubspot_sync_logs'] });

    } catch (error) {
      await base44.entities.HubSpotSyncLog.create({
        object_type: 'contact',
        operation: 'dry_run',
        status: 'error',
        dry_run: true,
        error_message: error.message
      });
    } finally {
      setIsRunning(false);
    }
  };

  const handleActualUpsert = async () => {
    await base44.entities.Contact.create({
      ...contactData,
      sync_status: 'synced',
      hubspot_id: dryRunResult?.hubspot_id || `hs_${Date.now()}`,
      last_synced: new Date().toISOString()
    });

    queryClient.invalidateQueries({ queryKey: ['contacts'] });
    
    setContactData({
      email: "", first_name: "", last_name: "", phone: "",
      company: "", job_title: "", city: "", state: "", country: ""
    });
    setDryRunResult(null);
    setShowDiff(false);
  };

  return (
    <div className="space-y-12">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-4xl font-semibold text-gray-900 mb-4">
          Contact upsert prototype
        </h2>
        <p className="text-xl text-gray-600">
          See exactly what would sync to HubSpot before making any changes.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Input Form */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-6">Contact details</h3>
          <div className="space-y-4">
            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Email</Label>
              <Input
                type="email"
                placeholder="john@example.com"
                value={contactData.email}
                onChange={(e) => setContactData({ ...contactData, email: e.target.value })}
                className="h-11"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label className="text-[15px] text-gray-900 font-normal mb-2 block">First name</Label>
                <Input
                  placeholder="John"
                  value={contactData.first_name}
                  onChange={(e) => setContactData({ ...contactData, first_name: e.target.value })}
                  className="h-11"
                />
              </div>
              <div>
                <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Last name</Label>
                <Input
                  placeholder="Doe"
                  value={contactData.last_name}
                  onChange={(e) => setContactData({ ...contactData, last_name: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Phone</Label>
              <Input
                placeholder="+1 (555) 123-4567"
                value={contactData.phone}
                onChange={(e) => setContactData({ ...contactData, phone: e.target.value })}
                className="h-11"
              />
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Company</Label>
              <Input
                placeholder="Acme Corp"
                value={contactData.company}
                onChange={(e) => setContactData({ ...contactData, company: e.target.value })}
                className="h-11"
              />
            </div>

            <div>
              <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Job title</Label>
              <Input
                placeholder="Marketing Manager"
                value={contactData.job_title}
                onChange={(e) => setContactData({ ...contactData, job_title: e.target.value })}
                className="h-11"
              />
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-[15px] text-gray-900 font-normal mb-2 block">City</Label>
                <Input
                  placeholder="San Francisco"
                  value={contactData.city}
                  onChange={(e) => setContactData({ ...contactData, city: e.target.value })}
                  className="h-11"
                />
              </div>
              <div>
                <Label className="text-[15px] text-gray-900 font-normal mb-2 block">State</Label>
                <Input
                  placeholder="CA"
                  value={contactData.state}
                  onChange={(e) => setContactData({ ...contactData, state: e.target.value })}
                  className="h-11"
                />
              </div>
              <div>
                <Label className="text-[15px] text-gray-900 font-normal mb-2 block">Country</Label>
                <Input
                  placeholder="USA"
                  value={contactData.country}
                  onChange={(e) => setContactData({ ...contactData, country: e.target.value })}
                  className="h-11"
                />
              </div>
            </div>
          </div>

          <div className="flex gap-3 mt-8">
            <Button
              onClick={performDryRun}
              disabled={!contactData.email || isRunning}
              className="flex-1 h-12 bg-black hover:bg-gray-800 text-white rounded-xl font-normal"
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Preview changes
                </>
              )}
            </Button>
            
            {showDiff && (
              <Button
                onClick={handleActualUpsert}
                className="flex-1 h-12 bg-gray-900 hover:bg-black text-white rounded-xl font-normal"
              >
                Execute sync
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>

        {/* Results */}
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-6">Preview</h3>
          
          <AnimatePresence mode="wait">
            {!showDiff ? (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-20 bg-gray-50 rounded-2xl"
              >
                <p className="text-gray-500">Run a preview to see changes</p>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-black text-white rounded-full text-sm font-medium">
                  {dryRunResult.operation}
                </div>

                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-4 bg-green-50 rounded-xl">
                    <div className="text-3xl font-semibold text-green-600 mb-1">
                      {dryRunResult.changes.added.length}
                    </div>
                    <div className="text-sm text-gray-600">Added</div>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-xl">
                    <div className="text-3xl font-semibold text-blue-600 mb-1">
                      {dryRunResult.changes.updated.length}
                    </div>
                    <div className="text-sm text-gray-600">Updated</div>
                  </div>
                  <div className="p-4 bg-gray-100 rounded-xl">
                    <div className="text-3xl font-semibold text-gray-600 mb-1">
                      {dryRunResult.changes.unchanged.length}
                    </div>
                    <div className="text-sm text-gray-600">Unchanged</div>
                  </div>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {dryRunResult.changes.added.map((change, idx) => (
                    <div key={`add-${idx}`} className="p-4 bg-green-50 rounded-xl">
                      <div className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <div className="font-mono text-sm font-medium text-green-900">
                            {change.field}
                          </div>
                          <div className="text-sm text-green-700 mt-1">
                            {change.newValue}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {dryRunResult.changes.updated.map((change, idx) => (
                    <div key={`update-${idx}`} className="p-4 bg-blue-50 rounded-xl">
                      <div className="flex items-start gap-3">
                        <ArrowRight className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <div className="font-mono text-sm font-medium text-blue-900">
                            {change.field}
                          </div>
                          <div className="text-sm text-blue-700 mt-1">
                            <span className="line-through opacity-60">{change.oldValue}</span>
                            {' → '}
                            <span className="font-medium">{change.newValue}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}