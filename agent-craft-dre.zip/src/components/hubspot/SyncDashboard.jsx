import { CheckCircle2, XCircle, Clock, Eye } from "lucide-react";
import { format } from "date-fns";

const STATUS_CONFIG = {
  success: { icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50' },
  error: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
  pending: { icon: Clock, color: 'text-blue-600', bg: 'bg-blue-50' },
  skipped: { icon: XCircle, color: 'text-gray-600', bg: 'bg-gray-50' }
};

export default function SyncDashboard({ syncLogs }) {
  if (syncLogs.length === 0) {
    return (
      <div className="text-center py-20">
        <p className="text-xl text-gray-600">No activity yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-semibold text-gray-900">Activity log</h2>
      
      <div className="space-y-3">
        {syncLogs.map((log) => {
          const statusConfig = STATUS_CONFIG[log.status];
          const StatusIcon = statusConfig.icon;

          return (
            <div
              key={log.id}
              className={`p-6 rounded-2xl ${statusConfig.bg}`}
            >
              <div className="flex items-start gap-4">
                <StatusIcon className={`w-5 h-5 ${statusConfig.color} flex-shrink-0 mt-1`} />
                
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-semibold text-gray-900 capitalize">
                      {log.operation}
                    </span>
                    <span className="text-gray-400">•</span>
                    <span className="text-sm text-gray-600 capitalize">
                      {log.object_type}
                    </span>
                    {log.dry_run && (
                      <span className="px-2 py-0.5 bg-white rounded-full text-xs font-medium text-gray-700">
                        Dry run
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>{format(new Date(log.created_date), 'MMM d, h:mm a')}</span>
                    {log.execution_time_ms && (
                      <>
                        <span>•</span>
                        <span>{log.execution_time_ms}ms</span>
                      </>
                    )}
                  </div>

                  {log.error_message && (
                    <div className="mt-3 p-3 bg-red-100 rounded-xl text-sm text-red-800">
                      {log.error_message}
                    </div>
                  )}

                  {log.changes_made && Object.keys(log.changes_made).length > 0 && (
                    <details className="mt-3">
                      <summary className="text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                        View details
                      </summary>
                      <pre className="mt-2 p-3 bg-white rounded-xl text-xs overflow-x-auto">
                        {JSON.stringify(log.changes_made, null, 2)}
                      </pre>
                    </details>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}