import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: onboardingProgress, isLoading: isLoadingOnboarding } = useQuery({
    queryKey: ['onboardingProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existing = await base44.entities.OnboardingProgress.filter({ 
        user_email: user.email 
      });
      return existing[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    staleTime: 300000,
  });

  const isLoading = isLoadingUser || isLoadingOnboarding;
  const isAuthenticated = !!user;
  const hasCompletedOnboarding = onboardingProgress?.has_completed_onboarding || false;

  return {
    isLoading,
    isAuthenticated,
    user: user ? { ...user, hasCompletedOnboarding } : null,
  };
}