import { useState } from "react";
import { HelpCircle, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const HELP_CONTENT = {
  // Builder
  agent_name: {
    title: "Agent Name",
    content: "Choose a memorable name for your agent. This is how users will identify and interact with your AI assistant."
  },
  agent_description: {
    title: "Description",
    content: "Describe what your agent does. This helps users understand its capabilities and when to use it."
  },
  personality: {
    title: "Personality",
    content: "Choose how your agent communicates. Professional is formal and business-focused, while Friendly is more casual and approachable."
  },
  abilities: {
    title: "Abilities",
    content: "Abilities are the superpowers your agent has. Each ability enables specific functionality like web search, email integration, or data analysis."
  },
  
  // Marketplace
  marketplace_pricing: {
    title: "Pricing Your Agent",
    content: "Set a fair price for your agent. Free agents get more downloads but paid agents earn you revenue. You keep 85% of each sale!"
  },
  marketplace_certification: {
    title: "Certification",
    content: "Certified agents have been reviewed for quality and reliability. Premium certification indicates top-tier, enterprise-ready agents."
  },
  
  // Monetization
  revenue_share: {
    title: "Revenue Share",
    content: "When someone purchases your agent, you receive 85% of the sale price. The remaining 15% covers platform fees and payment processing."
  },
  payout: {
    title: "Payouts",
    content: "Once your balance reaches $25, you can request a payout. Payments are processed within 3-5 business days via Stripe."
  },
  
  // Workflows
  workflow_trigger: {
    title: "Triggers",
    content: "Triggers start your workflow. Options include manual triggers, scheduled runs, webhooks from external services, or events from your agents."
  },
  workflow_nodes: {
    title: "Workflow Nodes",
    content: "Nodes are the steps in your workflow. Connect agents, actions, conditions, and delays to create powerful automations."
  },
  
  // API
  api_key: {
    title: "API Keys",
    content: "API keys authenticate your requests to the AgentCraft API. Keep them secure and never share them publicly."
  },
  api_scopes: {
    title: "Scopes",
    content: "Scopes control what your API key can access. Only grant the permissions you need for security."
  },
  webhooks: {
    title: "Webhooks",
    content: "Webhooks send real-time notifications to your server when events occur, like agent executions or purchases."
  }
};

export default function ContextualHelp({ helpKey, position = "top" }) {
  const [isOpen, setIsOpen] = useState(false);
  
  const help = HELP_CONTENT[helpKey];
  if (!help) return null;
  
  const positionClasses = {
    top: "bottom-full left-1/2 -translate-x-1/2 mb-2",
    bottom: "top-full left-1/2 -translate-x-1/2 mt-2",
    left: "right-full top-1/2 -translate-y-1/2 mr-2",
    right: "left-full top-1/2 -translate-y-1/2 ml-2"
  };
  
  return (
    <div className="relative inline-block">
      <button
        onClick={() => setIsOpen(!isOpen)}
        onMouseEnter={() => setIsOpen(true)}
        onMouseLeave={() => setIsOpen(false)}
        className="p-1 text-gray-400 hover:text-purple-600 transition-colors"
        aria-label="Help"
      >
        <HelpCircle className="w-4 h-4" />
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className={`absolute z-50 ${positionClasses[position]}`}
          >
            <div className="bg-gray-900 text-white rounded-xl p-4 shadow-xl w-64">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-semibold text-sm">{help.title}</h4>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
              <p className="text-xs text-gray-300 leading-relaxed">
                {help.content}
              </p>
              <div className="absolute w-3 h-3 bg-gray-900 transform rotate-45"
                style={{
                  ...(position === "top" && { bottom: "-6px", left: "50%", marginLeft: "-6px" }),
                  ...(position === "bottom" && { top: "-6px", left: "50%", marginLeft: "-6px" }),
                  ...(position === "left" && { right: "-6px", top: "50%", marginTop: "-6px" }),
                  ...(position === "right" && { left: "-6px", top: "50%", marginTop: "-6px" }),
                }}
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}