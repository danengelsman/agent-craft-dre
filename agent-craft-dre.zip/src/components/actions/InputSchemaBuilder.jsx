import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";
import { Card } from "@/components/ui/Card";
import { Plus, Trash2, Check } from "lucide-react";

export default function InputSchemaBuilder({ schema, onChange }) {
  const properties = schema?.properties || {};
  const required = schema?.required || [];

  const addProperty = () => {
    const newPropName = `field_${Object.keys(properties).length + 1}`;
    onChange({
      ...schema,
      properties: {
        ...properties,
        [newPropName]: { type: "string", description: "" }
      }
    });
  };

  const removeProperty = (propName) => {
    const newProps = { ...properties };
    delete newProps[propName];
    const newRequired = required.filter(r => r !== propName);
    onChange({
      ...schema,
      properties: newProps,
      required: newRequired
    });
  };

  const updateProperty = (propName, field, value) => {
    onChange({
      ...schema,
      properties: {
        ...properties,
        [propName]: {
          ...properties[propName],
          [field]: value
        }
      }
    });
  };

  const renameProperty = (oldName, newName) => {
    if (oldName === newName || !newName.trim()) return;
    const newProps = {};
    Object.keys(properties).forEach(key => {
      if (key === oldName) {
        newProps[newName] = properties[key];
      } else {
        newProps[key] = properties[key];
      }
    });
    const newRequired = required.map(r => r === oldName ? newName : r);
    onChange({
      ...schema,
      properties: newProps,
      required: newRequired
    });
  };

  const toggleRequired = (propName) => {
    const isRequired = required.includes(propName);
    onChange({
      ...schema,
      required: isRequired 
        ? required.filter(r => r !== propName)
        : [...required, propName]
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label>Input Parameters</Label>
        <Button onClick={addProperty} size="sm" variant="outline">
          <Plus className="w-4 h-4 mr-1" />
          Add Field
        </Button>
      </div>

      {Object.keys(properties).length === 0 ? (
        <Card className="p-6 text-center text-sm text-gray-500">
          No input fields defined yet. Click "Add Field" to start.
        </Card>
      ) : (
        <div className="space-y-3">
          {Object.entries(properties).map(([propName, propConfig]) => (
            <Card key={propName} className="p-4">
              <div className="grid grid-cols-12 gap-3 items-start">
                <div className="col-span-3">
                  <Label className="text-xs">Field Name</Label>
                  <Input
                    value={propName}
                    onChange={e => renameProperty(propName, e.target.value)}
                    placeholder="fieldName"
                    className="mt-1 text-sm"
                  />
                </div>

                <div className="col-span-2">
                  <Label className="text-xs">Type</Label>
                  <Select 
                    value={propConfig.type} 
                    onValueChange={v => updateProperty(propName, 'type', v)}
                  >
                    <SelectTrigger className="mt-1 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="string">String</SelectItem>
                      <SelectItem value="number">Number</SelectItem>
                      <SelectItem value="boolean">Boolean</SelectItem>
                      <SelectItem value="array">Array</SelectItem>
                      <SelectItem value="object">Object</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="col-span-5">
                  <Label className="text-xs">Description</Label>
                  <Input
                    value={propConfig.description || ''}
                    onChange={e => updateProperty(propName, 'description', e.target.value)}
                    placeholder="What is this field for?"
                    className="mt-1 text-sm"
                  />
                </div>

                <div className="col-span-1 flex items-end justify-center">
                  <Button
                    onClick={() => toggleRequired(propName)}
                    size="sm"
                    variant={required.includes(propName) ? "primary" : "outline"}
                    className="w-full"
                    title="Required field"
                  >
                    <Check className="w-4 h-4" />
                  </Button>
                </div>

                <div className="col-span-1 flex items-end justify-center">
                  <Button
                    onClick={() => removeProperty(propName)}
                    size="sm"
                    variant="ghost"
                    className="text-red-600 w-full"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {Object.keys(properties).length > 0 && (
        <p className="text-xs text-gray-500">
          ✓ = Required field. Agent must provide this value when executing the action.
        </p>
      )}
    </div>
  );
}