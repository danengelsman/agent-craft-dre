import { motion } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { X, Zap, Copy } from "lucide-react";

const ACTION_TYPES = [
  { id: 'send_email', name: 'Send Email' },
  { id: 'http_request', name: 'HTTP Request' },
  { id: 'slack_message', name: 'Slack Message' },
  { id: 'calendar_event', name: 'Calendar Event' },
  { id: 'database_query', name: 'Database Query' },
  { id: 'custom_function', name: 'Custom Function' }
];

export default function TemplatePreviewModal({ template, onClose, onUse }) {
  const typeInfo = ACTION_TYPES.find(t => t.id === template.action_type);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1">{template.name}</h2>
            <p className="text-gray-600">{template.description}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="space-y-6">
          <div className="flex gap-3">
            <div className="px-3 py-1 bg-gray-100 rounded-full text-sm font-medium">
              {typeInfo?.name || template.action_type}
            </div>
            <div className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium capitalize">
              {template.category}
            </div>
          </div>

          {template.input_schema?.properties && Object.keys(template.input_schema.properties).length > 0 && (
            <Card className="p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Input Parameters
              </h3>
              <div className="space-y-3">
                {Object.entries(template.input_schema.properties).map(([key, prop]) => (
                  <div key={key} className="flex justify-between items-start">
                    <div>
                      <span className="font-mono text-sm font-medium">{key}</span>
                      {template.input_schema.required?.includes(key) && (
                        <span className="text-red-500 ml-1">*</span>
                      )}
                      <p className="text-sm text-gray-600 mt-0.5">{prop.description}</p>
                    </div>
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded">{prop.type}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card className="p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Copy className="w-4 h-4" />
              Configuration Preview
            </h3>
            <pre className="bg-gray-50 p-3 rounded-lg text-xs overflow-auto max-h-64 font-mono">
              {JSON.stringify(template.config, null, 2)}
            </pre>
          </Card>
        </div>

        <div className="flex gap-3 mt-6 pt-6 border-t">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button 
            onClick={() => onUse(template)}
            className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500"
          >
            Use This Template
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}