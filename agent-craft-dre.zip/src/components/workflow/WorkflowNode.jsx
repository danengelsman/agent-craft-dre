import { memo } from "react";
import { Card } from "@/components/ui/card";
import { 
  Play, Bot, Zap, GitBranch, Clock, Square,
  GripVertical, Trash2, Settings
} from "lucide-react";

const NODE_CONFIGS = {
  trigger: {
    label: "Trigger",
    icon: Play,
    color: "bg-green-500",
    borderColor: "border-green-500"
  },
  agent: {
    label: "Agent",
    icon: Bot,
    color: "bg-purple-500",
    borderColor: "border-purple-500"
  },
  action: {
    label: "Action",
    icon: Zap,
    color: "bg-amber-500",
    borderColor: "border-amber-500"
  },
  condition: {
    label: "Condition",
    icon: GitBranch,
    color: "bg-blue-500",
    borderColor: "border-blue-500"
  },
  delay: {
    label: "Delay",
    icon: Clock,
    color: "bg-gray-500",
    borderColor: "border-gray-500"
  },
  end: {
    label: "End",
    icon: Square,
    color: "bg-red-500",
    borderColor: "border-red-500"
  }
};

function WorkflowNode({ 
  node, 
  isSelected, 
  onSelect, 
  onDelete, 
  onConfigure,
  isDragging 
}) {
  const config = NODE_CONFIGS[node.type] || NODE_CONFIGS.action;
  const Icon = config.icon;

  return (
    <div
      className={`absolute cursor-pointer transition-all ${
        isDragging ? 'opacity-50' : ''
      }`}
      style={{
        left: node.position?.x || 0,
        top: node.position?.y || 0,
        transform: isSelected ? 'scale(1.02)' : 'scale(1)'
      }}
      onClick={() => onSelect(node.id)}
    >
      <Card 
        className={`w-48 overflow-hidden border-2 ${
          isSelected ? config.borderColor : 'border-gray-200'
        } ${isSelected ? 'shadow-lg' : 'shadow-sm'}`}
      >
        {/* Header */}
        <div className={`${config.color} px-3 py-2 flex items-center justify-between`}>
          <div className="flex items-center gap-2">
            <GripVertical className="w-3 h-3 text-white/70 cursor-grab" />
            <Icon className="w-4 h-4 text-white" />
            <span className="text-white text-xs font-semibold">{config.label}</span>
          </div>
          {isSelected && (
            <div className="flex items-center gap-1">
              <button
                onClick={(e) => { e.stopPropagation(); onConfigure(node); }}
                className="p-1 hover:bg-white/20 rounded"
              >
                <Settings className="w-3 h-3 text-white" />
              </button>
              {node.type !== 'trigger' && (
                <button
                  onClick={(e) => { e.stopPropagation(); onDelete(node.id); }}
                  className="p-1 hover:bg-white/20 rounded"
                >
                  <Trash2 className="w-3 h-3 text-white" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-3 bg-white">
          <p className="text-sm font-medium text-gray-900 truncate">
            {node.data?.name || node.data?.label || `${config.label} Node`}
          </p>
          {node.data?.description && (
            <p className="text-xs text-gray-500 truncate mt-1">
              {node.data.description}
            </p>
          )}
        </div>

        {/* Connection Points */}
        {node.type !== 'end' && (
          <div 
            className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-gray-300 border-2 border-white cursor-pointer hover:bg-gray-400"
            title="Connect to next node"
          />
        )}
        {node.type !== 'trigger' && (
          <div 
            className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-gray-300 border-2 border-white"
          />
        )}
      </Card>
    </div>
  );
}

export default memo(WorkflowNode);