import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Zap, Mail, Calendar, Database, MessageSquare, FileText, 
  TrendingUp, Users, ShoppingCart, Bell, Clock, ArrowRight,
  Copy, Check, Star, Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";

const WORKFLOW_TEMPLATES = [
  {
    id: "customer_support_escalation",
    name: "Customer Support Escalation",
    description: "Automatically escalate tickets based on sentiment and priority, notify team leads",
    category: "Customer Service",
    icon: MessageSquare,
    color: "from-blue-500 to-cyan-500",
    difficulty: "beginner",
    estimatedTime: "5 min",
    popular: true,
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "webhook", label: "New Ticket" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 100 }, data: { agent_name: "Sentiment Analyzer", task: "Analyze customer sentiment" } },
      { id: "condition1", type: "condition", position: { x: 500, y: 100 }, data: { condition: "sentiment < 0.3", label: "Is Negative?" } },
      { id: "action1", type: "action", position: { x: 700, y: 50 }, data: { action_type: "send_email", label: "Alert Team Lead" } },
      { id: "action2", type: "action", position: { x: 700, y: 150 }, data: { action_type: "slack_message", label: "Log to Slack" } },
      { id: "end", type: "end", position: { x: 900, y: 100 }, data: {} }
    ],
    tags: ["support", "automation", "alerts"]
  },
  {
    id: "lead_qualification",
    name: "AI Lead Qualification",
    description: "Score and qualify leads automatically, route to appropriate sales reps",
    category: "Sales",
    icon: TrendingUp,
    color: "from-green-500 to-emerald-500",
    difficulty: "intermediate",
    estimatedTime: "10 min",
    popular: true,
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "event", label: "New Lead" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 100 }, data: { agent_name: "Lead Scorer", task: "Analyze lead data and score" } },
      { id: "condition1", type: "condition", position: { x: 500, y: 100 }, data: { condition: "score >= 80", label: "Hot Lead?" } },
      { id: "action1", type: "action", position: { x: 700, y: 50 }, data: { action_type: "calendar_event", label: "Schedule Call" } },
      { id: "delay1", type: "delay", position: { x: 700, y: 150 }, data: { delay: "24h", label: "Wait 24h" } },
      { id: "action2", type: "action", position: { x: 900, y: 150 }, data: { action_type: "send_email", label: "Nurture Email" } },
      { id: "end", type: "end", position: { x: 1100, y: 100 }, data: {} }
    ],
    tags: ["sales", "leads", "crm"]
  },
  {
    id: "content_pipeline",
    name: "Content Creation Pipeline",
    description: "Generate, review, and schedule content across multiple channels",
    category: "Marketing",
    icon: FileText,
    color: "from-purple-500 to-pink-500",
    difficulty: "intermediate",
    estimatedTime: "15 min",
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "schedule", label: "Weekly Trigger" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 100 }, data: { agent_name: "Content Writer", task: "Generate blog post draft" } },
      { id: "agent2", type: "agent", position: { x: 500, y: 100 }, data: { agent_name: "Editor", task: "Review and improve content" } },
      { id: "agent3", type: "agent", position: { x: 700, y: 100 }, data: { agent_name: "Social Media Manager", task: "Create social posts" } },
      { id: "action1", type: "action", position: { x: 900, y: 50 }, data: { action_type: "http_request", label: "Publish Blog" } },
      { id: "action2", type: "action", position: { x: 900, y: 150 }, data: { action_type: "http_request", label: "Schedule Social" } },
      { id: "end", type: "end", position: { x: 1100, y: 100 }, data: {} }
    ],
    tags: ["content", "marketing", "social"]
  },
  {
    id: "daily_briefing",
    name: "Executive Daily Briefing",
    description: "Compile news, metrics, and priorities into a personalized morning briefing",
    category: "Productivity",
    icon: Bell,
    color: "from-amber-500 to-orange-500",
    difficulty: "beginner",
    estimatedTime: "5 min",
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "schedule", label: "7 AM Daily" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 50 }, data: { agent_name: "News Curator", task: "Gather relevant news" } },
      { id: "agent2", type: "agent", position: { x: 300, y: 150 }, data: { agent_name: "Metrics Analyst", task: "Pull key metrics" } },
      { id: "agent3", type: "agent", position: { x: 500, y: 100 }, data: { agent_name: "Briefing Compiler", task: "Create executive summary" } },
      { id: "action1", type: "action", position: { x: 700, y: 100 }, data: { action_type: "send_email", label: "Send Briefing" } },
      { id: "end", type: "end", position: { x: 900, y: 100 }, data: {} }
    ],
    tags: ["productivity", "daily", "reports"]
  },
  {
    id: "meeting_assistant",
    name: "Smart Meeting Assistant",
    description: "Prepare agendas, take notes, and follow up on action items automatically",
    category: "Productivity",
    icon: Calendar,
    color: "from-indigo-500 to-violet-500",
    difficulty: "advanced",
    estimatedTime: "20 min",
    popular: true,
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "event", label: "Meeting Start" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 100 }, data: { agent_name: "Agenda Builder", task: "Compile agenda from docs" } },
      { id: "action1", type: "action", position: { x: 500, y: 100 }, data: { action_type: "slack_message", label: "Share Agenda" } },
      { id: "delay1", type: "delay", position: { x: 700, y: 100 }, data: { delay: "meeting_end", label: "Wait for End" } },
      { id: "agent2", type: "agent", position: { x: 900, y: 100 }, data: { agent_name: "Note Taker", task: "Summarize discussion" } },
      { id: "agent3", type: "agent", position: { x: 1100, y: 100 }, data: { agent_name: "Task Extractor", task: "Extract action items" } },
      { id: "action2", type: "action", position: { x: 1300, y: 100 }, data: { action_type: "send_email", label: "Send Follow-up" } },
      { id: "end", type: "end", position: { x: 1500, y: 100 }, data: {} }
    ],
    tags: ["meetings", "notes", "follow-up"]
  },
  {
    id: "data_enrichment",
    name: "Contact Data Enrichment",
    description: "Automatically enrich new contacts with company info, social profiles, and insights",
    category: "Data",
    icon: Database,
    color: "from-teal-500 to-cyan-500",
    difficulty: "intermediate",
    estimatedTime: "10 min",
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "event", label: "New Contact" } },
      { id: "agent1", type: "agent", position: { x: 300, y: 100 }, data: { agent_name: "Data Researcher", task: "Find company info" } },
      { id: "agent2", type: "agent", position: { x: 500, y: 100 }, data: { agent_name: "Social Finder", task: "Find social profiles" } },
      { id: "action1", type: "action", position: { x: 700, y: 100 }, data: { action_type: "database_query", label: "Update Contact" } },
      { id: "condition1", type: "condition", position: { x: 900, y: 100 }, data: { condition: "is_high_value", label: "High Value?" } },
      { id: "action2", type: "action", position: { x: 1100, y: 50 }, data: { action_type: "slack_message", label: "Alert Sales" } },
      { id: "end", type: "end", position: { x: 1100, y: 150 }, data: {} }
    ],
    tags: ["data", "crm", "enrichment"]
  },
  {
    id: "order_processing",
    name: "E-commerce Order Flow",
    description: "Process orders, check inventory, send confirmations, and handle fulfillment",
    category: "E-commerce",
    icon: ShoppingCart,
    color: "from-rose-500 to-red-500",
    difficulty: "advanced",
    estimatedTime: "25 min",
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "webhook", label: "New Order" } },
      { id: "action1", type: "action", position: { x: 300, y: 100 }, data: { action_type: "database_query", label: "Check Inventory" } },
      { id: "condition1", type: "condition", position: { x: 500, y: 100 }, data: { condition: "in_stock", label: "In Stock?" } },
      { id: "agent1", type: "agent", position: { x: 700, y: 50 }, data: { agent_name: "Fulfillment Agent", task: "Process shipment" } },
      { id: "action2", type: "action", position: { x: 700, y: 150 }, data: { action_type: "send_email", label: "Backorder Notice" } },
      { id: "action3", type: "action", position: { x: 900, y: 50 }, data: { action_type: "send_email", label: "Shipping Confirm" } },
      { id: "end", type: "end", position: { x: 1100, y: 100 }, data: {} }
    ],
    tags: ["ecommerce", "orders", "fulfillment"]
  },
  {
    id: "onboarding_sequence",
    name: "Customer Onboarding",
    description: "Guide new customers through setup with personalized emails and check-ins",
    category: "Customer Success",
    icon: Users,
    color: "from-sky-500 to-blue-500",
    difficulty: "intermediate",
    estimatedTime: "15 min",
    nodes: [
      { id: "trigger", type: "trigger", position: { x: 100, y: 100 }, data: { trigger_type: "event", label: "New Signup" } },
      { id: "action1", type: "action", position: { x: 300, y: 100 }, data: { action_type: "send_email", label: "Welcome Email" } },
      { id: "delay1", type: "delay", position: { x: 500, y: 100 }, data: { delay: "24h", label: "Wait 1 Day" } },
      { id: "agent1", type: "agent", position: { x: 700, y: 100 }, data: { agent_name: "Onboarding Guide", task: "Check progress, personalize tips" } },
      { id: "action2", type: "action", position: { x: 900, y: 100 }, data: { action_type: "send_email", label: "Tips Email" } },
      { id: "delay2", type: "delay", position: { x: 1100, y: 100 }, data: { delay: "3d", label: "Wait 3 Days" } },
      { id: "condition1", type: "condition", position: { x: 1300, y: 100 }, data: { condition: "is_active", label: "Is Active?" } },
      { id: "action3", type: "action", position: { x: 1500, y: 50 }, data: { action_type: "calendar_event", label: "Schedule Call" } },
      { id: "action4", type: "action", position: { x: 1500, y: 150 }, data: { action_type: "send_email", label: "Re-engage" } },
      { id: "end", type: "end", position: { x: 1700, y: 100 }, data: {} }
    ],
    tags: ["onboarding", "customer", "automation"]
  }
];

const DIFFICULTY_CONFIG = {
  beginner: { label: "Beginner", color: "bg-green-100 text-green-700" },
  intermediate: { label: "Intermediate", color: "bg-amber-100 text-amber-700" },
  advanced: { label: "Advanced", color: "bg-red-100 text-red-700" }
};

const CATEGORIES = ["All", "Customer Service", "Sales", "Marketing", "Productivity", "Data", "E-commerce", "Customer Success"];

export default function WorkflowTemplates({ onUseTemplate }) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [copiedId, setCopiedId] = useState(null);

  const filteredTemplates = WORKFLOW_TEMPLATES.filter(t => 
    selectedCategory === "All" || t.category === selectedCategory
  );

  const handleUseTemplate = (template) => {
    setCopiedId(template.id);
    setTimeout(() => setCopiedId(null), 2000);
    onUseTemplate(template);
  };

  return (
    <div>
      {/* Category Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {CATEGORIES.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
              selectedCategory === category
                ? 'bg-gray-900 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map((template, index) => {
          const Icon = template.icon;
          const diffConfig = DIFFICULTY_CONFIG[template.difficulty];

          return (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl border border-gray-200 p-5 hover:shadow-lg transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center gap-2">
                  {template.popular && (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-medium">
                      <Star className="w-3 h-3" />
                      Popular
                    </span>
                  )}
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${diffConfig.color}`}>
                    {diffConfig.label}
                  </span>
                </div>
              </div>

              <h3 className="font-bold text-gray-900 mb-1">{template.name}</h3>
              <p className="text-sm text-gray-600 mb-3 line-clamp-2">{template.description}</p>

              <div className="flex flex-wrap gap-1 mb-4">
                {template.tags.map(tag => (
                  <span key={tag} className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 text-xs">
                    {tag}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <div className="flex items-center gap-3 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Zap className="w-3 h-3" />
                    {template.nodes.length} nodes
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {template.estimatedTime}
                  </span>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleUseTemplate(template)}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  {copiedId === template.id ? (
                    <>
                      <Check className="w-3 h-3 mr-1" />
                      Added!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3 mr-1" />
                      Use Template
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}