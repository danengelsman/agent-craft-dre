import { useState, useRef, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Plus, Play, Bot, Zap, GitBranch, Clock, Square,
  ZoomIn, ZoomOut, Maximize2, Save, Trash2
} from "lucide-react";
import WorkflowNode from "./WorkflowNode";
import NodeConfigModal from "./NodeConfigModal";

const NODE_TYPES = [
  { type: 'agent', label: 'Agent', icon: Bot, color: 'bg-purple-500' },
  { type: 'action', label: 'Action', icon: Zap, color: 'bg-amber-500' },
  { type: 'condition', label: 'Condition', icon: GitBranch, color: 'bg-blue-500' },
  { type: 'delay', label: 'Delay', icon: Clock, color: 'bg-gray-500' },
  { type: 'end', label: 'End', icon: Square, color: 'bg-red-500' }
];

export default function WorkflowCanvas({ 
  nodes = [], 
  onNodesChange, 
  onSave,
  isSaving 
}) {
  const canvasRef = useRef(null);
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const [configNode, setConfigNode] = useState(null);
  const [zoom, setZoom] = useState(1);
  const [draggedNode, setDraggedNode] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  // Initialize with trigger node if empty
  const currentNodes = nodes.length === 0 ? [{
    id: 'trigger-1',
    type: 'trigger',
    position: { x: 300, y: 50 },
    data: { label: 'Start', type: 'manual' },
    connections: []
  }] : nodes;

  const handleAddNode = (type) => {
    const newNode = {
      id: `${type}-${Date.now()}`,
      type,
      position: { x: 300, y: (currentNodes.length * 120) + 50 },
      data: { label: `New ${type}`, name: '' },
      connections: []
    };

    const updatedNodes = [...currentNodes, newNode];
    
    // Auto-connect to previous node
    if (currentNodes.length > 0) {
      const lastNode = currentNodes[currentNodes.length - 1];
      if (lastNode.type !== 'end') {
        updatedNodes[currentNodes.length - 1] = {
          ...lastNode,
          connections: [...(lastNode.connections || []), newNode.id]
        };
      }
    }

    onNodesChange(updatedNodes);
    setSelectedNodeId(newNode.id);
  };

  const handleDeleteNode = (nodeId) => {
    const updatedNodes = currentNodes
      .filter(n => n.id !== nodeId)
      .map(n => ({
        ...n,
        connections: (n.connections || []).filter(c => c !== nodeId)
      }));
    onNodesChange(updatedNodes);
    setSelectedNodeId(null);
  };

  const handleNodeDragStart = (e, node) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    setDraggedNode(node.id);
  };

  const handleCanvasMouseMove = useCallback((e) => {
    if (!draggedNode || !canvasRef.current) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - dragOffset.x) / zoom;
    const y = (e.clientY - rect.top - dragOffset.y) / zoom;

    const updatedNodes = currentNodes.map(n =>
      n.id === draggedNode
        ? { ...n, position: { x: Math.max(0, x), y: Math.max(0, y) } }
        : n
    );
    onNodesChange(updatedNodes);
  }, [draggedNode, dragOffset, zoom, currentNodes, onNodesChange]);

  const handleCanvasMouseUp = () => {
    setDraggedNode(null);
  };

  const handleNodeConfigure = (node) => {
    setConfigNode(node);
  };

  const handleConfigSave = (nodeId, data) => {
    const updatedNodes = currentNodes.map(n =>
      n.id === nodeId ? { ...n, data: { ...n.data, ...data } } : n
    );
    onNodesChange(updatedNodes);
    setConfigNode(null);
  };

  // Draw connections
  const renderConnections = () => {
    const lines = [];
    currentNodes.forEach(node => {
      (node.connections || []).forEach(targetId => {
        const target = currentNodes.find(n => n.id === targetId);
        if (target) {
          const startX = (node.position?.x || 0) + 96;
          const startY = (node.position?.y || 0) + 80;
          const endX = (target.position?.x || 0) + 96;
          const endY = (target.position?.y || 0);

          const midY = (startY + endY) / 2;

          lines.push(
            <path
              key={`${node.id}-${targetId}`}
              d={`M ${startX} ${startY} C ${startX} ${midY}, ${endX} ${midY}, ${endX} ${endY}`}
              stroke="#9CA3AF"
              strokeWidth="2"
              fill="none"
              markerEnd="url(#arrowhead)"
            />
          );
        }
      });
    });
    return lines;
  };

  return (
    <div className="flex flex-col md:flex-row h-full min-h-[600px]">
      {/* Node Palette */}
      <div className="w-full md:w-48 border-b md:border-b-0 md:border-r bg-gray-50 p-3 md:p-4 flex-shrink-0 overflow-x-auto md:overflow-x-visible">
        <h3 className="font-semibold text-sm text-gray-700 mb-3">Add Nodes</h3>
        <div className="flex md:flex-col gap-2 md:space-y-0">
          {NODE_TYPES.map(({ type, label, icon: Icon, color }) => (
            <button
              key={type}
              onClick={() => handleAddNode(type)}
              className="flex-shrink-0 md:w-full flex items-center gap-2 p-2 rounded-lg border bg-white hover:bg-gray-50 transition-colors whitespace-nowrap"
            >
              <div className={`w-6 h-6 rounded ${color} flex items-center justify-center`}>
                <Icon className="w-3 h-3 text-white" />
              </div>
              <span className="text-sm">{label}</span>
            </button>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t">
          <Button
            onClick={onSave}
            disabled={isSaving}
            className="w-full bg-purple-600 hover:bg-purple-700"
            size="sm"
          >
            <Save className="w-3 h-3 mr-1" />
            {isSaving ? 'Saving...' : 'Save'}
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 relative overflow-auto bg-gray-100 touch-pan-x touch-pan-y">
        {/* Zoom Controls */}
        <div className="absolute top-2 md:top-4 right-2 md:right-4 flex items-center gap-1 md:gap-2 z-10">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-white"
            onClick={() => setZoom(Math.min(zoom + 0.1, 2))}
          >
            <ZoomIn className="w-4 h-4" />
          </Button>
          <span className="text-xs bg-white px-2 py-1 rounded">{Math.round(zoom * 100)}%</span>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-white"
            onClick={() => setZoom(Math.max(zoom - 0.1, 0.5))}
          >
            <ZoomOut className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-white"
            onClick={() => setZoom(1)}
          >
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>

        {/* Canvas Area */}
        <div
          ref={canvasRef}
          className="w-full h-full relative touch-none"
          style={{ 
            transform: `scale(${zoom})`,
            transformOrigin: 'top left',
            minHeight: '800px',
            minWidth: '100%'
          }}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onMouseLeave={handleCanvasMouseUp}
        >
          {/* Grid Pattern */}
          <div 
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: 'radial-gradient(circle, #d1d5db 1px, transparent 1px)',
              backgroundSize: '20px 20px'
            }}
          />

          {/* SVG for connections */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="7"
                refX="9"
                refY="3.5"
                orient="auto"
              >
                <polygon points="0 0, 10 3.5, 0 7" fill="#9CA3AF" />
              </marker>
            </defs>
            {renderConnections()}
          </svg>

          {/* Nodes */}
          {currentNodes.map(node => (
            <div
              key={node.id}
              onMouseDown={(e) => handleNodeDragStart(e, node)}
            >
              <WorkflowNode
                node={node}
                isSelected={selectedNodeId === node.id}
                onSelect={setSelectedNodeId}
                onDelete={handleDeleteNode}
                onConfigure={handleNodeConfigure}
                isDragging={draggedNode === node.id}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Config Modal */}
      {configNode && (
        <NodeConfigModal
          node={configNode}
          onSave={(data) => handleConfigSave(configNode.id, data)}
          onClose={() => setConfigNode(null)}
        />
      )}
    </div>
  );
}