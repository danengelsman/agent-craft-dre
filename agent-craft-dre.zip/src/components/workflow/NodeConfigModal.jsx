import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Bot, Zap, GitBranch, Clock, Play, Square } from "lucide-react";
import { motion } from "framer-motion";

export default function NodeConfigModal({ node, onSave, onClose }) {
  const [config, setConfig] = useState(node.data || {});

  const { data: agents = [] } = useQuery({
    queryKey: ['agentsForWorkflow'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: node.type === 'agent'
  });

  const { data: actions = [] } = useQuery({
    queryKey: ['actionsForWorkflow'],
    queryFn: () => base44.entities.AgentAction.list('-created_date'),
    enabled: node.type === 'action'
  });

  useEffect(() => {
    setConfig(node.data || {});
  }, [node]);

  const handleSave = () => {
    onSave(config);
  };

  const renderTriggerConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>Trigger Type</Label>
        <Select
          value={config.type || 'manual'}
          onValueChange={(v) => setConfig({ ...config, type: v })}
        >
          <SelectTrigger className="mt-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="manual">Manual Trigger</SelectItem>
            <SelectItem value="schedule">Scheduled</SelectItem>
            <SelectItem value="webhook">Webhook</SelectItem>
            <SelectItem value="event">On Event</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {config.type === 'schedule' && (
        <div>
          <Label>Schedule (cron)</Label>
          <Input
            value={config.schedule || ''}
            onChange={(e) => setConfig({ ...config, schedule: e.target.value })}
            placeholder="0 9 * * *"
            className="mt-1 font-mono"
          />
          <p className="text-xs text-gray-500 mt-1">e.g., "0 9 * * *" = daily at 9am</p>
        </div>
      )}
    </div>
  );

  const renderAgentConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>Select Agent</Label>
        <Select
          value={config.agentId || ''}
          onValueChange={(v) => {
            const agent = agents.find(a => a.id === v);
            setConfig({ ...config, agentId: v, name: agent?.name });
          }}
        >
          <SelectTrigger className="mt-1">
            <SelectValue placeholder="Choose an agent" />
          </SelectTrigger>
          <SelectContent>
            {agents.map(agent => (
              <SelectItem key={agent.id} value={agent.id}>
                {agent.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Task Instructions</Label>
        <Textarea
          value={config.instructions || ''}
          onChange={(e) => setConfig({ ...config, instructions: e.target.value })}
          placeholder="What should this agent do?"
          className="mt-1"
        />
      </div>
    </div>
  );

  const renderActionConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>Select Action</Label>
        <Select
          value={config.actionId || ''}
          onValueChange={(v) => {
            const action = actions.find(a => a.id === v);
            setConfig({ ...config, actionId: v, name: action?.name });
          }}
        >
          <SelectTrigger className="mt-1">
            <SelectValue placeholder="Choose an action" />
          </SelectTrigger>
          <SelectContent>
            {actions.map(action => (
              <SelectItem key={action.id} value={action.id}>
                {action.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Input Data (JSON)</Label>
        <Textarea
          value={config.inputData || '{}'}
          onChange={(e) => setConfig({ ...config, inputData: e.target.value })}
          placeholder="{}"
          className="mt-1 font-mono text-sm"
        />
      </div>
    </div>
  );

  const renderConditionConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>Condition Name</Label>
        <Input
          value={config.name || ''}
          onChange={(e) => setConfig({ ...config, name: e.target.value })}
          placeholder="e.g., Check if successful"
          className="mt-1"
        />
      </div>
      <div>
        <Label>Condition Expression</Label>
        <Textarea
          value={config.expression || ''}
          onChange={(e) => setConfig({ ...config, expression: e.target.value })}
          placeholder="e.g., {{previousOutput.success}} === true"
          className="mt-1 font-mono text-sm"
        />
        <p className="text-xs text-gray-500 mt-1">Use {"{{variable}}"} to reference workflow variables</p>
      </div>
    </div>
  );

  const renderDelayConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>Delay Duration</Label>
        <div className="flex gap-2 mt-1">
          <Input
            type="number"
            value={config.duration || 5}
            onChange={(e) => setConfig({ ...config, duration: parseInt(e.target.value) })}
            className="w-24"
          />
          <Select
            value={config.unit || 'seconds'}
            onValueChange={(v) => setConfig({ ...config, unit: v })}
          >
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="seconds">Seconds</SelectItem>
              <SelectItem value="minutes">Minutes</SelectItem>
              <SelectItem value="hours">Hours</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );

  const renderEndConfig = () => (
    <div className="space-y-4">
      <div>
        <Label>End Status</Label>
        <Select
          value={config.status || 'success'}
          onValueChange={(v) => setConfig({ ...config, status: v })}
        >
          <SelectTrigger className="mt-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="success">Success</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Final Message (optional)</Label>
        <Input
          value={config.message || ''}
          onChange={(e) => setConfig({ ...config, message: e.target.value })}
          placeholder="Workflow completed"
          className="mt-1"
        />
      </div>
    </div>
  );

  const nodeIcons = {
    trigger: Play,
    agent: Bot,
    action: Zap,
    condition: GitBranch,
    delay: Clock,
    end: Square
  };

  const Icon = nodeIcons[node.type] || Zap;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl p-6 max-w-md w-full max-h-[80vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
              <Icon className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Configure {node.type}</h2>
              <p className="text-sm text-gray-500">Node: {node.id}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {node.type === 'trigger' && renderTriggerConfig()}
        {node.type === 'agent' && renderAgentConfig()}
        {node.type === 'action' && renderActionConfig()}
        {node.type === 'condition' && renderConditionConfig()}
        {node.type === 'delay' && renderDelayConfig()}
        {node.type === 'end' && renderEndConfig()}

        <div className="flex gap-3 mt-6">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={handleSave} className="flex-1 bg-purple-600 hover:bg-purple-700">
            Save
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}