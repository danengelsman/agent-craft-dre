import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, Check, Plus, Mail, Globe, Calendar, Database, Code, MessageSquare, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const ACTION_ICONS = {
  send_email: Mail,
  http_request: Globe,
  slack_message: MessageSquare,
  calendar_event: Calendar,
  database_query: Database,
  custom_function: Code
};

export default function ActionSelector({ selectedActions = [], onSelectAction, onRemoveAction }) {
  const [showAll, setShowAll] = useState(false);

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ['availableActions'],
    queryFn: () => base44.entities.AgentAction.list('-created_date'),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-5 h-5 animate-spin text-amber-500" />
      </div>
    );
  }

  const displayedActions = showAll ? actions : actions.slice(0, 4);
  const hasMore = actions.length > 4;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-amber-500" />
          <h3 className="font-semibold">Assign Actions</h3>
        </div>
        <span className="text-sm text-gray-500">
          {selectedActions.length} selected
        </span>
      </div>

      {actions.length === 0 ? (
        <Card className="p-6 text-center border-dashed border-2">
          <Zap className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-sm text-gray-600 mb-3">No actions created yet</p>
          <Link to={createPageUrl("ActionBuilder")}>
            <Button size="sm" variant="outline">
              <Plus className="w-3 h-3 mr-1" />
              Create Action
            </Button>
          </Link>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3">
            <AnimatePresence>
              {displayedActions.map((action) => {
                const isSelected = selectedActions.includes(action.id);
                const Icon = ACTION_ICONS[action.action_type] || Zap;

                return (
                  <motion.div
                    key={action.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                  >
                    <button
                      onClick={() => isSelected ? onRemoveAction(action.id) : onSelectAction(action.id)}
                      className={`w-full p-3 rounded-xl text-left transition-all border-2 ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          isSelected ? 'bg-amber-500' : 'bg-gray-100'
                        }`}>
                          {isSelected ? (
                            <Check className="w-4 h-4 text-white" />
                          ) : (
                            <Icon className="w-4 h-4 text-gray-600" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm truncate">{action.name}</h4>
                          <p className="text-xs text-gray-500 truncate">{action.description}</p>
                        </div>
                      </div>
                    </button>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {hasMore && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowAll(!showAll)}
              className="w-full"
            >
              {showAll ? 'Show Less' : `Show ${actions.length - 4} More`}
            </Button>
          )}

          <div className="pt-2 border-t">
            <Link to={createPageUrl("ActionBuilder")}>
              <Button variant="outline" size="sm" className="w-full">
                <Plus className="w-3 h-3 mr-1" />
                Create New Action
              </Button>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}