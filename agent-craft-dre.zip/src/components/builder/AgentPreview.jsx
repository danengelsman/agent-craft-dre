import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function AgentPreview({ name, description, abilities, allAbilities }) {
  const selectedAbilitiesData = allAbilities.filter(a => abilities.includes(a.id));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <Card className="bg-gray-50 border-gray-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-gray-900">
            <Sparkles className="w-5 h-5 text-gray-900" />
            Preview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {name ? (
            <>
              <div>
                <h3 className="font-bold text-2xl mb-2 text-gray-900">
                  {name}
                </h3>
                <p className="text-gray-600">{description || "No description yet"}</p>
              </div>

              {selectedAbilitiesData.length > 0 && (
                <div>
                  <p className="text-sm font-semibold text-gray-700 mb-2">Connected Abilities:</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedAbilitiesData.map((ability) => (
                      <div
                        key={ability.id}
                        className="px-3 py-1 rounded-full bg-gray-200 text-gray-700 text-sm font-medium"
                      >
                        {ability.name}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center text-gray-400 py-8">
              <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Fill in the details to see your agent come to life!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}