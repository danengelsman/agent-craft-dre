import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, ArrowRight, X } from "lucide-react";
import { motion } from "framer-motion";
import { PREDEFINED_INTENTS } from "./intentData";

export default function IntentSelector({ selectedIntent, onSelect }) {
  const [showCustomForm, setShowCustomForm] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customDescription, setCustomDescription] = useState("");

  const handleCustomSubmit = () => {
    if (!customName.trim() || !customDescription.trim()) {
      alert("Please provide both name and description");
      return;
    }

    onSelect({
      id: "custom",
      name: customName,
      description: customDescription,
      icon: Sparkles,
      color: "from-gray-500 to-gray-700",
      default_abilities: [
        { id: "basic_chat", name: "Basic Chat", description: "Standard conversational capabilities", auto_selected: true }
      ],
      additional_abilities: [],
      example_queries: []
    });

    setShowCustomForm(false);
  };

  if (showCustomForm) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2 text-gray-900">Create Custom Agent</h2>
          <p className="text-gray-600">
            Build an agent from scratch with your own specifications
          </p>
        </div>

        <div className="premium-card p-8 space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              Agent Type Name
            </label>
            <Input
              placeholder="e.g., Email Assistant, Recipe Helper..."
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              className="text-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-900 mb-2">
              What will it do?
            </label>
            <Textarea
              placeholder="Describe the purpose and capabilities..."
              value={customDescription}
              onChange={(e) => setCustomDescription(e.target.value)}
              className="min-h-32"
            />
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => setShowCustomForm(false)}
              variant="outline"
              className="flex-1"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleCustomSubmit}
              className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2 text-gray-900">What's Your Channel About?</h2>
        <p className="text-gray-600">
          Pick your niche so we can tailor your content helper
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {PREDEFINED_INTENTS.map((intent, index) => {
          const Icon = intent.icon;
          const isSelected = selectedIntent?.id === intent.id;

          return (
            <motion.button
              key={intent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => onSelect(intent)}
              className={`premium-card p-6 text-left transition-all cursor-pointer ${
                isSelected ? 'ring-2 ring-gray-900' : ''
              }`}
            >
              <div
                className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${intent.color} flex items-center justify-center mb-4`}
              >
                <Icon className="w-7 h-7 text-white" />
              </div>

              <h3 className="font-bold text-lg mb-2 text-gray-900">{intent.name}</h3>
              <p className="text-sm text-gray-600 mb-4">{intent.description}</p>

              <div className="space-y-2 mb-4">
                <p className="text-xs font-semibold text-gray-500 uppercase">
                  Use Cases:
                </p>
                {intent.example_use_cases.map((useCase, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-gray-600">
                    <span className="text-gray-400">•</span>
                    <span>{useCase}</span>
                  </div>
                ))}
              </div>

              {isSelected && (
                <div className="flex items-center gap-2 text-sm font-semibold text-gray-900">
                  <div className="w-5 h-5 rounded-full bg-gray-900 flex items-center justify-center">
                    <ArrowRight className="w-3 h-3 text-white" />
                  </div>
                  Selected
                </div>
              )}
            </motion.button>
          );
        })}

        {/* Custom Agent Option */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: PREDEFINED_INTENTS.length * 0.05 }}
          onClick={() => setShowCustomForm(true)}
          className="premium-card p-6 text-left border-2 border-dashed border-gray-300 hover:border-purple-400 cursor-pointer transition-all duration-200"
        >
          <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-4">
            <Sparkles className="w-7 h-7 text-gray-600" />
          </div>

          <h3 className="font-bold text-lg mb-2 text-gray-900">Custom Agent</h3>
          <p className="text-sm text-gray-600 mb-4">
            Build your own agent from scratch with custom capabilities
          </p>

          <div className="text-sm font-semibold text-gray-600 flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            Create Custom
          </div>
        </motion.button>
      </div>
    </div>
  );
}