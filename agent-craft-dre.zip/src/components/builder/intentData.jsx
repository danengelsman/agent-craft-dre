import { 
  Gamepad2,
  ChefHat,
  Smartphone,
  Camera,
  Sparkles as Beauty,
  Dumbbell,
  GraduationCap,
  Video,
  MessageCircle,
  Sparkles,
  Tag,
  TrendingUp as Trending,
  Lightbulb,
  Crown
} from "lucide-react";

export const PREDEFINED_INTENTS = [
  {
    id: "gaming_youtube",
    name: "Gaming Channel",
    description: "Let's Plays, walkthroughs, reviews, and game commentary",
    icon: Gamepad2,
    color: "from-purple-500 to-indigo-600",
    example_use_cases: [
      "Generate ideas for trending games",
      "Write engaging gaming commentary",
      "Plan video series for game releases"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Content Brainstorming", description: "Generate video ideas based on trending games", auto_selected: true },
      { id: "trend_research", name: "Trend Research", description: "Find what's hot in gaming right now", auto_selected: true },
      { id: "viral_analysis", name: "Viral Analysis", description: "Understand what gaming content goes viral", auto_selected: true },
      { id: "title_optimizer", name: "Title Optimizer", description: "Write catchy gaming titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan multi-part gaming series" },
      { id: "thumbnail_tips", name: "Thumbnail Tips", description: "Suggest gaming thumbnail concepts" }
    ],
    example_queries: [
      "What games are trending right now?",
      "Give me 5 video ideas for Minecraft",
      "How should I title my gameplay video?",
      "What's a good hook for a gaming review?"
    ]
  },
  {
    id: "cooking_youtube",
    name: "Cooking/Food Channel",
    description: "Quick recipes, meal prep, and food reviews",
    icon: ChefHat,
    color: "from-orange-500 to-red-600",
    example_use_cases: [
      "Brainstorm recipe video ideas",
      "Plan budget meal content",
      "Create meal prep tutorials"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Recipe Brainstorming", description: "Generate recipe video ideas", auto_selected: true },
      { id: "trend_research", name: "Food Trend Research", description: "Find trending recipes and food hacks", auto_selected: true },
      { id: "viral_analysis", name: "Viral Food Analysis", description: "Understand what food content performs well", auto_selected: true },
      { id: "title_optimizer", name: "Recipe Title Optimizer", description: "Write catchy food titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan cooking series (e.g., 30-day challenges)" },
      { id: "thumbnail_tips", name: "Food Photo Tips", description: "Suggest appealing food thumbnails" }
    ],
    example_queries: [
      "Give me 5 quick dinner ideas",
      "What's trending in cooking videos?",
      "Help me plan a meal prep series",
      "How do I make healthy food look appealing?"
    ]
  },
  {
    id: "tech_youtube",
    name: "Tech Review Channel",
    description: "Gadget unboxing, comparisons, and tech tutorials",
    icon: Smartphone,
    color: "from-blue-500 to-cyan-600",
    example_use_cases: [
      "Plan product review videos",
      "Compare tech gadgets",
      "Create buying guide content"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Tech Content Ideas", description: "Generate gadget review concepts", auto_selected: true },
      { id: "trend_research", name: "Tech Trend Research", description: "Find new product launches and trends", auto_selected: true },
      { id: "viral_analysis", name: "Tech Video Analysis", description: "Understand what tech reviews perform best", auto_selected: true },
      { id: "title_optimizer", name: "Tech Title Optimizer", description: "Write engaging tech review titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan comparison series" },
      { id: "thumbnail_tips", name: "Tech Thumbnail Tips", description: "Suggest product shot ideas" }
    ],
    example_queries: [
      "What tech products should I review?",
      "Give me comparison video ideas",
      "How do I title an iPhone review?",
      "What gadgets are trending now?"
    ]
  },
  {
    id: "lifestyle_youtube",
    name: "Lifestyle Vlog Channel",
    description: "Day in life, routines, and personal stories",
    icon: Camera,
    color: "from-pink-500 to-rose-600",
    example_use_cases: [
      "Plan daily vlog content",
      "Create morning/night routine videos",
      "Share personal story ideas"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Vlog Ideas", description: "Generate lifestyle content concepts", auto_selected: true },
      { id: "trend_research", name: "Lifestyle Trends", description: "Find trending vlog formats", auto_selected: true },
      { id: "viral_analysis", name: "Vlog Analysis", description: "Understand what vlogs go viral", auto_selected: true },
      { id: "title_optimizer", name: "Vlog Title Optimizer", description: "Write relatable vlog titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan weekly vlog series" },
      { id: "thumbnail_tips", name: "Lifestyle Thumbnail Tips", description: "Suggest aesthetic thumbnail ideas" }
    ],
    example_queries: [
      "Give me morning routine video ideas",
      "What lifestyle content is trending?",
      "How do I make my vlogs more engaging?",
      "What should I film today?"
    ]
  },
  {
    id: "beauty_youtube",
    name: "Beauty/Makeup Channel",
    description: "Tutorials, GRWM, and product reviews",
    icon: Beauty,
    color: "from-fuchsia-500 to-pink-600",
    example_use_cases: [
      "Plan makeup tutorial videos",
      "Create GRWM content",
      "Review beauty products"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Beauty Ideas", description: "Generate makeup tutorial concepts", auto_selected: true },
      { id: "trend_research", name: "Beauty Trends", description: "Find trending makeup looks", auto_selected: true },
      { id: "viral_analysis", name: "Beauty Video Analysis", description: "Understand what beauty content performs well", auto_selected: true },
      { id: "title_optimizer", name: "Beauty Title Optimizer", description: "Write engaging beauty titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan makeup challenge series" },
      { id: "thumbnail_tips", name: "Beauty Thumbnail Tips", description: "Suggest stunning makeup thumbnails" }
    ],
    example_queries: [
      "Give me 5 makeup tutorial ideas",
      "What beauty trends are popular?",
      "How do I title a GRWM video?",
      "What products should I review?"
    ]
  },
  {
    id: "fitness_youtube",
    name: "Fitness/Wellness Channel",
    description: "Home workouts, nutrition tips, and fitness challenges",
    icon: Dumbbell,
    color: "from-green-500 to-emerald-600",
    example_use_cases: [
      "Plan workout video content",
      "Create nutrition guide videos",
      "Launch fitness challenges"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Workout Ideas", description: "Generate fitness content concepts", auto_selected: true },
      { id: "trend_research", name: "Fitness Trends", description: "Find trending workouts and challenges", auto_selected: true },
      { id: "viral_analysis", name: "Fitness Video Analysis", description: "Understand what fitness content performs well", auto_selected: true },
      { id: "title_optimizer", name: "Fitness Title Optimizer", description: "Write motivating fitness titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan 30-day challenge series" },
      { id: "thumbnail_tips", name: "Fitness Thumbnail Tips", description: "Suggest energetic workout thumbnails" }
    ],
    example_queries: [
      "Give me home workout video ideas",
      "What fitness challenges are trending?",
      "How do I plan a 30-day series?",
      "What nutrition topics should I cover?"
    ]
  },
  {
    id: "education_youtube",
    name: "Education/How-To Channel",
    description: "Tutorials, explainers, and study tips",
    icon: GraduationCap,
    color: "from-amber-500 to-yellow-600",
    example_use_cases: [
      "Create educational tutorials",
      "Explain complex topics simply",
      "Share study tips and strategies"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Tutorial Ideas", description: "Generate educational content concepts", auto_selected: true },
      { id: "trend_research", name: "Education Trends", description: "Find popular learning topics", auto_selected: true },
      { id: "viral_analysis", name: "Tutorial Analysis", description: "Understand what educational content performs well", auto_selected: true },
      { id: "title_optimizer", name: "Tutorial Title Optimizer", description: "Write clear educational titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan course-style series" },
      { id: "thumbnail_tips", name: "Educational Thumbnail Tips", description: "Suggest informative thumbnails" }
    ],
    example_queries: [
      "Give me tutorial video ideas",
      "How do I explain this concept simply?",
      "What study tips should I share?",
      "How do I title an educational video?"
    ]
  },
  // The following block of intents (Youtube related) is updated and reordered based on the outline.
  {
    id: "youtube_ideas",
    name: "YouTube Content Creator",
    description: "Generate video ideas, titles, and content strategies",
    icon: Video,
    color: "from-red-500 to-orange-600",
    example_use_cases: [
      "Brainstorm video ideas for your niche",
      "Write catchy titles and hooks",
      "Plan content series and schedules"
    ],
    default_abilities: [
      { id: "content_brainstorming", name: "Content Brainstorming", description: "Generate video ideas based on your niche", auto_selected: true },
      { id: "trend_research", name: "Trend Research", description: "Find what's trending in your category", auto_selected: true },
      { id: "viral_analysis", name: "Viral Analysis", description: "Understand what makes content go viral", auto_selected: true },
      { id: "title_optimizer", name: "Title Optimizer", description: "Write catchy, SEO-friendly titles", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan multi-part content series" },
      { id: "thumbnail_tips", name: "Thumbnail Tips", description: "Suggest thumbnail concepts" }
    ],
    example_queries: [
      "Give me 5 video ideas about cooking",
      "What's trending in gaming?",
      "Help me write a catchy title",
      "How can I make this topic engaging?"
    ]
  },
  {
    id: "video_script_writer",
    name: "Video Script Writer",
    description: "Write engaging scripts with hooks and CTAs for videos",
    icon: Video,
    color: "from-red-500 to-orange-600",
    example_use_cases: [
      "Generate viral video scripts",
      "Create attention-grabbing hooks",
      "Write compelling CTAs"
    ],
    default_abilities: [
      { id: "script_templates", name: "Script Templates", description: "Access templates for intros, outros, transitions", auto_selected: true },
      { id: "hook_generator", name: "Hook Generator", description: "Create scroll-stopping first 3 seconds", auto_selected: true },
      { id: "cta_builder", name: "CTA Builder", description: "Write calls-to-action for subs, likes, comments", auto_selected: true },
      { id: "trend_analyzer", name: "Trend Analyzer", description: "Reference current viral formats", auto_selected: true }
    ],
    additional_abilities: [
      { id: "voiceover_timer", name: "Voiceover Timer", description: "Time scripts for video length" },
      { id: "b_roll_suggester", name: "B-Roll Suggester", description: "Recommend visual elements" }
    ],
    example_queries: [
      "Write a script for a 60-second tutorial",
      "Create a hook for my cooking video",
      "What CTA should I use?"
    ]
  },
  {
    id: "comment_moderator",
    name: "Comment Moderator",
    description: "Respond to comments and manage engagement",
    icon: MessageCircle,
    color: "from-blue-500 to-indigo-600",
    example_use_cases: [
      "Reply to comments automatically",
      "Filter spam and negativity",
      "Boost engagement with replies"
    ],
    default_abilities: [
      { id: "auto_reply", name: "Auto Reply", description: "Generate personalized comment responses", auto_selected: true },
      { id: "sentiment_filter", name: "Sentiment Filter", description: "Flag negative or spam comments", auto_selected: true },
      { id: "engagement_boost", name: "Engagement Boost", description: "Ask questions to drive more comments", auto_selected: true },
      { id: "keyword_alerts", name: "Keyword Alerts", description: "Notify for important mentions", auto_selected: true }
    ],
    additional_abilities: [
      { id: "pin_selector", name: "Pin Selector", description: "Suggest which comments to pin" },
      { id: "heart_prioritizer", name: "Heart Prioritizer", description: "Identify comments worth hearting" }
    ],
    example_queries: [
      "Reply to my latest video comments",
      "Which comments should I pin?",
      "Flag any negative comments"
    ]
  },
  {
    id: "content_idea_generator",
    name: "Content Idea Generator",
    description: "Generate viral content ideas based on trends",
    icon: Lightbulb,
    color: "from-yellow-500 to-amber-600",
    example_use_cases: [
      "Find trending topics in your niche",
      "Generate video ideas from news",
      "Analyze competitor content"
    ],
    default_abilities: [
      { id: "trend_scout", name: "Trend Scout", description: "Monitor TikTok, YouTube, Twitter trends", auto_selected: true },
      { id: "niche_analyzer", name: "Niche Analyzer", description: "Find gaps in your content area", auto_selected: true },
      { id: "idea_spinner", name: "Idea Spinner", description: "Remix popular formats for your brand", auto_selected: true },
      { id: "competitor_tracker", name: "Competitor Tracker", description: "See what's working for similar creators", auto_selected: true }
    ],
    additional_abilities: [
      { id: "series_planner", name: "Series Planner", description: "Plan multi-part content series" },
      { id: "seasonal_ideas", name: "Seasonal Ideas", description: "Suggest holiday/seasonal content" }
    ],
    example_queries: [
      "What's trending in fitness content?",
      "Give me 10 video ideas for next week",
      "What are my competitors posting?"
    ]
  },
  {
    id: "caption_writer",
    name: "Caption Writer",
    description: "Write captions, hashtags, and descriptions",
    icon: Tag,
    color: "from-purple-500 to-pink-600",
    example_use_cases: [
      "Generate platform-specific captions",
      "Research best hashtags",
      "Write SEO-optimized descriptions"
    ],
    default_abilities: [
      { id: "caption_generator", name: "Caption Generator", description: "Write engaging captions with emojis", auto_selected: true },
      { id: "hashtag_research", name: "Hashtag Research", description: "Find trending and niche hashtags", auto_selected: true },
      { id: "description_optimizer", name: "Description Optimizer", description: "SEO-friendly video descriptions", auto_selected: true },
      { id: "platform_adapter", name: "Platform Adapter", description: "Adjust copy for YouTube/TikTok/IG", auto_selected: true }
    ],
    additional_abilities: [
      { id: "emoji_suggester", name: "Emoji Suggester", description: "Recommend relevant emojis" },
      { id: "call_to_action", name: "CTA Templates", description: "Pre-written CTAs for engagement" }
    ],
    example_queries: [
      "Write a caption for my workout video",
      "What hashtags should I use?",
      "Optimize my YouTube description"
    ]
  },
  {
    id: "analytics_tracker",
    name: "Analytics Tracker",
    description: "Track performance and optimize posting strategy",
    icon: Trending,
    color: "from-green-500 to-teal-600",
    example_use_cases: [
      "Analyze what content performs best",
      "Find optimal posting times",
      "Track follower growth"
    ],
    default_abilities: [
      { id: "performance_reports", name: "Performance Reports", description: "Weekly/monthly analytics summaries", auto_selected: true },
      { id: "best_time_finder", name: "Best Time Finder", description: "Identify when your audience is active", auto_selected: true },
      { id: "content_ranker", name: "Content Ranker", description: "Compare which videos performed best", auto_selected: true },
      { id: "growth_tracker", name: "Growth Tracker", description: "Monitor subs, followers, engagement rate", auto_selected: true }
    ],
    additional_abilities: [
      { id: "a_b_tester", name: "A/B Tester", description: "Test thumbnails, titles, hooks" },
      { id: "competitor_benchmarks", name: "Competitor Benchmarks", description: "Compare your metrics to others" }
    ],
    example_queries: [
      "What's my best performing content?",
      "When should I post for max views?",
      "How's my growth this month?"
    ]
  },
  {
    id: "thumbnail_designer",
    name: "Thumbnail Designer",
    description: "Generate thumbnail concepts and text overlays",
    icon: Sparkles,
    color: "from-fuchsia-500 to-purple-600",
    example_use_cases: [
      "Create click-worthy thumbnail ideas",
      "Suggest text overlays",
      "Test thumbnail variations"
    ],
    default_abilities: [
      { id: "thumbnail_concepts", name: "Thumbnail Concepts", description: "Generate layout and composition ideas", auto_selected: true },
      { id: "text_overlay_writer", name: "Text Overlay Writer", description: "Write compelling thumbnail text", auto_selected: true },
      { id: "color_palette", name: "Color Palette", description: "Suggest high-contrast color schemes", auto_selected: true },
      { id: "thumbnail_analyzer", name: "Thumbnail Analyzer", description: "Review competitor thumbnails", auto_selected: true }
    ],
    additional_abilities: [
      { id: "face_expression_guide", name: "Face Expression Guide", description: "Suggest facial expressions" },
      { id: "clickbait_checker", name: "Clickbait Checker", description: "Balance intrigue and honesty" }
    ],
    example_queries: [
      "Give me thumbnail ideas for my tech review",
      "What text should go on my thumbnail?",
      "Analyze this thumbnail concept"
    ]
  },
  {
    id: "content_manager",
    name: "Content Manager (Super Agent)",
    description: "Orchestrate all agents, optimize workflows, and maximize results",
    icon: Crown,
    color: "from-amber-500 via-yellow-500 to-orange-600",
    requiredPlan: "pro",
    isPremium: true,
    example_use_cases: [
      "Chain agents together for full workflows",
      "Monitor performance and auto-optimize",
      "Handle crises and proactive alerts"
    ],
    default_abilities: [
      { id: "workflow_orchestrator", name: "Workflow Orchestrator", description: "Chain agents: Idea → Script → Caption → Thumbnail", auto_selected: true },
      { id: "quality_control", name: "Quality Control", description: "Review all outputs, approve before publishing", auto_selected: true },
      { id: "performance_optimizer", name: "Performance Optimizer", description: "Analyze what works, update agent strategies", auto_selected: true },
      { id: "content_calendar", name: "Content Calendar", description: "Schedule posts, prevent gaps, balance types", auto_selected: true },
      { id: "cross_agent_memory", name: "Cross-Agent Memory", description: "Share context between all agents", auto_selected: true },
      { id: "proactive_alerts", name: "Proactive Alerts", description: "Detect problems before they happen", auto_selected: true },
      { id: "agent_collaboration", name: "Agent Collaboration", description: "Coordinate agents to solve complex tasks", auto_selected: true },
      { id: "competitive_intel", name: "Competitive Intelligence", description: "Monitor competitors, spot trends early", auto_selected: true },
      { id: "crisis_manager", name: "Crisis Manager", description: "Handle negative waves, policy violations", auto_selected: true },
      { id: "monetization_tracker", name: "Monetization Tracker", description: "Prioritize high-ROI content types", auto_selected: true },
      { id: "ab_test_coordinator", name: "A/B Test Coordinator", description: "Test variants, pick winners automatically", auto_selected: true },
      { id: "resource_monitor", name: "Resource Monitor", description: "Track agent usage, costs, efficiency", auto_selected: true }
    ],
    additional_abilities: [
      { id: "brand_guardian", name: "Brand Guardian", description: "Ensure consistency across all content" },
      { id: "learning_engine", name: "Learning Engine", description: "Improve strategies from past results" }
    ],
    example_queries: [
      "Create a full workflow for my next video",
      "What's underperforming and why?",
      "Schedule my content for next week",
      "What are competitors doing?",
      "Optimize my agent strategies",
      "Run A/B test on my thumbnails"
    ]
  }
];

export const SCRIPTED_CONVERSATIONS = {
  customer_support: [
    { role: "user", content: "Hi, I need help with my account" },
    { role: "assistant", content: "Hello! I'm {name}, your support assistant. I'd be happy to help with your account. What specific issue are you experiencing?", abilities_used: ["conversation_history"] },
    { role: "user", content: "I can't log in" },
    { role: "assistant", content: "I understand login issues can be frustrating. Let me help you resolve this. First, have you tried resetting your password? I can also check if there are any issues with your account status.", abilities_used: ["knowledge_base_search", "sentiment_detection"] }
  ],
  sales_assistant: [
    { role: "user", content: "I'm interested in your enterprise plan" },
    { role: "assistant", content: "Great to hear from you! I'm {name}, your sales assistant. Our enterprise plan is perfect for growing teams. Can you tell me a bit about your company size and current needs?", abilities_used: ["product_catalog"] },
    { role: "user", content: "We're a team of 50 people" },
    { role: "assistant", content: "Perfect! For a 50-person team, our Enterprise plan offers unlimited users, priority support, and advanced integrations. Would you like to schedule a demo to see how it works?", abilities_used: ["crm_integration", "calendar_booking"] }
  ],
  scheduling_coordinator: [
    { role: "user", content: "I need to schedule a meeting with 3 people" },
    { role: "assistant", content: "Hi! I'm {name}, your scheduling coordinator. I'll help you find the perfect time for all 3 people. Could you share the names or email addresses of the attendees?", abilities_used: ["calendar_integration"] },
    { role: "user", content: "Sarah, Mike, and John from the marketing team" },
    { role: "assistant", content: "Got it! I'll check their calendars to find available times. Looking at this week, I see Thursday at 2 PM works for everyone. Should I send the invites?", abilities_used: ["availability_finder", "email_sender"] }
  ],
  research_assistant: [
    { role: "user", content: "What are the latest trends in AI?" },
    { role: "assistant", content: "Hello! I'm {name}, your research assistant. I'd be happy to research the latest AI trends for you. Let me search for current information...", abilities_used: ["web_search"] },
    { role: "user", content: "Focus on business applications" },
    { role: "assistant", content: "Based on recent data, the top AI trends in business are: 1) Generative AI for content creation, 2) AI-powered customer service automation, 3) Predictive analytics for decision-making. Would you like me to dive deeper into any of these?", abilities_used: ["web_search", "data_extraction"] }
  ],
  content_creator: [
    { role: "user", content: "I need a blog post about productivity" },
    { role: "assistant", content: "Hi! I'm {name}, your content creation assistant. I'll help you create an engaging blog post about productivity. What's your target audience and desired tone?", abilities_used: ["content_templates"] },
    { role: "user", content: "Young professionals, friendly tone" },
    { role: "assistant", content: "Perfect! Here's a draft title: '5 Productivity Hacks That Actually Work for Busy Professionals'. I'll craft content with actionable tips, relatable examples, and a conversational style. Would you like me to proceed?", abilities_used: ["brand_voice_library", "grammar_checker"] }
  ],
  data_analyst: [
    { role: "user", content: "Show me our sales performance this quarter" },
    { role: "assistant", content: "Hello! I'm {name}, your data analyst. I'll analyze your sales performance for this quarter. Let me query the database...", abilities_used: ["database_query"] },
    { role: "user", content: "Compare it to last quarter" },
    { role: "assistant", content: "Analysis complete! Your Q4 sales increased by 23% compared to Q3. Top performing products: Product A (+45%), Product B (+32%). I can generate a detailed report with charts if you'd like.", abilities_used: ["database_query", "chart_generator", "statistical_analysis"] }
  ],
  // The following block of conversations is updated and reordered based on the outline.
  youtube_ideas: [
    { role: "user", content: "Give me 5 video ideas about cooking" },
    { role: "assistant", content: "Hello! I'm {name}, your YouTube content creator. I'd love to help you brainstorm. What kind of cooking videos are you thinking of? Quick meals, gourmet, baking?", abilities_used: ["content_brainstorming"] },
    { role: "user", content: "Quick weeknight dinners for busy people" },
    { role: "assistant", content: "Great niche! How about: 1) '5-Ingredient Dinners in 15 Minutes', 2) 'Meal Prep Hacks for Busy Weeks', 3) 'One-Pot Wonders: Easy Cleanup Dinners', 4) 'Healthy 30-Minute Recipes', 5) 'Budget-Friendly Weeknight Meals'. I can also help with catchy titles and hooks for these!", abilities_used: ["trend_research", "title_optimizer"] }
  ],
  video_script_writer: [
    { role: "user", content: "I need a script for a 60-second cooking video" },
    { role: "assistant", content: "Hey! I'm {name}, your script writer. I'll create an engaging 60-second cooking script for you. What dish are you making?", abilities_used: ["script_templates"] },
    { role: "user", content: "Quick pasta carbonara" },
    { role: "assistant", content: "Perfect! Here's your script with a strong hook: 'This 5-ingredient pasta will change your weeknights.' Then we'll show the process with quick cuts and end with 'Save this for later!' CTA. The script times out at exactly 58 seconds.", abilities_used: ["hook_generator", "cta_builder", "trend_analyzer"] }
  ],
  comment_moderator: [
    { role: "user", content: "Can you reply to comments on my latest video?" },
    { role: "assistant", content: "Hi! I'm {name}, your comment moderator. I'll check your latest video and draft personalized replies. How many comments do you have?", abilities_used: ["auto_reply"] },
    { role: "user", content: "About 50 comments" },
    { role: "assistant", content: "Great! I've reviewed all 50 comments. I suggest pinning the comment asking about your camera - it got 12 likes. I've drafted replies for 15 questions and flagged 2 spam comments for deletion.", abilities_used: ["sentiment_filter", "engagement_boost", "keyword_alerts"] }
  ],
  content_idea_generator: [
    { role: "user", content: "I need fresh video ideas for next week" },
    { role: "assistant", content: "Hello! I'm {name}, your idea generator. I'll find trending topics perfect for your niche. What type of content do you create?", abilities_used: ["trend_scout"] },
    { role: "user", content: "Fitness and workout tips" },
    { role: "assistant", content: "Perfect! Here are 5 trending ideas: 1) '30-day plank challenge' is viral now, 2) 'Gym anxiety tips' has high engagement, 3) 'Budget home gym setup' filling a content gap. Want me to generate more?", abilities_used: ["niche_analyzer", "idea_spinner", "competitor_tracker"] }
  ],
  caption_writer: [
    { role: "user", content: "Write a caption for my morning routine video" },
    { role: "assistant", content: "Hey! I'm {name}, your caption writer. I'll craft the perfect caption for your morning routine. What platform is this for?", abilities_used: ["caption_generator"] },
    { role: "user", content: "Instagram Reels" },
    { role: "assistant", content: "Here's your caption: 'POV: You're winning at life by 8am ☀️💪 Which step are you adding to your routine? 👇' Plus 15 trending hashtags including #morningroutine #productivityhacks #thatthatgirl", abilities_used: ["hashtag_research", "platform_adapter", "description_optimizer"] }
  ],
  analytics_tracker: [
    { role: "user", content: "What content is performing best for me?" },
    { role: "assistant", content: "Hi! I'm {name}, your analytics tracker. Let me pull your performance data. Which platform should I analyze?", abilities_used: ["performance_reports"] },
    { role: "user", content: "YouTube" },
    { role: "assistant", content: "Your top 3 videos: 1) 'Quick breakfast ideas' (45K views, 8.2% CTR), 2) 'Budget grocery haul' (38K views, 12% engagement), 3) 'Meal prep Sunday' (31K views). Tutorials with 'quick' in title perform 3x better!", abilities_used: ["content_ranker", "best_time_finder", "growth_tracker"] }
  ],
  thumbnail_designer: [
    { role: "user", content: "I need thumbnail ideas for my tech review" },
    { role: "assistant", content: "Hey! I'm {name}, your thumbnail designer. I'll create click-worthy concepts for your tech review. What product are you reviewing?", abilities_used: ["thumbnail_concepts"] },
    { role: "user", content: "New iPhone 16" },
    { role: "assistant", content: "Here are 3 concepts: 1) Split screen: you surprised (left) vs phone close-up (right) + 'WORTH IT?' in yellow, 2) You holding phone with bright gradient + 'iPhone 16 Review', 3) Dramatic lighting on phone + 'The TRUTH'. Use red/yellow text for max contrast!", abilities_used: ["text_overlay_writer", "color_palette", "thumbnail_analyzer"] }
  ],
  content_manager: [
    { role: "user", content: "Help me plan my content for next week" },
    { role: "assistant", content: "Hello! I'm {name}, your Content Manager. I'll orchestrate all your agents to plan a killer week. Let me analyze your performance data first...", abilities_used: ["performance_optimizer", "content_calendar"] },
    { role: "user", content: "What do you recommend?" },
    { role: "assistant", content: "Based on your analytics, here's your optimized schedule: Monday - Tutorial (your best performing format), Wednesday - Trending challenge video (competitor analysis shows this is hot), Friday - Story-time (fills your content gap). I've already assigned Script Writer, Caption Writer, and Thumbnail Designer to each. Workflow chains are ready to execute!", abilities_used: ["workflow_orchestrator", "competitive_intel", "agent_collaboration", "cross_agent_memory"] }
  ]
};

export const SUGGESTED_QUERIES = {
  customer_support: [
    "How do I reset my password?",
    "What's the status of my ticket?",
    "I need help with billing",
    "Can you escalate my issue?",
    "How do I update my account info?",
    "Is there a known outage?",
    "What are your support hours?",
    "I'm getting an error message"
  ],
  sales_assistant: [
    "What's included in your plans?",
    "Can I schedule a demo?",
    "What's your pricing for teams?",
    "Do you offer discounts?",
    "How does billing work?",
    "What integrations do you support?",
    "Can I see a product comparison?",
    "What's your refund policy?"
  ],
  scheduling_coordinator: [
    "Find time for a team meeting",
    "What's my schedule tomorrow?",
    "Cancel my 3pm meeting",
    "Book a 1-hour slot next week",
    "Who's available Friday afternoon?",
    "Reschedule my meeting",
    "Set up a recurring weekly call",
    "What time zones can you handle?"
  ],
  research_assistant: [
    "Research competitors in my industry",
    "Summarize this article for me",
    "What's trending in tech?",
    "Find statistics on market growth",
    "Compare these two companies",
    "What are best practices for SEO?",
    "Gather data on customer behavior",
    "Create a citation for this source"
  ],
  content_creator: [
    "Write a social media caption",
    "Create an email newsletter",
    "Draft a product announcement",
    "Generate blog post ideas",
    "Write a compelling headline",
    "Improve this paragraph",
    "Create a content calendar",
    "What's our brand voice?"
  ],
  data_analyst: [
    "Show me revenue trends",
    "What's our conversion rate?",
    "Analyze customer churn",
    "Create a sales report",
    "What products are top sellers?",
    "Compare this month vs last",
    "Show regional performance",
    "Calculate average order value"
  ],
  // The following block of queries is updated and reordered based on the outline.
  youtube_ideas: [
    "Give me 5 video ideas about cooking",
    "What's trending in gaming?",
    "Help me write a catchy title",
    "How can I make this topic engaging?",
    "Suggest a content series for me",
    "What thumbnail style works for this topic?"
  ],
  video_script_writer: [
    "Write a script for 60-second cooking video",
    "Create a hook for my tutorial",
    "What CTA drives the most subs?",
    "Give me 3 script variations",
    "How do I structure a story-time video?",
    "Write an outro with call-to-action",
    "What's a good opening line?",
    "Help me script a product review"
  ],
  comment_moderator: [
    "Reply to comments on my latest video",
    "Which comments should I pin?",
    "Filter out spam comments",
    "Generate replies for common questions",
    "What questions can I ask viewers?",
    "Flag negative comments",
    "How do I respond to criticism?",
    "Boost engagement in comments"
  ],
  content_idea_generator: [
    "What's trending in my niche?",
    "Give me 10 video ideas",
    "What are competitors posting?",
    "Find content gaps I can fill",
    "Suggest a video series",
    "What's viral on TikTok now?",
    "Ideas for holiday content",
    "Remix this trend for my brand"
  ],
  caption_writer: [
    "Write a caption for workout video",
    "Find trending hashtags for cooking",
    "Optimize my YouTube description",
    "What emojis should I use?",
    "Write Instagram caption",
    "Shorten this for TikTok",
    "Add a CTA to my caption",
    "Research best hashtags"
  ],
  analytics_tracker: [
    "What's my best content?",
    "When should I post?",
    "Track my growth this month",
    "Compare my last 10 videos",
    "What's my engagement rate?",
    "Which thumbnails work best?",
    "Analyze audience demographics",
    "Show me trending metrics"
  ],
  thumbnail_designer: [
    "Give me thumbnail ideas",
    "What text should I add?",
    "Suggest colors for my thumbnail",
    "Analyze competitor thumbnails",
    "What facial expression works?",
    "Is this too clickbait?",
    "Test this thumbnail concept",
    "Create 3 thumbnail variations"
  ],
  content_manager: [
    "Plan my content for next week",
    "What's underperforming and why?",
    "Create a workflow for my next video",
    "What are my competitors doing?",
    "Optimize my posting schedule",
    "Alert me if something goes wrong",
    "Which agents should I use more?",
    "Run A/B test on thumbnails",
    "What content drives the most revenue?",
    "Balance my content types",
    "Review all outputs before publishing",
    "What trends should I jump on?"
  ]
};