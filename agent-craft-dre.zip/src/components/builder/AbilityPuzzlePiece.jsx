import { motion } from "framer-motion";
import { Lock, Check, Crown, Brain, Search, FileText, Mail, Heart, Image } from "lucide-react";

const ICON_MAP = {
  Brain,
  Search,
  FileText,
  Mail,
  Heart,
  Image
};

export default function AbilityPuzzlePiece({ 
  ability, 
  isUnlocked, 
  isSelected, 
  isLocked, 
  onClick,
  planLocked = false,
  currentTier = "free"
}) {
  const Icon = typeof ability.icon === "string" ? ICON_MAP[ability.icon] : ability.icon;

  // Vibecode theme - all icons use consistent gray/black styling
  const getIconBackground = () => {
    if (isLocked) return "bg-gray-200";
    if (isSelected) return "bg-gray-900";
    return "bg-gray-100";
  };

  return (
    <motion.button
      onClick={onClick}
      disabled={isLocked}
      whileHover={!isLocked ? { scale: 1.02 } : {}}
      whileTap={!isLocked ? { scale: 0.98 } : {}}
      className={`p-4 rounded-xl border-2 transition-all text-left relative ${
        isSelected
          ? "border-gray-900 bg-gray-50 shadow-lg"
          : isLocked
          ? "border-gray-200 bg-gray-50 cursor-not-allowed opacity-60"
          : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-md cursor-pointer"
      }`}
    >
      {planLocked && (
        <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-gray-900 flex items-center justify-center shadow-md">
          <Crown className="w-3.5 h-3.5 text-white" />
        </div>
      )}

      <div className="flex items-start gap-3">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getIconBackground()}`}>
          {Icon && (
            <Icon className={`w-6 h-6 ${
              isSelected ? "text-white" : isLocked ? "text-gray-400" : "text-gray-600"
            }`} />
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-bold text-sm text-gray-900">{ability.name}</h4>
            {isSelected && <Check className="w-4 h-4 text-gray-900" />}
            {isLocked && !planLocked && <Lock className="w-4 h-4 text-gray-400" />}
          </div>
          <p className="text-xs text-gray-600 leading-tight">
            {ability.description}
          </p>
          {planLocked && (
            <div className="mt-2 text-xs font-semibold text-gray-600 flex items-center gap-1">
              <Crown className="w-3 h-3" />
              Upgrade to unlock
            </div>
          )}
          {isLocked && !planLocked && (
            <div className="mt-2 text-xs text-gray-500">
              Level {ability.levelRequired} required
            </div>
          )}
        </div>
      </div>
    </motion.button>
  );
}