
import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  X, 
  Send, 
  Camera, 
  Bug, 
  Lightbulb, 
  Palette, 
  HelpCircle, 
  Heart,
  Loader2,
  Check
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";

const FEEDBACK_TYPES = [
  {
    id: "bug",
    label: "Bug Report",
    icon: Bug,
    color: "from-red-500 to-rose-600",
    description: "Something isn't working"
  },
  {
    id: "feature_request",
    label: "Feature Request",
    icon: Lightbulb,
    color: "from-amber-500 to-orange-600",
    description: "I have an idea!"
  },
  {
    id: "ui_ux",
    label: "UI/UX Suggestion",
    icon: Palette,
    color: "from-purple-500 to-pink-600",
    description: "Design improvement"
  },
  {
    id: "question",
    label: "Question",
    icon: HelpCircle,
    color: "from-blue-500 to-cyan-600",
    description: "I need help"
  },
  {
    id: "praise",
    label: "Praise",
    icon: Heart,
    color: "from-pink-500 to-rose-600",
    description: "Love it!"
  }
];

const SEVERITY_OPTIONS = [
  { value: "low", label: "Low Priority", emoji: "🟢" },
  { value: "medium", label: "Medium Priority", emoji: "🟡" },
  { value: "high", label: "High Priority", emoji: "🔴" }
];

export default function FeedbackWidget({ user }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [severity, setSeverity] = useState("medium");
  const [message, setMessage] = useState("");
  const [screenshot, setScreenshot] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const queryClient = useQueryClient();

  const submitFeedbackMutation = useMutation({
    mutationFn: async (feedbackData) => {
      return await base44.entities.UserFeedback.create(feedbackData);
    },
    onSuccess: async (newFeedback) => {
      queryClient.invalidateQueries({ queryKey: ['userFeedback'] });
      
      // Trigger AI analysis in background
      try {
        const analysisPrompt = `Analyze this user feedback and provide numerical ratings:

Feedback Type: ${newFeedback.feedback_type}
Severity: ${newFeedback.severity}
User Message: ${newFeedback.message}
Page: ${newFeedback.page_url}

Context: AgentCraft is an educational SaaS platform for building AI agents. Users are learning to create and manage AI assistants.

Provide ratings (1-10 scale) for:
1. IMPACT: How many users would benefit?
2. EFFORT: Implementation difficulty (10=very easy, 1=very hard)
3. BUSINESS VALUE: Strategic importance for growth/retention
4. USER PAIN: Level of frustration this causes (10=critical blocker, 1=minor annoyance)

Also calculate: PRIORITY SCORE = (Impact × Business Value × User Pain) ÷ Effort

Provide detailed reasoning for each score.`;

        const analysis = await base44.integrations.Core.InvokeLLM({
          prompt: analysisPrompt,
          response_json_schema: {
            type: "object",
            properties: {
              impact_score: { type: "number" },
              effort_score: { type: "number" },
              business_value: { type: "number" },
              user_pain: { type: "number" },
              priority_score: { type: "number" },
              analysis: { type: "string" },
              recommendation: { type: "string" }
            }
          }
        });

        await base44.entities.UserFeedback.update(newFeedback.id, {
          ai_impact_score: analysis.impact_score,
          ai_effort_score: analysis.effort_score,
          ai_business_value: analysis.business_value,
          ai_user_pain: analysis.user_pain,
          ai_priority_score: analysis.priority_score,
          ai_analysis: `${analysis.analysis}\n\nRecommendation: ${analysis.recommendation}`
        });
      } catch (error) {
        console.error("AI analysis failed:", error);
        // Non-blocking - feedback still submitted successfully
      }
      
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        handleClose();
      }, 2000);
    },
  });

  const handleClose = () => {
    setIsExpanded(false);
    setSelectedType(null);
    setMessage("");
    setScreenshot(null);
    setSeverity("medium");
  };

  const handleScreenshotUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setScreenshot(file_url);
    } catch (error) {
      console.error("Error uploading screenshot:", error);
      alert("Failed to upload screenshot. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async () => {
    if (!selectedType || !message.trim()) {
      alert("Please select a feedback type and write a message");
      return;
    }

    await submitFeedbackMutation.mutateAsync({
      user_email: user?.email || "anonymous",
      page_url: window.location.href,
      feedback_type: selectedType,
      severity: severity,
      message: message.trim(),
      screenshot_url: screenshot || undefined,
      browser_info: navigator.userAgent
    });
  };

  // Floating Agent Head Button (Minimized State)
  if (!isExpanded) {
    return (
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", damping: 20 }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={() => setIsExpanded(true)}
        className="fixed bottom-6 right-6 z-50 group"
        style={{ width: "80px", height: "80px" }}
      >
        {/* Agent Head SVG */}
        <motion.svg
          width="80"
          height="80"
          viewBox="0 0 80 80"
          className="relative"
          animate={{
            rotateY: isHovered ? 0 : -90,
          }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          style={{ transformStyle: "preserve-3d" }}
        >
          {/* Pulsating glow effect */}
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
            <radialGradient id="glowGradient">
              <stop offset="0%" stopColor="#10b981" stopOpacity="0.8"/>
              <stop offset="100%" stopColor="#10b981" stopOpacity="0"/>
            </radialGradient>
          </defs>
          
          {/* Pulsating circle glow */}
          <motion.circle
            cx="40"
            cy="40"
            r="35"
            fill="url(#glowGradient)"
            animate={{
              scale: [1, 1.15, 1],
              opacity: [0.5, 0.8, 0.5]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />

          {/* Head outline (profile view when not hovered, front view when hovered) */}
          <g filter="url(#glow)">
            {/* Head shape */}
            <motion.ellipse
              cx={isHovered ? "40" : "45"}
              cy="40"
              rx={isHovered ? "22" : "18"}
              ry="28"
              fill="none"
              stroke="#10b981"
              strokeWidth="2.5"
              animate={{
                strokeOpacity: [0.7, 1, 0.7]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            
            {/* Compass needle integrated into head */}
            <motion.line
              x1="40"
              y1="32"
              x2="40"
              y2="22"
              stroke="#10b981"
              strokeWidth="2"
              strokeLinecap="round"
              animate={{
                rotate: isHovered ? 0 : [0, 10, -10, 0]
              }}
              transition={{
                duration: 3,
                repeat: isHovered ? 0 : Infinity,
                ease: "easeInOut"
              }}
              style={{ originX: "40px", originY: "40px" }}
            />
            
            {/* Eyes - closed when not hovered, open when hovered */}
            <AnimatePresence mode="wait">
              {!isHovered ? (
                // Closed eyes (profile view)
                <motion.g
                  key="closed"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <line x1="42" y1="38" x2="50" y2="38" stroke="#10b981" strokeWidth="2" strokeLinecap="round"/>
                </motion.g>
              ) : (
                // Open eyes (front view)
                <motion.g
                  key="open"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <circle cx="33" cy="38" r="3" fill="#10b981"/>
                  <circle cx="47" cy="38" r="3" fill="#10b981"/>
                </motion.g>
              )}
            </AnimatePresence>

            {/* Subtle smile */}
            {isHovered && (
              <motion.path
                d="M 30 48 Q 40 52 50 48"
                fill="none"
                stroke="#10b981"
                strokeWidth="2"
                strokeLinecap="round"
                initial={{ opacity: 0, pathLength: 0 }}
                animate={{ opacity: 1, pathLength: 1 }}
                transition={{ duration: 0.3 }}
              />
            )}
          </g>
        </motion.svg>

        {/* "Feedback" text on hover */}
        <AnimatePresence>
          {isHovered && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 whitespace-nowrap"
            >
              <span className="text-sm font-semibold text-gray-700">Feedback</span>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    );
  }

  // Expanded Feedback Panel
  return (
    <>
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-40 bg-black/30 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Agent Head Shadow Background */}
      <motion.div
        initial={{ scale: 1, opacity: 0 }}
        animate={{ scale: 10, opacity: 0.03 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="fixed top-1/2 left-1/2 z-40 pointer-events-none"
        style={{ transform: "translate(-50%, -50%)" }}
      >
        <svg width="80" height="80" viewBox="0 0 80 80">
          <ellipse cx="40" cy="40" rx="22" ry="28" fill="#10b981"/>
          <circle cx="33" cy="38" r="3" fill="#000"/>
          <circle cx="47" cy="38" r="3" fill="#000"/>
        </svg>
      </motion.div>

      {/* Feedback Panel */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9, x: 50, y: 50 }}
        animate={{ opacity: 1, scale: 1, x: 0, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, x: 50, y: 50 }}
        className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50 w-[calc(100vw-2rem)] md:w-full md:max-w-md max-h-[calc(100vh-2rem)] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="rounded-3xl shadow-2xl overflow-hidden"
          style={{
            background: "rgba(255, 255, 255, 0.98)",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(16, 185, 129, 0.2)",
          }}
        >
          {/* Success State */}
          <AnimatePresence>
            {showSuccess && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="absolute inset-0 z-10 flex items-center justify-center"
                style={{
                  background: "rgba(255, 255, 255, 0.98)",
                  backdropFilter: "blur(10px)",
                }}
              >
                <div className="text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center"
                    style={{
                      background: "linear-gradient(145deg, #10b981 0%, #059669 100%)",
                      boxShadow: "0 8px 24px rgba(16, 185, 129, 0.4)",
                    }}
                  >
                    <Check className="w-10 h-10 text-white" />
                  </motion.div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
                  <p className="text-gray-600">Your feedback helps us improve</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Header */}
          <div
            className="p-4 md:p-6 relative"
            style={{
              background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
            }}
          >
            <button
              onClick={handleClose}
              className="absolute top-3 right-3 md:top-4 md:right-4 p-2 rounded-xl bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>

            <div className="flex items-center gap-3 mb-2 pr-10">
              <div
                className="w-10 h-10 md:w-12 md:h-12 rounded-2xl flex items-center justify-center relative"
                style={{
                  background: "rgba(255, 255, 255, 0.2)",
                  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.3)",
                }}
              >
                <svg width="24" height="24" viewBox="0 0 24 24">
                  <ellipse cx="12" cy="12" rx="6" ry="8" fill="none" stroke="white" strokeWidth="2"/>
                  <circle cx="10" cy="11" r="1.5" fill="white"/>
                  <circle cx="14" cy="11" r="1.5" fill="white"/>
                </svg>
              </div>
              <div>
                <h2 className="text-xl md:text-2xl font-bold text-white">Share Your Feedback</h2>
                <p className="text-green-100 text-xs md:text-sm">Help us build better</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 md:p-6 space-y-4 md:space-y-6">
            {/* Beta Badge */}
            <div
              className="px-3 md:px-4 py-2 md:py-3 rounded-2xl"
              style={{
                background: "linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)",
                border: "1px solid rgba(245, 158, 11, 0.2)",
              }}
            >
              <p className="text-xs md:text-sm text-amber-900 font-medium">
                🚀 <strong>Beta Testing:</strong> Your feedback shapes AgentCraft's future!
              </p>
            </div>

            {/* Feedback Type Selection */}
            <div>
              <Label className="text-xs md:text-sm font-bold text-gray-900 mb-2 md:mb-3 block">What's on your mind?</Label>
              <div className="grid grid-cols-2 gap-2 md:gap-3">
                {FEEDBACK_TYPES.map((type) => {
                  const Icon = type.icon;
                  const isSelected = selectedType === type.id;
                  
                  return (
                    <button
                      key={type.id}
                      onClick={() => setSelectedType(type.id)}
                      className={`p-3 md:p-4 rounded-2xl transition-all ${
                        isSelected ? 'ring-2 ring-green-500' : ''
                      }`}
                      style={{
                        background: isSelected
                          ? "linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(5, 150, 105, 0.1) 100%)"
                          : "rgba(243, 244, 246, 0.8)",
                        border: isSelected
                          ? "2px solid rgba(16, 185, 129, 0.3)"
                          : "1px solid rgba(0, 0, 0, 0.05)",
                      }}
                    >
                      <div
                        className={`w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center mx-auto mb-1 md:mb-2 bg-gradient-to-br ${type.color}`}
                      >
                        <Icon className="w-4 h-4 md:w-5 md:h-5 text-white" />
                      </div>
                      <div className="text-xs font-bold text-gray-900 mb-0.5">{type.label}</div>
                      <div className="text-[10px] md:text-xs text-gray-600">{type.description}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Severity/Priority */}
            {(selectedType === "bug" || selectedType === "feature_request") && (
              <div>
                <Label className="text-xs md:text-sm font-bold text-gray-900 mb-2 md:mb-3 block">
                  {selectedType === "bug" ? "Severity" : "Priority"}
                </Label>
                <div className="flex gap-2">
                  {SEVERITY_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setSeverity(option.value)}
                      className={`flex-1 px-3 md:px-4 py-2 md:py-3 rounded-xl transition-all text-xs md:text-sm ${
                        severity === option.value ? 'ring-2 ring-green-500' : ''
                      }`}
                      style={{
                        background: severity === option.value
                          ? "linear-gradient(135deg, #10b981 0%, #059669 100%)"
                          : "rgba(243, 244, 246, 0.8)",
                        border: "1px solid rgba(0, 0, 0, 0.05)",
                        color: severity === option.value ? "white" : "#374151"
                      }}
                    >
                      <div className="font-medium">
                        {option.emoji} {option.label.split(' ')[0]}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Message */}
            <div>
              <Label htmlFor="message" className="text-xs md:text-sm font-bold text-gray-900 mb-2 md:mb-3 block">
                Tell us more
              </Label>
              <Textarea
                id="message"
                placeholder="What would you like us to know?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="min-h-24 md:min-h-32 resize-none rounded-2xl border-gray-200 text-sm"
                style={{
                  background: "rgba(243, 244, 246, 0.5)",
                }}
              />
              <p className="text-[10px] md:text-xs text-gray-500 mt-2">
                📍 Current page: {window.location.pathname}
              </p>
            </div>

            {/* Screenshot Upload */}
            <div>
              <Label className="text-xs md:text-sm font-bold text-gray-900 mb-2 md:mb-3 block">
                Screenshot (optional)
              </Label>
              <div className="flex gap-3">
                <label
                  className="flex-1 px-3 md:px-4 py-2 md:py-3 rounded-2xl cursor-pointer transition-all hover:bg-gray-100"
                  style={{
                    background: "rgba(243, 244, 246, 0.8)",
                    border: "1px dashed rgba(0, 0, 0, 0.2)",
                  }}
                >
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleScreenshotUpload}
                    className="hidden"
                    disabled={isUploading}
                  />
                  <div className="flex items-center justify-center gap-2 text-xs md:text-sm font-medium text-gray-700">
                    {isUploading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Uploading...
                      </>
                    ) : screenshot ? (
                      <>
                        <Check className="w-4 h-4 text-green-600" />
                        Screenshot added
                      </>
                    ) : (
                      <>
                        <Camera className="w-4 h-4" />
                        Add screenshot
                      </>
                    )}
                  </div>
                </label>
              </div>
              {screenshot && (
                <div className="mt-3">
                  <img
                    src={screenshot}
                    alt="Screenshot"
                    className="w-full rounded-xl border border-gray-200"
                  />
                </div>
              )}
            </div>

            {/* Submit Button */}
            <div className="flex gap-2 md:gap-3">
              <Button
                onClick={handleClose}
                variant="outline"
                className="flex-1 h-10 md:h-12 rounded-2xl text-sm"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={!selectedType || !message.trim() || submitFeedbackMutation.isLoading}
                className="flex-1 h-10 md:h-12 rounded-2xl text-white font-semibold text-sm"
                style={{
                  background: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
                  boxShadow: "0 4px 12px rgba(16, 185, 129, 0.3)",
                }}
              >
                {submitFeedbackMutation.isLoading ? (
                  <>
                    <Loader2 className="w-4 md:w-5 h-4 md:h-5 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 md:w-5 h-4 md:h-5 mr-2" />
                    Send Feedback
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}
