import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  AlertTriangle, CheckCircle, XCircle, Clock, 
  ChevronDown, ChevronUp, Loader2, Play, ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const priorityColors = {
  critical: 'bg-red-100 text-red-700 border-red-200',
  high: 'bg-orange-100 text-orange-700 border-orange-200',
  medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  low: 'bg-blue-100 text-blue-700 border-blue-200'
};

const statusIcons = {
  pending_review: Clock,
  approved: CheckCircle,
  rejected: XCircle,
  applied: CheckCircle,
  expired: Clock
};

export default function ImprovementProposals() {
  const [expandedId, setExpandedId] = useState(null);
  const [reviewNotes, setReviewNotes] = useState({});
  const queryClient = useQueryClient();

  const { data: proposals = [], isLoading } = useQuery({
    queryKey: ['improvementProposals'],
    queryFn: () => base44.entities.ImprovementProposal.list('-created_date', 50),
    refetchInterval: 10000
  });

  const updateProposalMutation = useMutation({
    mutationFn: async ({ proposalId, status, notes }) => {
      await base44.entities.ImprovementProposal.update(proposalId, {
        status,
        review_notes: notes,
        reviewed_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['improvementProposals'] });
    }
  });

  const applyProposalMutation = useMutation({
    mutationFn: async (proposalId) => {
      const response = await base44.functions.invoke('proactiveMonitor', {
        action: 'apply',
        proposalId
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['improvementProposals'] });
      queryClient.invalidateQueries({ queryKey: ['agents'] });
    }
  });

  const scanAgentsMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('proactiveMonitor', { action: 'scan' });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['improvementProposals'] });
    }
  });

  const handleApprove = async (proposalId) => {
    await updateProposalMutation.mutateAsync({
      proposalId,
      status: 'approved',
      notes: reviewNotes[proposalId] || ''
    });
  };

  const handleReject = async (proposalId) => {
    await updateProposalMutation.mutateAsync({
      proposalId,
      status: 'rejected',
      notes: reviewNotes[proposalId] || ''
    });
  };

  const handleApply = async (proposalId) => {
    await applyProposalMutation.mutateAsync(proposalId);
  };

  const pendingProposals = proposals.filter(p => p.status === 'pending_review');
  const approvedProposals = proposals.filter(p => p.status === 'approved');
  const otherProposals = proposals.filter(p => !['pending_review', 'approved'].includes(p.status));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-lg flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          Improvement Proposals
        </h3>
        <Button
          onClick={() => scanAgentsMutation.mutate()}
          disabled={scanAgentsMutation.isPending}
          variant="outline"
          size="sm"
        >
          {scanAgentsMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Play className="w-4 h-4 mr-2" />
          )}
          Scan All Agents
        </Button>
      </div>

      {pendingProposals.length === 0 && approvedProposals.length === 0 && (
        <Card className="p-8 text-center">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h4 className="font-semibold text-lg mb-2">All Clear!</h4>
          <p className="text-gray-600 text-sm">No improvement proposals pending review.</p>
        </Card>
      )}

      {pendingProposals.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-sm text-gray-500 uppercase">Pending Review ({pendingProposals.length})</h4>
          {pendingProposals.map((proposal) => (
            <ProposalCard
              key={proposal.id}
              proposal={proposal}
              expanded={expandedId === proposal.id}
              onToggle={() => setExpandedId(expandedId === proposal.id ? null : proposal.id)}
              reviewNotes={reviewNotes[proposal.id] || ''}
              onNotesChange={(notes) => setReviewNotes({ ...reviewNotes, [proposal.id]: notes })}
              onApprove={() => handleApprove(proposal.id)}
              onReject={() => handleReject(proposal.id)}
              isUpdating={updateProposalMutation.isPending}
            />
          ))}
        </div>
      )}

      {approvedProposals.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-sm text-gray-500 uppercase">Ready to Apply ({approvedProposals.length})</h4>
          {approvedProposals.map((proposal) => (
            <Card key={proposal.id} className="p-4 border-green-200 bg-green-50">
              <div className="flex items-center justify-between">
                <div>
                  <span className="font-semibold">{proposal.agent_name}</span>
                  <span className="text-sm text-gray-600 ml-2">
                    {proposal.suggestions?.length || 0} changes ready
                  </span>
                </div>
                <Button
                  onClick={() => handleApply(proposal.id)}
                  disabled={applyProposalMutation.isPending}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  {applyProposalMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <ArrowRight className="w-4 h-4 mr-2" />
                  )}
                  Apply Changes
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {otherProposals.length > 0 && (
        <div className="space-y-4">
          <h4 className="font-semibold text-sm text-gray-500 uppercase">History ({otherProposals.length})</h4>
          <div className="space-y-2">
            {otherProposals.slice(0, 5).map((proposal) => {
              const StatusIcon = statusIcons[proposal.status];
              return (
                <div key={proposal.id} className="p-3 bg-gray-50 rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <StatusIcon className={`w-4 h-4 ${
                      proposal.status === 'applied' ? 'text-green-500' : 
                      proposal.status === 'rejected' ? 'text-red-500' : 'text-gray-400'
                    }`} />
                    <span className="text-sm">{proposal.agent_name}</span>
                  </div>
                  <span className="text-xs text-gray-500 capitalize">{proposal.status.replace('_', ' ')}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function ProposalCard({ proposal, expanded, onToggle, reviewNotes, onNotesChange, onApprove, onReject, isUpdating }) {
  return (
    <Card className={`overflow-hidden border-2 ${priorityColors[proposal.priority]}`}>
      <div 
        className="p-4 cursor-pointer flex items-center justify-between"
        onClick={onToggle}
      >
        <div className="flex items-center gap-3">
          <span className={`text-xs font-bold px-2 py-1 rounded uppercase ${priorityColors[proposal.priority]}`}>
            {proposal.priority}
          </span>
          <div>
            <span className="font-semibold">{proposal.agent_name}</span>
            <p className="text-sm text-gray-600">
              {proposal.trigger_reason === 'low_audit_score' ? 'Audit Score' : 'Pass Rate'}: {proposal.trigger_value?.toFixed(1)}% 
              (threshold: {proposal.threshold}%)
            </p>
          </div>
        </div>
        {expanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t"
          >
            <div className="p-4 space-y-4">
              <div>
                <h5 className="font-semibold text-sm mb-2">Assessment</h5>
                <p className="text-sm text-gray-600">{proposal.overall_assessment}</p>
              </div>

              {proposal.suggestions?.length > 0 && (
                <div>
                  <h5 className="font-semibold text-sm mb-2">Suggested Changes ({proposal.suggestions.length})</h5>
                  <div className="space-y-2">
                    {proposal.suggestions.map((s, i) => (
                      <div key={i} className="p-3 bg-gray-50 rounded-lg text-sm">
                        <div className="font-medium">{s.field}</div>
                        <div className="text-gray-500 text-xs mt-1">
                          Current: {s.current_value || 'Not set'}
                        </div>
                        <div className="text-green-700 text-xs">
                          Suggested: {s.suggested_value}
                        </div>
                        <div className="text-gray-600 text-xs mt-1">{s.reason}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <h5 className="font-semibold text-sm mb-2">Review Notes (Optional)</h5>
                <Textarea
                  value={reviewNotes}
                  onChange={(e) => onNotesChange(e.target.value)}
                  placeholder="Add any notes about your decision..."
                  className="h-20"
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={(e) => { e.stopPropagation(); onReject(); }}
                  disabled={isUpdating}
                  variant="outline"
                  className="flex-1 border-red-200 text-red-700 hover:bg-red-50"
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Reject
                </Button>
                <Button
                  onClick={(e) => { e.stopPropagation(); onApprove(); }}
                  disabled={isUpdating}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Approve
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}