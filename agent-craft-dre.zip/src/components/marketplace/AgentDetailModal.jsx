import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  X, Bot, Star, Download, Zap, GitBranch, 
  Calendar, TrendingUp, History, Tag, Shield
} from "lucide-react";
import { motion } from "framer-motion";
import CertificationBadge from "./CertificationBadge";

export default function AgentDetailModal({ agent, onClose, onPurchase, isPurchased, isOwn }) {
  const [activeTab, setActiveTab] = useState("overview");

  if (!agent) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b bg-gray-50">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className="w-16 h-16 rounded-xl bg-gray-100 flex items-center justify-center">
                <Bot className="w-8 h-8 text-gray-900" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-2xl font-bold text-gray-900">{agent.name}</h2>
                  <CertificationBadge status={agent.certification_status} size="sm" />
                </div>
                <div className="flex items-center gap-3 text-sm text-gray-600">
                  <span>By {agent.creator_name || agent.created_by?.split('@')[0]}</span>
                  <span>•</span>
                  <span>v{agent.version || '1.0.0'}</span>
                </div>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-6 mt-4">
            <div className="flex items-center gap-1 text-sm">
              <Download className="w-4 h-4 text-gray-500" />
              <span className="font-medium">{agent.download_count || 0}</span>
              <span className="text-gray-500">downloads</span>
            </div>
            <div className="flex items-center gap-1 text-sm">
              <Star className="w-4 h-4 text-amber-500" />
              <span className="font-medium">{(agent.average_rating || 0).toFixed(1)}</span>
              <span className="text-gray-500">({agent.review_count || 0} reviews)</span>
            </div>
            {agent.last_audit_score && (
              <div className="flex items-center gap-1 text-sm">
                <Shield className="w-4 h-4 text-green-500" />
                <span className="font-medium text-green-600">{agent.last_audit_score}%</span>
                <span className="text-gray-500">quality</span>
              </div>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <div className="flex">
            {['overview', 'includes', 'versions'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-3 text-sm font-medium capitalize ${
                  activeTab === tab 
                    ? 'border-b-2 border-gray-900 text-gray-900' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[400px]">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2 text-gray-900">Description</h3>
                <p className="text-gray-600">{agent.description}</p>
              </div>

              {agent.tags?.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Tags</h3>
                  <div className="flex flex-wrap gap-2">
                    {agent.tags.map((tag, i) => (
                      <span key={i} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {agent.certification_status === 'certified' && (
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield className="w-5 h-5 text-blue-500" />
                    <span className="font-semibold text-blue-900">Certified Agent</span>
                  </div>
                  <p className="text-sm text-blue-700">
                    This agent has passed our quality audit and meets platform standards for reliability and performance.
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'includes' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2 text-gray-900">
                  <Zap className="w-4 h-4 text-gray-900" />
                  Abilities ({agent.abilities?.length || 0})
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {agent.abilities?.map((ability, i) => (
                    <div key={i} className="p-3 bg-gray-100 rounded-lg text-sm text-gray-700">
                      {ability}
                    </div>
                  ))}
                </div>
              </div>

              {agent.assigned_actions?.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-500" />
                    Actions Included ({agent.assigned_actions.length})
                  </h3>
                  <p className="text-sm text-gray-600">
                    This agent comes with {agent.assigned_actions.length} pre-configured actions.
                  </p>
                </div>
              )}

              {agent.included_workflows?.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-3 flex items-center gap-2">
                    <GitBranch className="w-4 h-4 text-blue-500" />
                    Workflows Included ({agent.included_workflows.length})
                  </h3>
                  <p className="text-sm text-gray-600">
                    This package includes {agent.included_workflows.length} automated workflows.
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'versions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-900">Version History</h3>
                <span className="text-sm text-gray-500">Current: v{agent.version || '1.0.0'}</span>
              </div>

              {agent.version_history?.length > 0 ? (
                <div className="space-y-3">
                  {agent.version_history.map((v, i) => (
                    <div key={i} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">v{v.version}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(v.released_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{v.changelog}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>No version history available</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t bg-gray-50">
          <div className="flex items-center justify-between">
            <div>
              {agent.price === 0 ? (
                <span className="text-2xl font-bold text-green-600">FREE</span>
              ) : (
                <span className="text-2xl font-bold">${agent.price}</span>
              )}
            </div>
            {isOwn ? (
              <Button disabled variant="outline">Your Agent</Button>
            ) : isPurchased ? (
              <Button disabled variant="outline">Already Owned</Button>
            ) : (
              <Button 
                onClick={() => onPurchase(agent)}
                className="bg-gray-900 hover:bg-gray-800 text-white px-8"
              >
                {agent.price === 0 ? 'Download Free' : 'Purchase Now'}
              </Button>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}