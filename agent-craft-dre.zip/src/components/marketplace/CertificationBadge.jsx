import { Shield, CheckCircle, Crown, Star } from "lucide-react";
import { motion } from "framer-motion";

const BADGE_CONFIG = {
  none: null,
  pending: {
    icon: Shield,
    label: "Pending Review",
    color: "bg-gray-100 text-gray-600 border-gray-300",
    iconColor: "text-gray-500"
  },
  certified: {
    icon: CheckCircle,
    label: "Certified",
    color: "bg-blue-100 text-blue-700 border-blue-300",
    iconColor: "text-blue-500"
  },
  premium: {
    icon: Crown,
    label: "Premium",
    color: "bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-700 border-amber-300",
    iconColor: "text-amber-500"
  }
};

export default function CertificationBadge({ status, size = "sm", showLabel = true }) {
  const config = BADGE_CONFIG[status];
  if (!config) return null;

  const Icon = config.icon;
  const sizeClasses = {
    xs: "text-xs px-1.5 py-0.5",
    sm: "text-xs px-2 py-1",
    md: "text-sm px-3 py-1.5",
    lg: "text-base px-4 py-2"
  };

  const iconSizes = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5"
  };

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`inline-flex items-center gap-1 rounded-full border ${config.color} ${sizeClasses[size]} font-medium`}
    >
      <Icon className={`${iconSizes[size]} ${config.iconColor}`} />
      {showLabel && <span>{config.label}</span>}
    </motion.div>
  );
}