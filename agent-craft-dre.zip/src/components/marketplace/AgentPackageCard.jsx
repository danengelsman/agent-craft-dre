import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Store, Download, Star, Zap, GitBranch, Bot, 
  Tag, Calendar, TrendingUp, Eye
} from "lucide-react";
import { motion } from "framer-motion";
import CertificationBadge from "./CertificationBadge";

const CATEGORY_LABELS = {
  productivity: "Productivity",
  customer_service: "Customer Service",
  sales: "Sales",
  content: "Content",
  data: "Data",
  other: "Other"
};

export default function AgentPackageCard({ 
  agent, 
  isPurchased, 
  isOwn, 
  onPurchase, 
  onReview,
  onViewDetails,
  isLoading 
}) {
  const hasActions = agent.assigned_actions?.length > 0;
  const hasWorkflows = agent.included_workflows?.length > 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="p-5 hover:shadow-xl transition-all duration-200 h-full flex flex-col relative overflow-hidden cursor-pointer hover:border-gray-300">
        {/* Featured Banner */}
        {agent.featured && (
          <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-orange-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
            ⭐ Featured
          </div>
        )}

        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
            <Bot className="w-6 h-6 text-gray-900" />
          </div>
          <div className="text-right">
            {agent.price === 0 ? (
              <span className="text-lg font-bold text-green-600">FREE</span>
            ) : (
              <span className="text-lg font-bold">${agent.price}</span>
            )}
            {agent.version && (
              <div className="text-xs text-gray-400">v{agent.version}</div>
            )}
          </div>
        </div>

        {/* Title & Badges */}
        <div className="mb-2">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            <h3 className="font-bold text-lg text-gray-900">{agent.name}</h3>
            <CertificationBadge status={agent.certification_status} size="xs" showLabel={false} />
          </div>
          {agent.category && agent.category !== 'other' && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
              {CATEGORY_LABELS[agent.category]}
            </span>
          )}
        </div>

        {/* Description */}
        <p className="text-gray-600 text-sm mb-3 line-clamp-2 flex-1">
          {agent.description}
        </p>

        {/* Package Contents */}
        <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
          <div className="flex items-center gap-1">
            <Zap className="w-3 h-3" />
            {agent.abilities?.length || 0} abilities
          </div>
          {hasActions && (
            <div className="flex items-center gap-1 text-amber-600">
              <Zap className="w-3 h-3" />
              {agent.assigned_actions.length} actions
            </div>
          )}
          {hasWorkflows && (
            <div className="flex items-center gap-1 text-blue-600">
              <GitBranch className="w-3 h-3" />
              {agent.included_workflows.length} workflows
            </div>
          )}
        </div>

        {/* Stats Row */}
        <div className="flex items-center gap-4 text-xs text-gray-500 mb-3 pb-3 border-b">
          <div className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            {agent.download_count || 0}
          </div>
          <div className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-500" />
            {(agent.average_rating || 0).toFixed(1)} ({agent.review_count || 0})
          </div>
          {agent.last_audit_score && (
            <div className="flex items-center gap-1 text-green-600">
              <TrendingUp className="w-3.5 h-3.5" />
              {agent.last_audit_score}% quality
            </div>
          )}
        </div>

        {/* Tags */}
        {agent.tags?.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {agent.tags.slice(0, 3).map((tag, i) => (
              <span key={i} className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full">
                #{tag}
              </span>
            ))}
            {agent.tags.length > 3 && (
              <span className="text-xs text-gray-400">+{agent.tags.length - 3}</span>
            )}
          </div>
        )}

        {/* Creator */}
        <div className="text-xs text-gray-500 mb-4">
          By {agent.creator_name || agent.created_by?.split('@')[0]}
        </div>

        {/* Actions */}
        <div className="flex gap-2 mt-auto">
          {isOwn ? (
            <Button disabled variant="outline" className="flex-1">
              Your Agent
            </Button>
          ) : isPurchased ? (
            <Button disabled variant="outline" className="flex-1">
              Owned
            </Button>
          ) : (
            <Button
              onClick={() => onPurchase(agent)}
              disabled={isLoading}
              className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
            >
              {agent.price === 0 ? 'Download' : 'Purchase'}
            </Button>
          )}
          <Button
            onClick={() => onViewDetails?.(agent)}
            variant="outline"
            size="icon"
          >
            <Eye className="w-4 h-4" />
          </Button>
          <Button
            onClick={() => onReview(agent)}
            variant="outline"
            size="icon"
          >
            <Star className="w-4 h-4" />
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}