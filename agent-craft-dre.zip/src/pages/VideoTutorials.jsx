import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Play, Clock, Award, CheckCircle, Video, User, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORIES = [
  { id: "getting_started", label: "Getting Started", icon: Sparkles },
  { id: "building_agents", label: "Building Agents", icon: User },
  { id: "marketplace", label: "Marketplace", icon: Award },
  { id: "advanced", label: "Advanced", icon: Video },
  { id: "tips", label: "Pro Tips", icon: CheckCircle },
];

export default function VideoTutorials() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("getting_started");
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [currentTimestamp, setCurrentTimestamp] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: videos = [] } = useQuery({
    queryKey: ['videoTutorials'],
    queryFn: () => base44.entities.VideoTutorial.list('order'),
    initialData: [],
    retry: 1,
  });

  const { data: userProgress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existing = await base44.entities.UserProgress.filter({ user_email: user.email });
      return existing[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
  });

  const markWatchedMutation = useMutation({
    mutationFn: async (video) => {
      if (!userProgress?.id) return;
      const newXp = (userProgress.xp || 0) + video.xp_reward;
      const newLevel = Math.floor(newXp / 200) + 1;
      await base44.entities.UserProgress.update(userProgress.id, {
        xp: newXp,
        level: newLevel
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
      alert(`+${selectedVideo.xp_reward} XP earned! 🎉`);
    },
    retry: 1,
  });

  const filteredVideos = videos.filter(v => v.category === selectedCategory);

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app py-16" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center mx-auto mb-6 shadow-xl">
            <Video className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-4">
            Video Tutorials
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Learn AgentCraft from our AI guide, step-by-step with visual walkthroughs
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex gap-3 overflow-x-auto pb-4 mb-12"
        >
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-gray-900 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <cat.icon className="w-5 h-5" />
              {cat.label}
            </button>
          ))}
        </motion.div>

        {/* Video Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredVideos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.05 }}
              onClick={() => setSelectedVideo(video)}
              className="ui-card overflow-hidden cursor-pointer group"
            >
              {/* Thumbnail */}
              <div className="relative h-48 bg-gradient-to-br from-gray-200 to-gray-300 overflow-hidden">
                {video.thumbnail_url ? (
                  <img src={video.thumbnail_url} alt={video.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Play className="w-16 h-16 text-gray-400" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                    <Play className="w-8 h-8 text-gray-900 ml-1" />
                  </div>
                </div>
                <div className="absolute top-4 right-4 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-sm text-white text-xs font-medium">
                  {video.duration_minutes} min
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm text-gray-600">
                    {video.avatar_config?.name || 'AI Guide'}
                  </span>
                </div>

                <h3 className="text-lg font-bold tracking-tight mb-2">
                  {video.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {video.description}
                </p>

                <div className="flex items-center justify-between">
                  <span className={`text-xs px-3 py-1 rounded-full ${
                    video.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                    video.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {video.difficulty}
                  </span>
                  <span className="text-sm text-gray-500 flex items-center gap-1">
                    <Award className="w-4 h-4" />
                    +{video.xp_reward} XP
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {filteredVideos.length === 0 && (
          <div className="text-center py-20">
            <Video className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-xl font-bold text-gray-700 mb-2">No videos yet</h3>
            <p className="text-gray-500">Videos coming soon for this category!</p>
          </div>
        )}

        {/* Video Modal */}
        <AnimatePresence>
          {selectedVideo && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
              onClick={() => setSelectedVideo(null)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-white rounded-3xl max-w-6xl w-full max-h-[90vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Video Player */}
                <div className="relative bg-black rounded-t-3xl" style={{ paddingBottom: '56.25%' }}>
                  <iframe
                    className="absolute inset-0 w-full h-full rounded-t-3xl"
                    src={selectedVideo.video_url}
                    title={selectedVideo.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>

                {/* Video Info */}
                <div className="p-8">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h2 className="text-3xl font-bold tracking-tight mb-2">
                        {selectedVideo.title}
                      </h2>
                      <p className="text-gray-600 mb-4">{selectedVideo.description}</p>
                      
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span>{selectedVideo.duration_minutes} minutes</span>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs ${
                          selectedVideo.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                          selectedVideo.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {selectedVideo.difficulty}
                        </span>
                      </div>
                    </div>

                    <Button
                      onClick={() => markWatchedMutation.mutate(selectedVideo)}
                    >
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Mark Complete
                    </Button>
                  </div>

                  {/* Key Timestamps */}
                  {selectedVideo.key_timestamps && selectedVideo.key_timestamps.length > 0 && (
                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-bold mb-4">Key Moments</h3>
                      <div className="grid gap-3">
                        {selectedVideo.key_timestamps.map((timestamp, idx) => (
                          <button
                            key={idx}
                            className="flex items-center gap-4 p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors text-left"
                            onClick={() => setCurrentTimestamp(timestamp)}
                          >
                            {timestamp.screenshot_url && (
                              <img
                                src={timestamp.screenshot_url}
                                alt={timestamp.label}
                                className="w-24 h-16 rounded-lg object-cover"
                              />
                            )}
                            <div>
                              <div className="text-sm font-bold text-gray-900">{timestamp.label}</div>
                              <div className="text-xs text-gray-500">{timestamp.time}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}