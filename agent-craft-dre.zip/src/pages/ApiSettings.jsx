import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import ContextualHelp from "../components/ContextualHelp";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { 
  Key, Plus, Trash2, Copy, Eye, EyeOff, Webhook, 
  Check, X, Loader2, ExternalLink, Zap, RefreshCw,
  Shield, Clock, AlertTriangle
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const AVAILABLE_SCOPES = [
  { id: "read", label: "Read", description: "Read agents, workflows, data" },
  { id: "write", label: "Write", description: "Create and update resources" },
  { id: "delete", label: "Delete", description: "Delete resources" },
  { id: "webhooks", label: "Webhooks", description: "Manage webhooks" }
];

const WEBHOOK_EVENTS = [
  { id: "agent.created", label: "Agent Created" },
  { id: "agent.updated", label: "Agent Updated" },
  { id: "agent.deleted", label: "Agent Deleted" },
  { id: "chat.message", label: "Chat Message Sent" },
  { id: "workflow.completed", label: "Workflow Completed" },
  { id: "workflow.failed", label: "Workflow Failed" },
  { id: "action.executed", label: "Action Executed" }
];

export default function ApiSettings() {
  const [user, setUser] = useState(null);
  const [showNewKeyModal, setShowNewKeyModal] = useState(false);
  const [showNewWebhookModal, setShowNewWebhookModal] = useState(false);
  const [newKeyData, setNewKeyData] = useState({ name: "", scopes: ["read"] });
  const [newWebhookData, setNewWebhookData] = useState({ name: "", url: "", events: [] });
  const [generatedKey, setGeneratedKey] = useState(null);
  const [copiedId, setCopiedId] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: apiKeys = [], isLoading: keysLoading } = useQuery({
    queryKey: ['apiKeys'],
    queryFn: () => base44.entities.ApiKey.list('-created_date'),
    enabled: !!user
  });

  const { data: webhooks = [], isLoading: webhooksLoading } = useQuery({
    queryKey: ['webhooks'],
    queryFn: () => base44.entities.Webhook.list('-created_date'),
    enabled: !!user
  });

  const createKeyMutation = useMutation({
    mutationFn: async (data) => {
      // Generate a random API key
      const key = `ac_${crypto.randomUUID().replace(/-/g, '')}`;
      const keyPrefix = key.substring(0, 11);
      
      // Simple hash (in production, use proper hashing on backend)
      const encoder = new TextEncoder();
      const keyData = encoder.encode(key);
      const hashBuffer = await crypto.subtle.digest('SHA-256', keyData);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const keyHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
      
      await base44.entities.ApiKey.create({
        name: data.name,
        key_prefix: keyPrefix,
        key_hash: keyHash,
        scopes: data.scopes,
        status: "active"
      });
      
      return key; // Return full key only once
    },
    onSuccess: (key) => {
      setGeneratedKey(key);
      queryClient.invalidateQueries({ queryKey: ['apiKeys'] });
    }
  });

  const revokeKeyMutation = useMutation({
    mutationFn: (keyId) => base44.entities.ApiKey.update(keyId, { status: "revoked" }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['apiKeys'] })
  });

  const deleteKeyMutation = useMutation({
    mutationFn: (keyId) => base44.entities.ApiKey.delete(keyId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['apiKeys'] })
  });

  const createWebhookMutation = useMutation({
    mutationFn: async (data) => {
      const secret = `whsec_${crypto.randomUUID().replace(/-/g, '')}`;
      return base44.entities.Webhook.create({
        ...data,
        secret,
        status: "active"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['webhooks'] });
      setShowNewWebhookModal(false);
      setNewWebhookData({ name: "", url: "", events: [] });
    }
  });

  const deleteWebhookMutation = useMutation({
    mutationFn: (id) => base44.entities.Webhook.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['webhooks'] })
  });

  const toggleWebhookMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Webhook.update(id, { 
      status: status === 'active' ? 'paused' : 'active' 
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['webhooks'] })
  });

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCreateKey = () => {
    if (!newKeyData.name.trim()) return;
    createKeyMutation.mutate(newKeyData);
  };

  const handleCreateWebhook = () => {
    if (!newWebhookData.name.trim() || !newWebhookData.url.trim() || newWebhookData.events.length === 0) return;
    createWebhookMutation.mutate(newWebhookData);
  };

  const toggleScope = (scopeId) => {
    setNewKeyData(prev => ({
      ...prev,
      scopes: prev.scopes.includes(scopeId)
        ? prev.scopes.filter(s => s !== scopeId)
        : [...prev.scopes, scopeId]
    }));
  };

  const toggleEvent = (eventId) => {
    setNewWebhookData(prev => ({
      ...prev,
      events: prev.events.includes(eventId)
        ? prev.events.filter(e => e !== eventId)
        : [...prev.events, eventId]
    }));
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '68rem' }}>
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 text-gray-900">API & Integrations</h1>
          <p className="text-gray-600">Manage API keys, webhooks, and external integrations</p>
        </div>

        {/* API Keys Section */}
        <Card className="p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center">
                <Key className="w-5 h-5 text-gray-900" />
              </div>
              <div>
                <h2 className="font-bold text-lg flex items-center gap-1 text-gray-900">
                  API Keys
                  <ContextualHelp helpKey="api_key" />
                </h2>
                <p className="text-sm text-gray-500">Generate keys to access the API programmatically</p>
              </div>
            </div>
            <Button onClick={() => setShowNewKeyModal(true)} className="bg-gray-900 hover:bg-gray-800 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Key
            </Button>
          </div>

          {keysLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            </div>
          ) : apiKeys.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Key className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No API keys yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {apiKeys.map((key) => (
                <div 
                  key={key.id} 
                  className={`p-4 rounded-xl border ${key.status === 'revoked' ? 'bg-gray-50 opacity-60' : 'bg-white'}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${key.status === 'active' ? 'bg-green-500' : 'bg-gray-400'}`} />
                      <div>
                        <div className="font-medium">{key.name}</div>
                        <div className="text-sm text-gray-500 font-mono">{key.key_prefix}...</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right text-sm text-gray-500">
                        <div>{key.usage_count || 0} requests</div>
                        {key.last_used_at && (
                          <div className="text-xs">Last used {new Date(key.last_used_at).toLocaleDateString()}</div>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        {key.status === 'active' && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => revokeKeyMutation.mutate(key.id)}
                          >
                            Revoke
                          </Button>
                        )}
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => deleteKeyMutation.mutate(key.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-2">
                    {key.scopes?.map(scope => (
                      <span key={scope} className="px-2 py-0.5 text-xs rounded-full bg-purple-100 text-purple-700">
                        {scope}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Webhooks Section */}
        <Card className="p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center">
                <Webhook className="w-5 h-5 text-gray-900" />
              </div>
              <div>
                <h2 className="font-bold text-lg flex items-center gap-1 text-gray-900">
                  Webhooks
                  <ContextualHelp helpKey="webhooks" />
                </h2>
                <p className="text-sm text-gray-500">Receive real-time event notifications</p>
              </div>
            </div>
            <Button onClick={() => setShowNewWebhookModal(true)} variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Add Webhook
            </Button>
          </div>

          {webhooksLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            </div>
          ) : webhooks.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Webhook className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No webhooks configured</p>
            </div>
          ) : (
            <div className="space-y-3">
              {webhooks.map((webhook) => (
                <div key={webhook.id} className="p-4 rounded-xl border bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        webhook.status === 'active' ? 'bg-green-500' : 
                        webhook.status === 'failed' ? 'bg-red-500' : 'bg-gray-400'
                      }`} />
                      <div>
                        <div className="font-medium">{webhook.name}</div>
                        <div className="text-sm text-gray-500 font-mono truncate max-w-md">{webhook.url}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => toggleWebhookMutation.mutate({ id: webhook.id, status: webhook.status })}
                      >
                        {webhook.status === 'active' ? 'Pause' : 'Enable'}
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-red-600"
                        onClick={() => deleteWebhookMutation.mutate(webhook.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {webhook.events?.map(event => (
                      <span key={event} className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-700">
                        {event}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Check className="w-3 h-3 text-green-500" />
                      {webhook.success_count || 0} delivered
                    </span>
                    <span className="flex items-center gap-1">
                      <X className="w-3 h-3 text-red-500" />
                      {webhook.failure_count || 0} failed
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* External Integrations */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center">
              <Zap className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h2 className="font-bold text-lg">External Integrations</h2>
              <p className="text-sm text-gray-500">Connect with automation platforms</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <a 
              href="https://zapier.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-4 rounded-xl border hover:border-orange-300 hover:bg-orange-50 transition-colors group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="font-bold text-lg">Zapier</div>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-orange-500" />
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Connect AgentCraft to 5,000+ apps with no code
              </p>
              <div className="text-xs text-orange-600">Use webhooks to trigger Zaps →</div>
            </a>

            <a 
              href="https://make.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-4 rounded-xl border hover:border-purple-300 hover:bg-purple-50 transition-colors group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="font-bold text-lg">Make (Integromat)</div>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-purple-500" />
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Build complex automations with visual workflows
              </p>
              <div className="text-xs text-purple-600">Use webhooks to trigger scenarios →</div>
            </a>
          </div>

          <div className="mt-6 p-4 rounded-xl bg-gray-100">
            <h3 className="font-medium mb-2">API Base URL</h3>
            <div className="flex items-center gap-2">
              <code className="flex-1 p-2 bg-white rounded border text-sm font-mono">
                https://api.agentcraft.app/v1
              </code>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => copyToClipboard('https://api.agentcraft.app/v1', 'baseurl')}
              >
                {copiedId === 'baseurl' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </Card>

        {/* Create API Key Modal */}
        <AnimatePresence>
          {showNewKeyModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => {
                if (!generatedKey) {
                  setShowNewKeyModal(false);
                  setNewKeyData({ name: "", scopes: ["read"] });
                }
              }}
            >
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                className="bg-white rounded-2xl max-w-md w-full p-6"
                onClick={e => e.stopPropagation()}
              >
                {generatedKey ? (
                  <>
                    <div className="text-center mb-4">
                      <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-3">
                        <Check className="w-6 h-6 text-green-600" />
                      </div>
                      <h3 className="font-bold text-lg">API Key Created</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Copy this key now. You won't be able to see it again.
                      </p>
                    </div>
                    <div className="p-3 bg-gray-100 rounded-lg mb-4">
                      <code className="text-sm font-mono break-all">{generatedKey}</code>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1"
                        onClick={() => copyToClipboard(generatedKey, 'newkey')}
                      >
                        {copiedId === 'newkey' ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                        {copiedId === 'newkey' ? 'Copied!' : 'Copy Key'}
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => {
                          setShowNewKeyModal(false);
                          setGeneratedKey(null);
                          setNewKeyData({ name: "", scopes: ["read"] });
                        }}
                      >
                        Done
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <h3 className="font-bold text-lg mb-4">Create API Key</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Name</label>
                        <Input
                          placeholder="e.g., Production Key"
                          value={newKeyData.name}
                          onChange={(e) => setNewKeyData({ ...newKeyData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-1">
                          Permissions
                          <ContextualHelp helpKey="api_scopes" position="right" />
                        </label>
                        <div className="space-y-2">
                          {AVAILABLE_SCOPES.map(scope => (
                            <label key={scope.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={newKeyData.scopes.includes(scope.id)}
                                onChange={() => toggleScope(scope.id)}
                                className="rounded"
                              />
                              <div>
                                <div className="font-medium text-sm">{scope.label}</div>
                                <div className="text-xs text-gray-500">{scope.description}</div>
                              </div>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-6">
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={() => {
                          setShowNewKeyModal(false);
                          setNewKeyData({ name: "", scopes: ["read"] });
                        }}
                      >
                        Cancel
                      </Button>
                      <Button 
                        className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
                        onClick={handleCreateKey}
                        disabled={!newKeyData.name.trim() || createKeyMutation.isPending}
                      >
                        {createKeyMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          'Create Key'
                        )}
                      </Button>
                    </div>
                  </>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Create Webhook Modal */}
        <AnimatePresence>
          {showNewWebhookModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => setShowNewWebhookModal(false)}
            >
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                className="bg-white rounded-2xl max-w-md w-full p-6 max-h-[80vh] overflow-y-auto"
                onClick={e => e.stopPropagation()}
              >
                <h3 className="font-bold text-lg mb-4">Add Webhook</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Name</label>
                    <Input
                      placeholder="e.g., Zapier Integration"
                      value={newWebhookData.name}
                      onChange={(e) => setNewWebhookData({ ...newWebhookData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Endpoint URL</label>
                    <Input
                      placeholder="https://hooks.zapier.com/..."
                      value={newWebhookData.url}
                      onChange={(e) => setNewWebhookData({ ...newWebhookData, url: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Events to Subscribe</label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {WEBHOOK_EVENTS.map(event => (
                        <label key={event.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={newWebhookData.events.includes(event.id)}
                            onChange={() => toggleEvent(event.id)}
                            className="rounded"
                          />
                          <span className="text-sm">{event.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 mt-6">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setShowNewWebhookModal(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    className="flex-1 bg-gray-900 hover:bg-gray-800 text-white"
                    onClick={handleCreateWebhook}
                    disabled={!newWebhookData.name.trim() || !newWebhookData.url.trim() || newWebhookData.events.length === 0}
                  >
                    {createWebhookMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      'Create Webhook'
                    )}
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}