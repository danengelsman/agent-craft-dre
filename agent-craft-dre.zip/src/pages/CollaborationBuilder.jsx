import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/Card";
import { Loader2, Plus, Users, LayoutDashboard, Brain, Check, GitBranch } from "lucide-react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function CollaborationBuilder() {
  const [user, setUser] = useState(null);
  const [workflowName, setWorkflowName] = useState("");
  const [orchestratorAgentId, setOrchestratorAgentId] = useState("");
  const [participatingAgentIds, setParticipatingAgentIds] = useState([]);
  const [workflowType, setWorkflowType] = useState("custom");

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: allAgents = [], isLoading: agentsLoading } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: !!user,
  });

  const createCollaborationMutation = useMutation({
    mutationFn: (newCollaboration) => base44.entities.AgentCollaboration.create(newCollaboration),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentCollaborations'] });
      toast.success("Collaboration created successfully!");
      navigate(createPageUrl("Dashboard"));
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  const handleCreateCollaboration = () => {
    if (!workflowName || !orchestratorAgentId || participatingAgentIds.length === 0) {
      toast.error("Please fill all required fields.");
      return;
    }

    createCollaborationMutation.mutate({
      workflow_name: workflowName,
      orchestrator_agent: orchestratorAgentId,
      participating_agents: participatingAgentIds,
      workflow_type: workflowType,
      status: "pending",
      steps: [],
      shared_context: {},
    });
  };

  const toggleParticipatingAgent = (agentId) => {
    setParticipatingAgentIds((prev) =>
      prev.includes(agentId) ? prev.filter((id) => id !== agentId) : [...prev, agentId]
    );
  };

  if (!user || agentsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  const workflowTypes = [
    { value: "audit_pipeline", label: "Audit Pipeline", icon: LayoutDashboard },
    { value: "improvement_cycle", label: "Improvement Cycle", icon: Brain },
    { value: "knowledge_sync", label: "Knowledge Sync", icon: Users },
    { value: "custom", label: "Custom", icon: Plus },
  ];

  const availableParticipants = allAgents.filter(a => a.id !== orchestratorAgentId);

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app pb-24" style={{ maxWidth: '56rem' }}>
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Agent Collaboration Builder
          </h1>
          <p className="text-gray-600">
            Design workflows where multiple AI agents work together on complex tasks.
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Workflow Details</CardTitle>
            <CardDescription>Name your collaborative workflow and choose its type.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Workflow Name <span className="text-red-500">*</span>
              </label>
              <Input
                placeholder="e.g., Customer Support Triage, Content Creation Pipeline"
                value={workflowName}
                onChange={(e) => setWorkflowName(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Workflow Type <span className="text-red-500">*</span>
              </label>
              <Select value={workflowType} onValueChange={setWorkflowType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  {workflowTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <type.icon className="w-4 h-4" />
                        {type.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Orchestrator Agent</CardTitle>
            <CardDescription>The main agent that coordinates the collaboration.</CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={orchestratorAgentId} onValueChange={setOrchestratorAgentId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose orchestrator" />
              </SelectTrigger>
              <SelectContent>
                {allAgents.map((agent) => (
                  <SelectItem key={agent.id} value={agent.id}>
                    {agent.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Participating Agents</CardTitle>
            <CardDescription>Select agents that will contribute to this collaboration.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {availableParticipants.length > 0 ? (
              availableParticipants.map((agent) => {
                const isSelected = participatingAgentIds.includes(agent.id);
                return (
                  <button
                    key={agent.id}
                    onClick={() => toggleParticipatingAgent(agent.id)}
                    className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                      isSelected
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {isSelected && <Check className="w-5 h-5 text-purple-600" />}
                        <div>
                          <p className="font-semibold text-gray-900">{agent.name}</p>
                          <p className="text-xs text-gray-500 line-clamp-1">{agent.description}</p>
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">
                {orchestratorAgentId ? 'No other agents available' : 'Select an orchestrator first'}
              </p>
            )}
          </CardContent>
        </Card>

        <Button
          onClick={handleCreateCollaboration}
          disabled={
            createCollaborationMutation.isPending ||
            !workflowName ||
            !orchestratorAgentId ||
            participatingAgentIds.length === 0
          }
          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white"
        >
          {createCollaborationMutation.isPending ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Creating...
            </>
          ) : (
            <>
              <GitBranch className="w-5 h-5 mr-2" />
              Create Collaboration
            </>
          )}
        </Button>
      </div>
    </div>
  );
}