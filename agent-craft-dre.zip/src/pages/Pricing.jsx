import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { PageShell } from "@/components/ui/PageShell";
import { Check, Zap, Crown, Sparkles, Building2 } from "lucide-react";
import { motion } from "framer-motion";

const TIERS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    icon: Sparkles,
    color: "from-gray-400 to-gray-600",
    features: [
      "3 AI agents",
      "100 messages/month",
      "Basic abilities",
      "Community access",
      "Basic support"
    ],
    limits: {
      maxAgents: 3,
      maxMessages: 100,
      abilities: ["basic_chat", "personality"]
    }
  },
  {
    id: "pro",
    name: "Pro",
    price: 19,
    icon: Zap,
    color: "from-blue-500 to-purple-600",
    popular: true,
    features: [
      "Unlimited AI agents",
      "Unlimited messages",
      "All abilities unlocked",
      "Priority support",
      "Advanced analytics",
      "No ads",
      "Early access to features"
    ],
    limits: {
      maxAgents: -1,
      maxMessages: -1,
      abilities: ["all"]
    }
  },
  {
    id: "business",
    name: "Business",
    price: 99,
    icon: Building2,
    color: "from-amber-500 to-orange-600",
    features: [
      "Everything in Pro",
      "Team collaboration",
      "Custom branding",
      "API access",
      "Dedicated support",
      "SLA guarantee",
      "Training & onboarding",
      "Custom integrations"
    ],
    limits: {
      maxAgents: -1,
      maxMessages: -1,
      abilities: ["all"]
    }
  }
];

export default function Pricing() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const subs = await base44.entities.UserSubscription.filter({ user_email: user.email });
      return subs[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
  });

  const upgradeMutation = useMutation({
    mutationFn: async (tier) => {
      if (!user?.email) throw new Error("User not loaded");
      
      if (!subscription) {
        // Create new subscription
        return await base44.entities.UserSubscription.create({
          user_email: user.email,
          tier: tier,
          status: "active",
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        });
      } else {
        // Update existing
        return await base44.entities.UserSubscription.update(subscription.id, {
          tier: tier,
          status: "active"
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      alert("Subscription updated! 🎉");
    },
    retry: 1,
  });

  const currentTier = subscription?.tier || "free";

  return (
    <PageShell>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl ui-muted max-w-2xl mx-auto">
            Start free, upgrade when you need more power
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-16 items-stretch">
          {TIERS.map((tier, index) => {
            const Icon = tier.icon;
            const isCurrentTier = currentTier === tier.id;
            
            return (
              <div key={tier.id} className="flex">
                <Card className="p-6 relative flex flex-col w-full">
                  {tier.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-3 py-1 bg-gray-900 text-white text-xs font-semibold rounded-full whitespace-nowrap">
                      Most Popular
                    </div>
                  )}

                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tier.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>

                  <h3 className="text-xl font-bold mb-2">{tier.name}</h3>
                  
                  <div className="mb-6">
                    <span className="text-4xl font-bold">${tier.price}</span>
                    {tier.price > 0 && <span className="text-sm text-gray-600">/month</span>}
                  </div>

                  <ul className="space-y-2.5 mb-6 flex-grow">
                    {tier.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <div className="w-4 h-4 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-2.5 h-2.5 text-green-600" />
                        </div>
                        <span className="text-gray-700 text-sm leading-snug">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => upgradeMutation.mutate(tier.id)}
                    disabled={isCurrentTier || upgradeMutation.isLoading}
                    variant={tier.popular ? "primary" : "secondary"}
                    className="w-full"
                  >
                    {isCurrentTier ? 'Current Plan' : `Upgrade to ${tier.name}`}
                  </Button>
                </Card>
              </div>
            );
          })}
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">
            Frequently Asked Questions
          </h2>

          <div className="space-y-4">
            <Card className="p-6">
              <h3 className="font-bold mb-2">Can I cancel anytime?</h3>
              <p className="ui-muted">
                Yes! You can cancel your subscription at any time. You'll continue to have access until the end of your billing period.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-bold mb-2">What payment methods do you accept?</h3>
              <p className="ui-muted">
                We accept all major credit cards, PayPal, and bank transfers for Business plans.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-bold mb-2">Do you offer refunds?</h3>
              <p className="ui-muted">
                We offer a 30-day money-back guarantee for all paid plans. No questions asked.
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-bold mb-2">Can I upgrade or downgrade?</h3>
              <p className="ui-muted">
                Absolutely! You can change your plan at any time. Changes take effect at the start of your next billing cycle.
              </p>
            </Card>
          </div>
        </div>
      </div>
    </PageShell>
  );
}