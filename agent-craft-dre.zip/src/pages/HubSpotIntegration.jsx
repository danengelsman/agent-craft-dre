import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { CheckCircle2, Loader2, ArrowRight } from "lucide-react";
import FieldMappingTable from "../components/hubspot/FieldMappingTable";
import ContactUpsertPrototype from "../components/hubspot/ContactUpsertPrototype";
import SyncDashboard from "../components/hubspot/SyncDashboard";

export default function HubSpotIntegration() {
  const [user, setUser] = useState(null);
  const [apiKey, setApiKey] = useState("");
  const [isConfigured, setIsConfigured] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
    
    const savedKey = localStorage.getItem('hubspot_api_key');
    if (savedKey) {
      setApiKey(savedKey);
      setIsConfigured(true);
    }
  }, []);

  const { data: fieldMappings = [] } = useQuery({
    queryKey: ['hubspot_field_mappings'],
    queryFn: () => base44.entities.HubSpotFieldMapping.list(),
    enabled: !!user
  });

  const { data: syncLogs = [] } = useQuery({
    queryKey: ['hubspot_sync_logs'],
    queryFn: () => base44.entities.HubSpotSyncLog.list('-created_date', 50),
    enabled: !!user
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list('-created_date'),
    enabled: !!user
  });

  const handleSaveApiKey = () => {
    setIsSaving(true);
    localStorage.setItem('hubspot_api_key', apiKey);
    setIsConfigured(true);
    setIsSaving(false);
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-black" />
      </div>
    );
  }

  const syncStats = {
    total: syncLogs.length,
    success: syncLogs.filter(log => log.status === 'success').length,
    error: syncLogs.filter(log => log.status === 'error').length,
    pending: syncLogs.filter(log => log.status === 'pending').length
  };

  return (
    <div className="bg-app min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl lg:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              HubSpot.
              <br />
              Seamlessly connected.
            </h1>
            <p className="text-xl lg:text-2xl text-gray-600 mb-12 font-normal">
              Your contacts, companies, and deals. Always in sync.
            </p>

            {!isConfigured ? (
              <div className="max-w-md mx-auto">
                <Input
                  type="password"
                  placeholder="Enter your HubSpot API key"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="h-12 text-base mb-4 bg-white"
                />
                <Button
                  onClick={handleSaveApiKey}
                  disabled={!apiKey || isSaving}
                  className="w-full h-12 bg-black hover:bg-gray-800 text-white rounded-xl font-normal text-base"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    'Connect HubSpot'
                  )}
                </Button>
                <p className="text-sm text-gray-500 mt-4">
                  Get your key from HubSpot Settings → Integrations → Private Apps
                </p>
              </div>
            ) : (
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-50 border border-green-200 rounded-full">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-green-900">Connected</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      {isConfigured && (
        <div className="max-w-6xl mx-auto px-6 lg:px-8 py-16">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            <div className="text-center">
              <div className="text-5xl lg:text-6xl font-semibold text-gray-900 mb-2">
                {syncStats.total}
              </div>
              <div className="text-base text-gray-600">Total syncs</div>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-6xl font-semibold text-green-600 mb-2">
                {syncStats.success}
              </div>
              <div className="text-base text-gray-600">Successful</div>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-6xl font-semibold text-red-600 mb-2">
                {syncStats.error}
              </div>
              <div className="text-base text-gray-600">Errors</div>
            </div>
            <div className="text-center">
              <div className="text-5xl lg:text-6xl font-semibold text-blue-600 mb-2">
                {contacts.length}
              </div>
              <div className="text-base text-gray-600">Contacts</div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      {isConfigured && (
        <div className="border-b border-gray-200 bg-white sticky top-0 z-10">
          <div className="max-w-6xl mx-auto px-6 lg:px-8">
            <nav className="flex gap-8">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'prototype', label: 'Prototype' },
                { id: 'mappings', label: 'Field Mappings' },
                { id: 'contacts', label: 'Contacts' },
                { id: 'activity', label: 'Activity' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 text-[15px] font-normal relative ${
                    activeTab === tab.id
                      ? 'text-gray-900'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {tab.label}
                  {activeTab === tab.id && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-black" />
                  )}
                </button>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* Content Sections */}
      {isConfigured && (
        <div className="max-w-6xl mx-auto px-6 lg:px-8 py-16">
          {activeTab === 'overview' && (
            <div className="space-y-16">
              <div className="text-center max-w-2xl mx-auto">
                <h2 className="text-4xl font-semibold text-gray-900 mb-4">
                  Everything in sync
                </h2>
                <p className="text-xl text-gray-600">
                  Your CRM data flows seamlessly between AgentCraft and HubSpot.
                  Set it up once, and forget about it.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-12 h-12 bg-black rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Automatic sync
                  </h3>
                  <p className="text-[15px] text-gray-600">
                    Changes sync automatically in real-time
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-black rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Field mapping
                  </h3>
                  <p className="text-[15px] text-gray-600">
                    Customize how your data maps between systems
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-black rounded-2xl mx-auto mb-4 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Conflict resolution
                  </h3>
                  <p className="text-[15px] text-gray-600">
                    Smart handling of data conflicts
                  </p>
                </div>
              </div>

              <div className="text-center">
                <Button
                  onClick={() => setActiveTab('prototype')}
                  className="h-12 px-8 bg-black hover:bg-gray-800 text-white rounded-xl font-normal text-base"
                >
                  Try the prototype
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}

          {activeTab === 'prototype' && (
            <ContactUpsertPrototype 
              apiKey={apiKey}
              isConfigured={isConfigured}
              fieldMappings={fieldMappings}
            />
          )}

          {activeTab === 'mappings' && (
            <FieldMappingTable fieldMappings={fieldMappings} />
          )}

          {activeTab === 'contacts' && (
            <div>
              <h2 className="text-3xl font-semibold text-gray-900 mb-8">
                Contacts
              </h2>
              {contacts.length === 0 ? (
                <div className="text-center py-20">
                  <p className="text-xl text-gray-600">No contacts yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {contacts.map((contact) => (
                    <div 
                      key={contact.id}
                      className="p-6 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-semibold text-gray-900 text-base">
                            {contact.first_name} {contact.last_name}
                          </h4>
                          <p className="text-[15px] text-gray-600">{contact.email}</p>
                          {contact.company && (
                            <p className="text-sm text-gray-500 mt-1">{contact.company}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            contact.sync_status === 'synced' 
                              ? 'bg-green-100 text-green-700'
                              : contact.sync_status === 'error'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-gray-200 text-gray-700'
                          }`}>
                            {contact.sync_status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'activity' && (
            <SyncDashboard syncLogs={syncLogs} />
          )}
        </div>
      )}
    </div>
  );
}