import { PageShell } from "@/components/ui/PageShell";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/Card";
import { Calendar, User, Tag, Clock } from "lucide-react";
import { useState } from "react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

// Mark this page as public (no authentication required)
export const PUBLIC_PAGE = true;

const calculateReadingTime = (content) => {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  const minutes = Math.ceil(wordCount / wordsPerMinute);
  return minutes;
};

const BLOG_POSTS = [
  {
    id: 1,
    title: "Welcome to AgentCraft: The Future of AI Agent Creation",
    excerpt: "Discover how AgentCraft is revolutionizing the way creators build intelligent AI agents. Learn about our mission to make AI accessible to everyone, from complete beginners to advanced users.",
    content: "Welcome to AgentCraft, where we're democratizing AI agent creation for creators worldwide. Our platform combines powerful AI capabilities with an intuitive interface, making it easier than ever to build, deploy, and monetize intelligent agents.",
    date: "2024-12-15",
    author: "Daniel Engelsman",
    category: "Announcements",
    tags: ["Getting Started", "Platform"],
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 2,
    title: "Building Your First Agent: A Complete Guide",
    excerpt: "From zero to deployed in minutes. Follow our comprehensive guide to creating your first AI agent with AgentCraft's intuitive builder.",
    content: "Creating your first AI agent doesn't have to be complicated. With AgentCraft's guided builder, you'll go from idea to deployed agent in just a few simple steps. Choose your agent's personality, define its capabilities, and watch it come to life.",
    date: "2024-12-10",
    author: "Daniel Engelsman",
    category: "Tutorials",
    tags: ["Getting Started", "Agent Builder", "Beginner"],
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 3,
    title: "Agent Best Practices: Optimize Your AI Workflow",
    excerpt: "Master the art of agent creation with proven strategies for personality design, prompt engineering, and workflow optimization.",
    content: "Get the most out of your AI agents with these expert tips. Learn how to craft effective personalities, structure conversations, and leverage advanced features like evolution and collaboration.",
    date: "2024-12-05",
    author: "Daniel Engelsman",
    category: "Best Practices",
    tags: ["Advanced", "Optimization", "Tips"],
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 4,
    title: "Understanding Agent Evolution: How Your AI Gets Smarter",
    excerpt: "Explore the cutting-edge evolution system that allows your agents to learn, adapt, and improve over time based on real interactions.",
    content: "AgentCraft's evolution system is a game-changer. Your agents can automatically improve their performance through genetic algorithms, learning from successful interactions and adapting their behavior to better serve your needs.",
    date: "2024-11-28",
    author: "Daniel Engelsman",
    category: "Features",
    tags: ["Evolution", "Advanced", "AI"],
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 5,
    title: "Monetize Your Agents: Creator Economy Guide",
    excerpt: "Turn your AI expertise into revenue. Learn how to package, price, and sell your agents in the AgentCraft marketplace.",
    content: "The creator economy is here, and AgentCraft puts you at the center. Discover strategies for creating valuable agents, pricing them effectively, and building a sustainable business around your AI creations.",
    date: "2024-11-20",
    author: "Daniel Engelsman",
    category: "Monetization",
    tags: ["Marketplace", "Revenue", "Business"],
    image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 6,
    title: "Agent Collaboration: Building Multi-Agent Workflows",
    excerpt: "Unlock new possibilities by having multiple agents work together. Learn how to orchestrate complex workflows with agent collaboration.",
    content: "Single agents are powerful, but agent collaboration takes things to the next level. Design workflows where multiple specialized agents work together, each contributing their unique capabilities to solve complex problems.",
    date: "2024-11-15",
    author: "Daniel Engelsman",
    category: "Advanced",
    tags: ["Collaboration", "Workflows", "Advanced"],
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 7,
    title: "What is AgentCraft? A Beginner's Guide to AI Assistants",
    excerpt: "Never used AI before? No problem. Learn what AgentCraft is, how it works, and why it's the easiest way for anyone to create smart AI helpers.",
    content: "If you've heard about ChatGPT but aren't quite sure what it does or how to use AI, you're in the right place. AgentCraft makes creating your own AI assistant simple enough for anyone to do—no technical knowledge required.",
    date: "2024-12-21",
    author: "Daniel Engelsman",
    category: "Getting Started",
    tags: ["Beginner", "Introduction", "AI Basics"],
    image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?w=800&h=400&fit=crop&q=80",
  },
];

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  
  const categories = ["All", ...new Set(BLOG_POSTS.map(post => post.category))];
  
  const filteredPosts = selectedCategory === "All" 
    ? BLOG_POSTS 
    : BLOG_POSTS.filter(post => post.category === selectedCategory);

  return (
    <PageShell
      title="Blog"
      subtitle="Latest updates, guides, and insights"
    >
      <div className="max-w-5xl mx-auto">
        {/* Category Filter */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                selectedCategory === category
                  ? "bg-gray-900 text-white"
                  : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Blog Posts */}
        <div className="space-y-6">
          {filteredPosts.map((post) => (
            <Link 
              key={post.id}
              to={createPageUrl("BlogPost") + "?id=" + post.id}
            >
              <Card className="hover:shadow-lg transition-shadow cursor-pointer overflow-hidden">
              <div className="flex flex-col md:flex-row">
                {/* Featured Image */}
                <div className="md:w-1/3">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>
                
                {/* Content */}
                <div className="md:w-2/3">
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs font-semibold text-gray-900 bg-gray-100 px-2 py-1 rounded">
                        {post.category}
                      </span>
                    </div>
                    <CardTitle>{post.title}</CardTitle>
                    <CardDescription>{post.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{post.date}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{calculateReadingTime(post.content)} min read</span>
                      </div>
                      {post.tags && post.tags.length > 0 && (
                        <div className="flex items-center gap-1 flex-wrap">
                          <Tag className="w-4 h-4" />
                          {post.tags.map((tag, idx) => (
                            <span key={idx} className="text-xs bg-gray-50 px-2 py-0.5 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </div>
              </div>
            </Card>
            </Link>
          ))}
        </div>
      </div>
    </PageShell>
  );
}