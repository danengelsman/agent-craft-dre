import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";
import { 
  Dna, Sparkles, TrendingUp, Settings, ArrowLeft, 
  Loader2, Zap, Brain, RotateCcw, Play, History
} from "lucide-react";
import { motion } from "framer-motion";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import EvolutionTimeline from "../components/evolution/EvolutionTimeline";
import EvolutionSettingsPanel from "../components/evolution/EvolutionSettingsPanel";
import GenePoolExplorer from "../components/evolution/GenePoolExplorer";
import HelpTooltip from "@/components/ui/HelpTooltip";
import ExplanationCard from "@/components/ui/ExplanationCard";

export default function AgentEvolution() {
  const [user, setUser] = useState(null);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const agentId = searchParams.get("agent");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  // Fetch all user's agents
  const { data: allAgents = [], isLoading: allAgentsLoading } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: !!user
  });

  // Fetch agent
  const { data: agent, isLoading: agentLoading } = useQuery({
    queryKey: ['agent', agentId],
    queryFn: async () => {
      const agents = await base44.entities.Agent.filter({ id: agentId });
      return agents[0];
    },
    enabled: !!agentId && !!user
  });

  // Fetch evolution history
  const { data: evolutions = [] } = useQuery({
    queryKey: ['evolutions', agentId],
    queryFn: () => base44.entities.AgentEvolution.filter({ agent_id: agentId }, '-created_date'),
    enabled: !!agentId && !!user
  });

  // Fetch evolution settings
  const { data: evolutionSettings } = useQuery({
    queryKey: ['evolutionSettings', agentId],
    queryFn: async () => {
      const settings = await base44.entities.EvolutionSettings.filter({ agent_id: agentId });
      return settings[0];
    },
    enabled: !!agentId && !!user
  });

  // Fetch gene pool
  const { data: genePool = [] } = useQuery({
    queryKey: ['genePool'],
    queryFn: () => base44.entities.AgentGenePool.list('-effectiveness_score', 50),
    enabled: !!user
  });

  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (settings) => {
      if (evolutionSettings?.id) {
        return base44.entities.EvolutionSettings.update(evolutionSettings.id, settings);
      } else {
        return base44.entities.EvolutionSettings.create({ ...settings, agent_id: agentId });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evolutionSettings', agentId] });
    }
  });

  // Trigger evolution mutation
  const triggerEvolutionMutation = useMutation({
    mutationFn: async () => {
      // Analyze agent performance
      const performanceAnalysis = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this AI agent and suggest improvements:
        
Name: ${agent.name}
Description: ${agent.description}
Personality: ${agent.personality}
Abilities: ${agent.abilities?.join(', ')}

Based on common best practices, suggest ONE specific improvement that would make this agent more effective. Focus on either:
1. Personality refinement - making the tone more appropriate
2. Prompt tuning - optimizing the system instructions
3. Ability optimization - suggesting better ability combinations

Return your analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            evolution_type: { type: "string", enum: ["personality_refinement", "prompt_tuning", "ability_optimization"] },
            field_to_change: { type: "string" },
            current_value: { type: "string" },
            suggested_value: { type: "string" },
            reason: { type: "string" },
            expected_improvement: { type: "number" }
          }
        }
      });

      const currentGen = evolutions.length > 0 ? Math.max(...evolutions.map(e => e.generation)) : 0;

      return base44.entities.AgentEvolution.create({
        agent_id: agentId,
        agent_name: agent.name,
        generation: currentGen + 1,
        evolution_type: performanceAnalysis.evolution_type,
        trigger_reason: "user_requested",
        before_snapshot: {
          personality: agent.personality,
          abilities: agent.abilities,
          description: agent.description
        },
        changes_applied: [{
          field: performanceAnalysis.field_to_change,
          old_value: performanceAnalysis.current_value,
          new_value: performanceAnalysis.suggested_value,
          reason: performanceAnalysis.reason
        }],
        improvement_percentage: performanceAnalysis.expected_improvement,
        status: evolutionSettings?.require_approval === false ? "applied" : "pending",
        auto_applied: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evolutions', agentId] });
    }
  });

  // Apply evolution mutation
  const applyEvolutionMutation = useMutation({
    mutationFn: async (evolution) => {
      // Apply the changes to the agent
      const updates = {};
      for (const change of evolution.changes_applied) {
        if (change.field === 'personality') {
          updates.personality = change.new_value;
        } else if (change.field === 'abilities') {
          updates.abilities = JSON.parse(change.new_value);
        }
      }

      await base44.entities.Agent.update(agentId, updates);
      await base44.entities.AgentEvolution.update(evolution.id, { status: "applied" });

      // Extract gene from successful evolution
      if (evolution.improvement_percentage > 10) {
        await base44.entities.AgentGenePool.create({
          gene_type: evolution.evolution_type === "personality_refinement" ? "personality_trait" : "prompt_pattern",
          name: `${agent.name} - Gen ${evolution.generation}`,
          description: evolution.changes_applied[0]?.reason || "Successful evolution trait",
          genetic_code: { changes: evolution.changes_applied },
          source_agent_id: agentId,
          effectiveness_score: Math.min(100, 50 + evolution.improvement_percentage),
          is_validated: true
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evolutions', agentId] });
      queryClient.invalidateQueries({ queryKey: ['agent', agentId] });
      queryClient.invalidateQueries({ queryKey: ['genePool'] });
    }
  });

  // Rollback mutation
  const rollbackMutation = useMutation({
    mutationFn: async (evolution) => {
      const updates = {};
      for (const change of evolution.changes_applied) {
        if (change.field === 'personality') {
          updates.personality = change.old_value;
        } else if (change.field === 'abilities') {
          updates.abilities = JSON.parse(change.old_value);
        }
      }

      await base44.entities.Agent.update(agentId, updates);
      await base44.entities.AgentEvolution.update(evolution.id, { status: "rolled_back" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evolutions', agentId] });
      queryClient.invalidateQueries({ queryKey: ['agent', agentId] });
    }
  });

  // Apply gene mutation
  const applyGeneMutation = useMutation({
    mutationFn: async (gene) => {
      // Apply gene to agent
      const currentGen = evolutions.length > 0 ? Math.max(...evolutions.map(e => e.generation)) : 0;

      await base44.entities.AgentEvolution.create({
        agent_id: agentId,
        agent_name: agent.name,
        generation: currentGen + 1,
        evolution_type: "hybrid_mutation",
        trigger_reason: "user_requested",
        changes_applied: gene.genetic_code.changes || [{
          field: "genetic_material",
          old_value: "none",
          new_value: gene.name,
          reason: `Applied gene: ${gene.name}`
        }],
        status: "applied",
        auto_applied: false
      });

      // Update gene usage
      await base44.entities.AgentGenePool.update(gene.id, {
        times_used: (gene.times_used || 0) + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['evolutions', agentId] });
      queryClient.invalidateQueries({ queryKey: ['genePool'] });
    }
  });

  if (!user || allAgentsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="bg-app min-h-screen">
        <div className="container-app" style={{ maxWidth: '72rem' }}>
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2">Evolution Lab</h1>
            <p className="text-gray-600">Select a helper to view and manage its evolution</p>
          </div>

          {allAgents.length === 0 ? (
            <Card className="p-12 text-center">
              <Dna className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h2 className="text-xl font-bold mb-2">No helpers yet</h2>
              <p className="text-gray-600 mb-6">Create your first helper to start evolving</p>
              <Link to={createPageUrl("GuidedBuilder")}>
                <Button>Create Helper</Button>
              </Link>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allAgents.map((agentItem, index) => (
                <Link 
                  key={agentItem.id} 
                  to={`${createPageUrl("AgentEvolution")}?agent=${agentItem.id}`}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="p-6 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-purple-200 bg-gradient-to-br from-white via-purple-50/30 to-blue-50/30">
                      <div className="flex items-start gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 via-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/30">
                          <Dna className="w-7 h-7 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-lg mb-2 truncate text-gray-900">{agentItem.name}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2 mb-4">{agentItem.description}</p>
                          <div className="flex items-center gap-2 text-xs font-medium text-purple-600 bg-purple-100 rounded-full px-3 py-1.5 w-fit">
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>Ready to evolve</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  const currentGeneration = evolutions.length > 0 ? Math.max(...evolutions.map(e => e.generation)) : 1;
  const totalImprovement = evolutions
    .filter(e => e.status === "applied")
    .reduce((sum, e) => sum + (e.improvement_percentage || 0), 0);
  const pendingEvolutions = evolutions.filter(e => e.status === "pending").length;

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to={createPageUrl("AgentEvolution")}>
            <Button variant="outline" size="icon" className="shadow-sm hover:shadow-md transition-all">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 via-purple-600 to-blue-600 flex items-center justify-center shadow-xl shadow-purple-500/40">
                <Dna className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2 mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Evolution Lab
                  <HelpTooltip>
                    Evolution helps your helper improve over time by analyzing performance and suggesting upgrades
                  </HelpTooltip>
                </h1>
                <Select 
                  value={agentId} 
                  onValueChange={(value) => navigate(`${createPageUrl("AgentEvolution")}?agent=${value}`)}
                >
                  <SelectTrigger className="w-full md:w-[300px] border-gray-200 hover:border-purple-300 transition-colors shadow-sm">
                    <SelectValue placeholder="Select helper" />
                  </SelectTrigger>
                  <SelectContent>
                    {allAgents.map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <Button
            onClick={() => triggerEvolutionMutation.mutate()}
            disabled={triggerEvolutionMutation.isPending}
            className="bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 text-white hidden md:flex shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all hover:scale-105"
          >
            {triggerEvolutionMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            Trigger Evolution
          </Button>
        </div>
        
        {/* Mobile Evolution Button */}
        <div className="md:hidden mb-6">
          <Button
            onClick={() => triggerEvolutionMutation.mutate()}
            disabled={triggerEvolutionMutation.isPending}
            className="w-full bg-gradient-to-r from-purple-600 via-purple-500 to-blue-600 text-white shadow-lg shadow-purple-500/50 hover:shadow-xl hover:shadow-purple-500/60 transition-all"
          >
            {triggerEvolutionMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            Trigger Evolution
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-5 bg-gradient-to-br from-purple-50 via-white to-purple-50/50 border-purple-100 hover:shadow-lg transition-all">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Dna className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold flex items-center gap-1 text-purple-700">
                  {currentGeneration}
                  <HelpTooltip side="right">
                    Each time your helper evolves, the generation number increases. Higher generations mean more improvements!
                  </HelpTooltip>
                </p>
                <p className="text-sm text-gray-600 font-medium">Generation</p>
              </div>
            </div>
          </Card>
          <Card className="p-5 bg-gradient-to-br from-green-50 via-white to-green-50/50 border-green-100 hover:shadow-lg transition-all">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-green-500/30">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">+{totalImprovement.toFixed(1)}%</p>
                <p className="text-sm text-gray-600 font-medium">Total Improvement</p>
              </div>
            </div>
          </Card>
          <Card className="p-5 bg-gradient-to-br from-amber-50 via-white to-amber-50/50 border-amber-100 hover:shadow-lg transition-all">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-amber-600">{pendingEvolutions}</p>
                <p className="text-sm text-gray-600 font-medium">Pending</p>
              </div>
            </div>
          </Card>
          <Card className="p-5 bg-gradient-to-br from-blue-50 via-white to-blue-50/50 border-blue-100 hover:shadow-lg transition-all">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{evolutionSettings?.auto_evolve_enabled ? 'ON' : 'OFF'}</p>
                <p className="text-sm text-gray-600 font-medium">Auto-Evolve</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="timeline" className="space-y-6">
          <TabsList className="bg-gradient-to-r from-gray-100 via-purple-50/50 to-gray-100 p-1.5 rounded-xl shadow-sm border border-gray-200">
            <TabsTrigger value="timeline" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-md transition-all data-[state=active]:text-purple-700 font-medium">
              <History className="w-4 h-4 mr-2" />
              Evolution Timeline
            </TabsTrigger>
            <TabsTrigger value="settings" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-md transition-all data-[state=active]:text-purple-700 font-medium">
              <Settings className="w-4 h-4 mr-2" />
              Evolution Settings
            </TabsTrigger>
            <TabsTrigger value="genepool" className="rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-md transition-all data-[state=active]:text-purple-700 font-medium">
              <Dna className="w-4 h-4 mr-2" />
              Gene Pool
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timeline">
            <Card className="p-6 bg-gradient-to-br from-white via-purple-50/20 to-white shadow-lg border-purple-100/50">
              <ExplanationCard title="What is Evolution?" icon={Sparkles}>
                Evolution automatically analyzes your helper's performance and suggests improvements. You can review each suggestion before applying it, or enable auto-evolution to let your helper improve itself!
              </ExplanationCard>
              <div className="mt-6">
                <EvolutionTimeline
                  evolutions={evolutions}
                  onApply={(evolution) => applyEvolutionMutation.mutate(evolution)}
                  onRollback={(evolution) => rollbackMutation.mutate(evolution)}
                />
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="p-6 bg-gradient-to-br from-white via-blue-50/20 to-white shadow-lg border-blue-100/50">
              <EvolutionSettingsPanel
                settings={evolutionSettings}
                onSave={(settings) => saveSettingsMutation.mutate(settings)}
                isLoading={saveSettingsMutation.isPending}
              />
            </Card>
          </TabsContent>

          <TabsContent value="genepool">
            <Card className="p-6 bg-gradient-to-br from-white via-purple-50/20 to-white shadow-lg border-purple-100/50">
              <div className="mb-4">
                <h3 className="text-lg font-bold mb-2 flex items-center gap-2 text-gray-900">
                  Gene Pool
                  <HelpTooltip>
                    Genes are successful traits from other helpers. Apply them to quickly improve your helper!
                  </HelpTooltip>
                </h3>
                <ExplanationCard title="How Genes Work" icon={Dna}>
                  When a helper evolves successfully, we save that improvement as a "gene". You can apply these proven improvements to your helpers instantly, instead of waiting for evolution!
                </ExplanationCard>
              </div>
              <GenePoolExplorer
                genes={genePool}
                onApplyGene={(gene) => applyGeneMutation.mutate(gene)}
                currentAgentId={agentId}
              />
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}