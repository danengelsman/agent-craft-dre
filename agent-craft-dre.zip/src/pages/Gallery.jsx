import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Sparkles, Plus, MessageSquare, Trash2, Loader2, Crown, Lock, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { usePlanAccess } from "../components/PlanAccessProvider";

const CertificationBadge = lazy(() => import("../components/marketplace/CertificationBadge"));
const AdminSimulationControls = lazy(() => import("../components/AdminSimulationControls"));

export default function Gallery() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const queryClient = useQueryClient();
  
  const { canCreateAgent, maxAgents, tier, isAdmin, isSimulating } = usePlanAccess();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: agents = [], isLoading: agentsLoading } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: !!user,
    staleTime: 300000,
  });

  const deleteAgentMutation = useMutation({
    mutationFn: (agentId) => base44.entities.Agent.delete(agentId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agents'] });
    },
  });

  const handleDelete = async (agentId, agentName) => {
    if (window.confirm(`Are you sure you want to delete "${agentName}"?`)) {
      await deleteAgentMutation.mutateAsync(agentId);
    }
  };

  const canCreateMore = useMemo(() => canCreateAgent(agents.length), [canCreateAgent, agents.length]);

  if (isLoadingUser || agentsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        {/* Admin Simulation Controls */}
        {(isAdmin || isSimulating) && (
          <Suspense fallback={<div className="h-16" />}>
            <AdminSimulationControls />
          </Suspense>
        )}

        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                My Helpers
              </h1>
              <p className="text-gray-600">
                {agents.length} {agents.length === 1 ? 'helper' : 'helpers'}
                {maxAgents !== -1 && ` of ${maxAgents} used`}
              </p>
            </div>
            {canCreateMore ? (
              <Link to={createPageUrl("Builder")}>
                <Button className="bg-gray-900 hover:bg-gray-800 text-white">
                  <Plus className="w-5 h-5 mr-2" />
                  Create Helper
                </Button>
              </Link>
            ) : (
              <Button disabled className="opacity-50 cursor-not-allowed bg-gray-200 text-gray-500">
                <Lock className="w-5 h-5 mr-2" />
                Limit Reached
              </Button>
            )}
          </div>

          {/* Agent Limit Warning */}
          {!canCreateMore && (
            <Card className="p-6 bg-amber-50 border-amber-200 mb-6">
              <div className="flex items-start gap-4">
                <Crown className="w-8 h-8 text-amber-600 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-amber-900 mb-2">Helper Limit Reached</h3>
                  <p className="text-amber-800 mb-4">
                    You've created {agents.length} of {maxAgents} helpers available on the {tier.charAt(0).toUpperCase() + tier.slice(1)} plan. 
                    Upgrade to create unlimited helpers!
                  </p>
                  <Link to={createPageUrl("Pricing")}>
                    <Button className="bg-amber-600 hover:bg-amber-700 text-white">
                      Upgrade Now
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          )}
        </div>

        {agents.length === 0 ? (
          <div className="text-center py-20 max-w-2xl mx-auto">
            <div className="w-20 h-20 rounded-xl bg-gray-100 flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-10 h-10 text-gray-900" />
            </div>
            <h2 className="text-2xl font-bold mb-3">Ready to create your first AI Helper?</h2>
            <p className="ui-muted mb-8 text-lg">
              Here's what others are using AI Helpers for:
            </p>
            
            <div className="grid md:grid-cols-2 gap-4 mb-8 text-left">
              <Card className="p-4 hover:shadow-md hover:scale-[1.02] transition-all duration-200 cursor-pointer hover:border-gray-300">
                <h3 className="font-semibold mb-2">📝 Content Assistant</h3>
                <p className="text-sm ui-muted">Write blog posts, social media captions, and marketing emails</p>
              </Card>
              <Card className="p-4 hover:shadow-md hover:scale-[1.02] transition-all duration-200 cursor-pointer hover:border-gray-300">
                <h3 className="font-semibold mb-2">💬 Customer Support</h3>
                <p className="text-sm ui-muted">Answer common questions and help customers 24/7</p>
              </Card>
              <Card className="p-4 hover:shadow-md hover:scale-[1.02] transition-all duration-200 cursor-pointer hover:border-gray-300">
                <h3 className="font-semibold mb-2">📚 Study Buddy</h3>
                <p className="text-sm ui-muted">Explain concepts, quiz you, and help with homework</p>
              </Card>
              <Card className="p-4 hover:shadow-md hover:scale-[1.02] transition-all duration-200 cursor-pointer hover:border-gray-300">
                <h3 className="font-semibold mb-2">🎯 Personal Coach</h3>
                <p className="text-sm ui-muted">Set goals, track habits, and stay motivated</p>
              </Card>
            </div>

            <Link to={createPageUrl("GuidedBuilder")}>
              <Button variant="primary" className="bg-gray-900 hover:bg-gray-800 text-white">
                <Plus className="w-5 h-5 mr-2" />
                Create Your First Helper
              </Button>
            </Link>
            <p className="text-sm ui-muted mt-4">Takes less than 2 minutes • No coding required</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {agents.map((agent) => (
              <Card key={agent.id} className="p-6 hover:shadow-lg hover:scale-[1.02] transition-all duration-200 cursor-pointer hover:border-gray-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center">
                    <Sparkles className="w-7 h-7 text-gray-900" />
                  </div>
                  <Button
                    onClick={() => handleDelete(agent.id, agent.name)}
                    variant="ghost"
                    size="icon"
                    className="text-gray-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-bold text-lg text-gray-900">{agent.name}</h3>
                  <Suspense fallback={null}>
                    <CertificationBadge status={agent.certification_status} size="sm" />
                  </Suspense>
                </div>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {agent.description}
                </p>
                <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                  <span>{agent.abilities?.length || 0} superpowers</span>
                  <span>{agent.chat_history?.length || 0} messages</span>
                </div>
                <Link to={createPageUrl("Chat")}>
                  <Button variant="outline" className="w-full">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Open Chat
                  </Button>
                </Link>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}