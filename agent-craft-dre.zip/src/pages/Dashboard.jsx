import { useState, useEffect, useMemo, useCallback, lazy, Suspense } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { PageShell } from "@/components/ui/PageShell";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Sparkles, Plus, ArrowRight, MessageSquare, Brain, Search, FileText, Heart, Image as ImageIcon, Lock, Check, Trophy, Zap, Loader2, DollarSign, Store, BookOpen } from "lucide-react";
import HelpTooltip from "@/components/ui/HelpTooltip";
import ExplanationCard from "@/components/ui/ExplanationCard";

const FeatureIconGrid = lazy(() => import("@/components/icons/FeatureIconGrid"));

const ABILITY_ICONS = {
  basic_chat: MessageSquare,
  memory: Brain,
  web_search: Search,
  file_handling: FileText,
  personality: Heart,
  image_gen: ImageIcon,
};

const ABILITY_NAMES = {
  basic_chat: "Chat",
  memory: "Memory",
  web_search: "Web Search",
  file_handling: "File Helper",
  personality: "Personality",
  image_gen: "Image Creator",
};

const ALL_ABILITIES = ["basic_chat", "memory", "web_search", "file_handling", "personality", "image_gen"];

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: onboardingProgress, isLoading: isLoadingOnboardingProgress } = useQuery({
    queryKey: ['onboardingProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existing = await base44.entities.OnboardingProgress.filter({ 
        user_email: user.email 
      });
      return existing.length > 0 ? existing[0] : null;
    },
    enabled: !!user?.email && !isLoadingUser,
    staleTime: 600000,
    gcTime: 600000,
  });

  const { data: progress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existingProgress = await base44.entities.UserProgress.filter({ user_email: user.email });
      if (existingProgress.length > 0) {
        return existingProgress[0];
      }
      return await base44.entities.UserProgress.create({
        user_email: user.email,
        level: 1,
        xp: 0,
        unlocked_abilities: ["basic_chat"],
        completed_lessons: []
      });
    },
    enabled: !!user?.email && !isLoadingUser && !!onboardingProgress?.has_completed_onboarding,
    staleTime: 300000,
    gcTime: 600000,
  });

  const { data: agents = [] } = useQuery({
    queryKey: ['agents', 'recent'],
    queryFn: () => base44.entities.Agent.list('-created_date', 3),
    initialData: [],
    staleTime: 300000,
    gcTime: 600000,
    enabled: !!user && !!onboardingProgress?.has_completed_onboarding,
  });

  const xpToNextLevel = useMemo(() => progress?.level ? progress.level * 200 : 200, [progress?.level]);
  const xpProgress = useMemo(() => progress?.xp ? (progress.xp / xpToNextLevel) * 100 : 0, [progress?.xp, xpToNextLevel]);
  const unlockedAbilities = useMemo(() => progress?.unlocked_abilities || ["basic_chat"], [progress?.unlocked_abilities]);

  const quickActions = useMemo(() => [
    {
      title: "Build an Agent",
      description: "Create your AI helper in minutes",
      icon: Plus,
      color: "from-blue-500 to-purple-600",
      action: createPageUrl("GuidedBuilder"),
    },
    {
      title: "Start Chatting",
      description: "Talk to your AI agents",
      icon: MessageSquare,
      color: "from-purple-500 to-pink-600",
      action: createPageUrl("Chat"),
    },
    {
      title: "Learn & Grow",
      description: "Unlock new capabilities",
      icon: BookOpen,
      color: "from-pink-500 to-red-600",
      action: createPageUrl("TutorialCenter"),
    },
    {
      title: "Explore Marketplace",
      description: "Discover community agents",
      icon: Store,
      color: "from-green-500 to-teal-600",
      action: createPageUrl("Marketplace"),
    },
    {
      title: "Start Earning",
      description: "Sell agents, keep 85%",
      icon: DollarSign,
      color: "from-amber-500 to-orange-600",
      action: createPageUrl("CreatorDashboard"),
    },
  ], []);

  const greeting = useMemo(() => {
    if (!onboardingProgress) return "Welcome to AgentCraft";
    
    const goalMessages = {
      business: "Let's build agents for your business",
      career: "Let's advance your AI career",
      personal: "Let's build your personal AI projects",
      exploring: "Let's explore AI possibilities together"
    };

    return goalMessages[onboardingProgress.main_goal] || "Welcome to AgentCraft";
  }, [onboardingProgress]);

  if (isLoadingUser || isLoadingOnboardingProgress) {
    return (
      <PageShell>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-gray-900" />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-3">
          {user?.full_name ? `Welcome back, ${user.full_name.split(' ')[0]}!` : 'Welcome!'} 👋
        </h1>
        <p className="text-xl ui-muted max-w-2xl mx-auto mb-2">
          {greeting}
        </p>
        <p className="text-sm ui-muted max-w-xl mx-auto">
          Your AI agents work FOR you while teaching you to create better content
        </p>
      </div>

      {progress && (
        <Card className="max-w-5xl mx-auto mb-12">
          <CardContent className="p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-2xl bg-gray-900 flex items-center justify-center">
                  <Trophy className="w-10 h-10 text-white" />
                </div>
                <div>
                  <div className="text-4xl md:text-5xl font-bold mb-2 flex items-center gap-2">
                    Level {progress.level}
                    <HelpTooltip>
                      Your level shows your experience. Complete lessons and create AI Helpers to level up and unlock new superpowers!
                    </HelpTooltip>
                  </div>
                  <div className="ui-muted font-medium">AI Helper Creator</div>
                </div>
              </div>

              <div className="flex-1 max-w-md w-full">
                <div className="flex justify-between text-sm ui-muted mb-3 font-medium">
                  <span className="flex items-center gap-1">
                    Progress
                    <HelpTooltip side="right">
                      XP (Experience Points) tracks your progress. Earn XP by completing tutorials, creating helpers, and using the platform!
                    </HelpTooltip>
                  </span>
                  <span>{progress.xp} / {xpToNextLevel} XP</span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gray-900 rounded-full transition-all duration-500"
                    style={{ width: `${xpProgress}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold">{progress.completed_lessons?.length || 0}</div>
                  <div className="text-sm ui-muted">Lessons</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">{agents.length}</div>
                  <div className="text-sm ui-muted">Agents</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="mb-16">
        <h2 className="text-2xl md:text-3xl font-bold mb-2 text-center">What can AgentCraft help with?</h2>
        <p className="ui-muted text-center mb-8">Core capabilities at your fingertips</p>
        <Suspense fallback={<div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-gray-400" /></div>}>
          <FeatureIconGrid />
        </Suspense>
      </div>

      <div className="mb-16">
        <h2 className="text-2xl md:text-3xl font-bold mb-2 text-center">Quick Actions</h2>
        <p className="ui-muted text-center mb-8">Everything in one unified workflow</p>
        <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6 max-w-6xl mx-auto">
          {quickActions.map((action, index) => (
            <Link key={index} to={action.action}>
              <Card className="p-8 cursor-pointer group hover:shadow-xl transition-all duration-200 hover:scale-[1.02]">
                <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-6 group-hover:bg-gray-900 transition-colors">
                  <action.icon className="w-7 h-7 text-gray-900 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{action.title}</h3>
                <p className="ui-muted text-sm mb-4">{action.description}</p>
                <div className="flex items-center text-sm font-medium group-hover:gap-2 transition-all">
                  <span>Start</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {progress && (
        <Card className="max-w-5xl mx-auto">
          <CardContent className="p-8 md:p-12">
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-6 h-6" />
              <h3 className="text-2xl font-bold flex items-center gap-2">
                Your Superpowers
                <HelpTooltip>
                  These are skills you can give to your AI Helpers. Unlock more by leveling up through tutorials!
                </HelpTooltip>
              </h3>
            </div>
            <ExplanationCard title="What are Superpowers?">
              Superpowers are special abilities you can add to your AI Helpers. Start with basic chat, then unlock Memory (remembers conversations), Web Search (finds info online), and more as you level up!
            </ExplanationCard>
            <div className="mt-6"></div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {ALL_ABILITIES.map((abilityId) => {
                const isUnlocked = unlockedAbilities.includes(abilityId);
                const Icon = ABILITY_ICONS[abilityId];

                return (
                  <div
                    key={abilityId}
                    className={`p-5 rounded-xl border transition-all ${
                      isUnlocked 
                        ? 'bg-white border-gray-200 hover:border-gray-300' 
                        : 'bg-gray-50 border-gray-100 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      {isUnlocked ? (
                        <Icon className="w-5 h-5" />
                      ) : (
                        <Lock className="w-5 h-5 ui-muted" />
                      )}
                      {isUnlocked && (
                        <div className="w-6 h-6 rounded-full bg-gray-900 flex items-center justify-center">
                          <Check className="w-3.5 h-3.5 text-white" />
                        </div>
                      )}
                    </div>
                    <div className={`text-sm font-semibold ${isUnlocked ? '' : 'ui-muted'}`}>
                      {ABILITY_NAMES[abilityId]}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {agents.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl md:text-3xl font-bold mb-8">Recent Agents</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {agents.slice(0, 3).map((agent) => (
              <Card key={agent.id} className="p-6 group hover:shadow-xl transition-all duration-200 hover:scale-[1.02] cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center mb-4 group-hover:bg-gray-900 transition-colors">
                  <Sparkles className="w-6 h-6 text-gray-900 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{agent.name}</h3>
                <p className="ui-muted text-sm mb-4 line-clamp-2">{agent.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs ui-muted">{agent.abilities?.length || 0} abilities</span>
                  <Link to={createPageUrl("Builder") + "?agent=" + agent.id} className="inline-block">
                    <Button variant="primary" size="sm">
                      Edit
                    </Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}
    </PageShell>
  );
}