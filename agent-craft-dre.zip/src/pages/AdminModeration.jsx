import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Textarea";
import { Card } from "@/components/ui/Card";
import { Shield, AlertTriangle, CheckCircle, Trash2, Eye, Ban, Users, RefreshCw, AlertCircle, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AdminModeration() {
  const [user, setUser] = useState(null);
  const [selectedTab, setSelectedTab] = useState("flagged"); // Changed initial tab to "flagged"
  const [reviewingItem, setReviewingItem] = useState(null);
  const [adminNotes, setAdminNotes] = useState("");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  // Query for flagged content needing review
  const { data: flaggedContent = [] } = useQuery({
    queryKey: ['flaggedContent'],
    queryFn: () => base44.entities.ContentModeration.filter({ status: "pending_review" }),
    initialData: [],
  });

  // Query for blocked content
  const { data: blockedContent = [] } = useQuery({
    queryKey: ['blockedContent'],
    queryFn: () => base44.entities.ContentModeration.filter({ status: "blocked" }),
    initialData: [],
  });

  // Query for all posts
  const { data: posts = [] } = useQuery({
    queryKey: ['allForumPosts'],
    queryFn: () => base44.entities.ForumPost.list('-created_date', 100),
    initialData: [],
  });

  // Query for all agents
  const { data: agents = [] } = useQuery({
    queryKey: ['allPublicAgents'],
    queryFn: () => base44.entities.Agent.filter({ is_public: true }),
    initialData: [],
  });

  // Query for all reviews
  const { data: reviews = [] } = useQuery({
    queryKey: ['allReviews'],
    queryFn: () => base44.entities.AgentReview.list('-created_date', 100),
    initialData: [],
  });

  const approveContentMutation = useMutation({
    mutationFn: async ({ moderationId, contentId, contentType }) => {
      await base44.entities.ContentModeration.update(moderationId, {
        status: "approved",
        reviewed_by: user.email,
        reviewed_at: new Date().toISOString(),
        admin_notes: adminNotes
      });
      
      // If it was an agent, no need to restore since we didn't delete it
      // If it was a post or review, they're already created
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['flaggedContent'] });
      queryClient.invalidateQueries({ queryKey: ['blockedContent'] }); // Invalidate blocked as well, in case content was previously blocked and now approved
      alert("Content approved successfully");
      setReviewingItem(null);
      setAdminNotes("");
    },
  });

  const blockContentMutation = useMutation({
    mutationFn: async ({ moderationId, contentId, contentType }) => {
      await base44.entities.ContentModeration.update(moderationId, {
        status: "blocked",
        reviewed_by: user.email,
        reviewed_at: new Date().toISOString(),
        admin_notes: adminNotes
      });

      // Delete the actual content
      if (contentType === "agent") {
        await base44.entities.Agent.delete(contentId);
      } else if (contentType === "forum_post") {
        await base44.entities.ForumPost.delete(contentId);
      } else if (contentType === "review") {
        await base44.entities.AgentReview.delete(contentId);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['flaggedContent'] });
      queryClient.invalidateQueries({ queryKey: ['blockedContent'] });
      queryClient.invalidateQueries({ queryKey: ['allForumPosts'] });
      queryClient.invalidateQueries({ queryKey: ['allPublicAgents'] });
      queryClient.invalidateQueries({ queryKey: ['allReviews'] });
      alert("Content blocked successfully");
      setReviewingItem(null);
      setAdminNotes("");
    },
  });

  const unblockContentMutation = useMutation({
    mutationFn: async ({ moderationId }) => {
      await base44.entities.ContentModeration.update(moderationId, {
        status: "approved",
        reviewed_by: user.email,
        reviewed_at: new Date().toISOString(),
        admin_notes: adminNotes || "Unblocked by admin override"
      });
      // Note: This operation assumes the original content (agent, post, review) was NOT deleted
      // when it was blocked by the moderation system. If blocking involved deletion,
      // an unblock operation would need to 'restore' the content, which isn't currently defined.
      // For this implementation, we assume 'blocking' marks the content as blocked in moderation
      // but doesn't necessarily remove it from the primary entity database for unblocking to work.
      // If content was physically deleted by blockContentMutation, unblocking only updates the moderation record.
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['flaggedContent'] });
      queryClient.invalidateQueries({ queryKey: ['blockedContent'] });
      alert("Content unblocked successfully");
      setAdminNotes("");
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: (postId) => base44.entities.ForumPost.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allForumPosts'] });
      alert("Post deleted successfully");
    },
  });

  const deleteAgentMutation = useMutation({
    mutationFn: (agentId) => base44.entities.Agent.delete(agentId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allPublicAgents'] });
      alert("Agent removed from marketplace");
    },
  });

  const deleteReviewMutation = useMutation({
    mutationFn: (reviewId) => base44.entities.AgentReview.delete(reviewId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allReviews'] });
      alert("Review deleted successfully");
    },
  });

  const pinPostMutation = useMutation({
    mutationFn: ({ postId, isPinned }) => 
      base44.entities.ForumPost.update(postId, { is_pinned: !isPinned }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['allForumPosts'] });
    },
  });

  // Check if user is admin
  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="p-12 text-center max-w-md">
          <Ban className="w-16 h-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold text-purple-800 mb-2">Access Denied</h2>
          <p className="text-purple-600">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  const getSeverityColor = (score) => {
    if (score <= 30) return { bg: '#b8f0c8', text: '#15803d' }; // Greenish
    if (score <= 50) return { bg: '#ffd9a8', text: '#c2410c' }; // Orangish
    if (score <= 70) return { bg: '#ffb8a8', text: '#dc2626' }; // Reddish
    return { bg: '#ff8a8a', text: '#991b1b' }; // Darker Red
  };

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-[20px] flex items-center justify-center" style={{
              background: 'linear-gradient(145deg, #ffb8a8, #ffd5c9)',
              boxShadow: '8px 8px 16px rgba(240, 170, 160, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9)'
            }}>
              <Shield className="w-7 h-7 text-red-600" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-purple-800">Content Moderation</h1>
              <p className="text-purple-600">AI-powered content review system</p> {/* Updated text */}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6"> {/* Updated grid layout */}
            <Card className="p-4 text-center">
              <AlertCircle className="w-6 h-6 mx-auto mb-2 text-amber-600" />
              <div className="text-2xl font-bold text-purple-800">{flaggedContent.length}</div>
              <div className="text-sm text-purple-600">Needs Review</div>
            </Card>
            <Card className="p-4 text-center">
              <XCircle className="w-6 h-6 mx-auto mb-2 text-red-600" />
              <div className="text-2xl font-bold text-purple-800">{blockedContent.length}</div>
              <div className="text-sm text-purple-600">Blocked</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-800">{posts.length}</div>
              <div className="text-sm text-purple-600">Forum Posts</div>
            </Card>
            <Card className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-800">{agents.length}</div>
              <div className="text-sm text-purple-600">Public Agents</div>
            </Card>
          </div>

          {/* Tabs */}
          <div className="flex gap-3 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedTab("flagged")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap flex items-center gap-2 transition-all ${selectedTab === "flagged" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
            >
              <AlertCircle className="w-4 h-4" />
              Flagged Content ({flaggedContent.length})
            </button>
            <button
              onClick={() => setSelectedTab("blocked")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap flex items-center gap-2 transition-all ${selectedTab === "blocked" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
            >
              <XCircle className="w-4 h-4" />
              Blocked ({blockedContent.length})
            </button>
            <button
              onClick={() => setSelectedTab("posts")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${selectedTab === "posts" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
            >
              Forum Posts
            </button>
            <button
              onClick={() => setSelectedTab("agents")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${selectedTab === "agents" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
            >
              Marketplace Agents
            </button>
            <button
              onClick={() => setSelectedTab("reviews")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${selectedTab === "reviews" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
            >
              Reviews
            </button>
          </div>
        </motion.div>

        {/* Content */}
        <div className="space-y-4">
          {/* Flagged Content Tab */}
          {selectedTab === "flagged" && (
            <>
              {flaggedContent.length === 0 ? (
                <Card className="p-12 text-center">
                  <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h3 className="text-xl font-bold text-purple-800 mb-2">All Clear!</h3>
                  <p className="text-purple-600">No content needs review right now</p>
                </Card>
              ) : (
                flaggedContent.map((item, index) => {
                  const severityColor = getSeverityColor(item.moderation_score);
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="ui-card p-6"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: severityColor.bg,
                              color: severityColor.text
                            }}>
                              Score: {item.moderation_score}/100
                            </span>
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                              color: '#6b21a8'
                            }}>
                              {item.content_type.replace('_', ' ').toUpperCase()}
                            </span>
                          </div>
                          <p className="text-purple-800 font-medium mb-2">{item.content_preview}</p>
                          <div className="text-sm text-purple-600 mb-3">
                            <strong>Flagged for:</strong> {item.moderation_reasons?.join(', ') || 'Review needed'}
                          </div>
                          <div className="text-xs text-purple-500">
                            By: {item.author_email} • Created: {new Date(item.created_date).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      {reviewingItem === item.id ? (
                        <div className="mt-4 p-4 rounded-[14px]" style={{
                          background: 'linear-gradient(145deg, #f5f3ff, #e8e6f7)',
                          boxShadow: 'inset 2px 2px 4px rgba(209, 196, 233, 0.2)'
                        }}>
                          <Textarea
                            placeholder="Admin notes (optional)..."
                            value={adminNotes}
                            onChange={(e) => setAdminNotes(e.target.value)}
                            className="mb-3"
                            rows={2}
                          />
                          <div className="flex gap-2">
                            <Button
                              onClick={() => approveContentMutation.mutate({
                                moderationId: item.id,
                                contentId: item.content_id,
                                contentType: item.content_type
                              })}
                              className="flex-1 rounded-[12px] text-white border-none" style={{
                                background: 'linear-gradient(145deg, #b8f0c8, #d5f7de)',
                                boxShadow: '4px 4px 8px rgba(160, 220, 180, 0.3)'
                              }}
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              onClick={() => blockContentMutation.mutate({
                                moderationId: item.id,
                                contentId: item.content_id,
                                contentType: item.content_type
                              })}
                              className="flex-1 rounded-[12px] text-white border-none" style={{
                                background: 'linear-gradient(145deg, #ffb8a8, #ffd5c9)',
                                boxShadow: '4px 4px 8px rgba(240, 170, 160, 0.3)'
                              }}
                            >
                              <XCircle className="w-4 h-4 mr-2" />
                              Block
                            </Button>
                            <Button
                              onClick={() => {
                                setReviewingItem(null);
                                setAdminNotes("");
                              }}
                              variant="outline"
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Button
                          onClick={() => setReviewingItem(item.id)}
                          variant="outline"
                          className="w-full"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Review Content
                        </Button>
                      )}
                    </motion.div>
                  );
                })
              )}
            </>
          )}

          {/* Blocked Content Tab */}
          {selectedTab === "blocked" && (
            <>
              {blockedContent.length === 0 ? (
                <Card className="p-12 text-center">
                  <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h3 className="text-xl font-bold text-purple-800 mb-2">No Blocked Content</h3>
                  <p className="text-purple-600">All previously blocked content has been reviewed or unblocked.</p>
                </Card>
              ) : (
                blockedContent.map((item, index) => {
                  const severityColor = getSeverityColor(item.moderation_score);
                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="ui-card p-6 opacity-80"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: severityColor.bg,
                              color: severityColor.text
                            }}>
                              Score: {item.moderation_score}/100
                            </span>
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold bg-red-100 text-red-700">
                              BLOCKED
                            </span>
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                              color: '#6b21a8'
                            }}>
                              {item.content_type.replace('_', ' ').toUpperCase()}
                            </span>
                          </div>
                          <p className="text-purple-800 font-medium mb-2 line-through">{item.content_preview}</p>
                          <div className="text-sm text-purple-600 mb-2">
                            <strong>Blocked for:</strong> {item.moderation_reasons?.join(', ')}
                          </div>
                          {item.admin_notes && (
                            <div className="text-sm text-purple-600 mb-2">
                              <strong>Admin Notes:</strong> {item.admin_notes}
                            </div>
                          )}
                          <div className="text-xs text-purple-500">
                            By: {item.author_email} • Blocked: {item.reviewed_at ? new Date(item.reviewed_at).toLocaleString() : 'Auto-blocked'}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => {
                              if (window.confirm("Unblock this content? It will become visible immediately.")) {
                                unblockContentMutation.mutate({ moderationId: item.id });
                              }
                            }}
                            variant="ghost"
                            size="icon"
                            title="Unblock (Override)"
                          >
                            <RefreshCw className="w-4 h-4 text-green-600" />
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </>
          )}

          {selectedTab === "posts" && (
            <>
              {posts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="ui-card p-6"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="text-lg font-bold text-purple-800">{post.title}</h3>
                        {post.is_pinned && (
                          <span className="px-2 py-1 rounded-[8px] text-xs font-bold text-amber-700" style={{
                            background: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)',
                            boxShadow: '2px 2px 4px rgba(240, 200, 150, 0.3)'
                          }}>
                            PINNED
                          </span>
                        )}
                      </div>
                      <p className="text-purple-600 text-sm mb-2 line-clamp-2">{post.content}</p>
                      <div className="flex items-center gap-4 text-xs text-purple-500">
                        <span>By {post.author_name}</span>
                        <span>Category: {post.category}</span>
                        <span>{post.upvotes || 0} upvotes</span>
                        <span>{new Date(post.created_date).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => pinPostMutation.mutate({ postId: post.id, isPinned: post.is_pinned })}
                        variant="ghost"
                        size="icon"
                        title={post.is_pinned ? "Unpin" : "Pin"}
                      >
                        <CheckCircle className="w-4 h-4 text-purple-700" />
                      </Button>
                      <Button
                        onClick={() => {
                          if (window.confirm("Delete this post?")) {
                            deletePostMutation.mutate(post.id);
                          }
                        }}
                        variant="ghost"
                        size="icon"
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </>
          )}

          {selectedTab === "agents" && (
            <>
              {agents.map((agent, index) => (
                <motion.div
                  key={agent.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="ui-card p-6"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-purple-800 mb-2">{agent.name}</h3>
                      <p className="text-purple-600 text-sm mb-2 line-clamp-2">{agent.description}</p>
                      <div className="flex items-center gap-4 text-xs text-purple-500">
                        <span>By {agent.creator_name || agent.created_by}</span>
                        <span>Price: ${agent.price.toFixed(2)}</span>
                        <span>{agent.download_count || 0} downloads</span>
                        <span>Rating: {(agent.average_rating || 0).toFixed(1)}</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        if (window.confirm("Remove this agent from marketplace?")) {
                          deleteAgentMutation.mutate(agent.id);
                        }
                      }}
                      variant="ghost"
                      size="icon"
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </>
          )}

          {selectedTab === "reviews" && (
            <>
              {reviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="ui-card p-6"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-lg font-bold text-purple-800">{review.reviewer_name}</span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <span key={i} className={i < review.rating ? "text-amber-500" : "text-gray-300"}>★</span>
                          ))}
                        </div>
                      </div>
                      <p className="text-purple-600 text-sm mb-2">{review.review_text}</p>
                      <div className="flex items-center gap-4 text-xs text-purple-500">
                        <span>Agent ID: {review.agent_id}</span>
                        {review.is_verified_purchase && (
                          <span className="px-2 py-1 rounded-[8px] bg-green-100 text-green-700">Verified Purchase</span>
                        )}
                        <span>{new Date(review.created_date).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        if (window.confirm("Delete this review?")) {
                          deleteReviewMutation.mutate(review.id);
                        }
                      }}
                      variant="ghost"
                      size="icon"
                      className="text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}