import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { 
  Store, Mail, Globe, Calendar, Database, Code, 
  MessageSquare, Loader2, Download, Search, TrendingUp
} from "lucide-react";
import { AnimatePresence } from "framer-motion";
import TemplatePreviewModal from "../components/actions/TemplatePreviewModal";

const ACTION_ICONS = {
  send_email: Mail,
  http_request: Globe,
  slack_message: MessageSquare,
  calendar_event: Calendar,
  database_query: Database,
  custom_function: Code
};

export default function ActionMarketplace() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [previewTemplate, setPreviewTemplate] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: publicTemplates = [], isLoading } = useQuery({
    queryKey: ['publicActionTemplates'],
    queryFn: () => base44.entities.AgentAction.filter({ is_public: true }),
    enabled: !!user
  });

  const importTemplateMutation = useMutation({
    mutationFn: (template) => {
      const { id, created_date, updated_date, created_by, ...data } = template;
      return base44.entities.AgentAction.create({
        ...data,
        is_template: false,
        is_public: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentActions'] });
    }
  });

  const filteredTemplates = publicTemplates.filter(template => {
    const matchesSearch = !searchQuery || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ['all', ...new Set(publicTemplates.map(t => t.category))];

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Action Marketplace</h1>
              <p className="text-gray-600">Discover and use community action templates</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <TrendingUp className="w-4 h-4" />
            <span>{publicTemplates.length} templates available</span>
          </div>
        </div>

        <div className="mb-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              placeholder="Search templates..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map(cat => (
              <Button
                key={cat}
                size="sm"
                variant={selectedCategory === cat ? 'primary' : 'outline'}
                onClick={() => setSelectedCategory(cat)}
                className="capitalize"
              >
                {cat === 'all' ? 'All' : cat}
              </Button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {filteredTemplates.map((template) => {
              const Icon = ACTION_ICONS[template.action_type] || Code;
              return (
                <Card key={template.id} className="p-5 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-purple-600" />
                    </div>
                    <div className="px-2 py-1 bg-gray-100 rounded-full text-xs capitalize">
                      {template.category}
                    </div>
                  </div>
                  <h3 className="font-semibold mb-1">{template.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{template.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">by {template.created_by?.split('@')[0]}</span>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setPreviewTemplate(template)}
                      >
                        Preview
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => importTemplateMutation.mutate(template)}
                        disabled={importTemplateMutation.isPending}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {importTemplateMutation.isPending ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <>
                            <Download className="w-3 h-3 mr-1" />
                            Use
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </Card>
              );
            })}
            {filteredTemplates.length === 0 && (
              <Card className="col-span-3 p-12 text-center">
                <Store className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">No templates found</h3>
                <p className="text-gray-600">Try adjusting your search or filters</p>
              </Card>
            )}
          </div>
        )}

        <AnimatePresence>
          {previewTemplate && (
            <TemplatePreviewModal
              template={previewTemplate}
              onClose={() => setPreviewTemplate(null)}
              onUse={(template) => {
                importTemplateMutation.mutate(template);
                setPreviewTemplate(null);
              }}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}