import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";
import { 
  Zap, Plus, Mail, Globe, Calendar, Database, Code, 
  MessageSquare, Save, Loader2, Play, Trash2, CheckCircle, XCircle, Upload
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import InputSchemaBuilder from "../components/actions/InputSchemaBuilder";
import TemplatePreviewModal from "../components/actions/TemplatePreviewModal";

const ACTION_TYPES = [
  { id: 'send_email', name: 'Send Email', icon: Mail, category: 'communication', description: 'Send emails programmatically' },
  { id: 'http_request', name: 'HTTP Request', icon: Globe, category: 'integration', description: 'Call any REST API' },
  { id: 'slack_message', name: 'Slack Message', icon: MessageSquare, category: 'communication', description: 'Send Slack messages' },
  { id: 'calendar_event', name: 'Calendar Event', icon: Calendar, category: 'productivity', description: 'Create calendar events' },
  { id: 'database_query', name: 'Database Query', icon: Database, category: 'data', description: 'Query your entities' },
  { id: 'custom_function', name: 'Custom Function', icon: Code, category: 'utility', description: 'Call a backend function' }
];

const TEMPLATES = [
  // Communication Templates
  {
    name: 'Send Welcome Email',
    description: 'Send a personalized welcome email to new users',
    action_type: 'send_email',
    category: 'communication',
    input_schema: {
      type: 'object',
      properties: {
        to: { type: 'string', description: 'Recipient email' },
        userName: { type: 'string', description: 'User name for personalization' }
      },
      required: ['to', 'userName']
    },
    config: {
      subject: 'Welcome to AgentCraft, {{userName}}!',
      body: 'Hi {{userName}},\n\nWelcome to our platform! We\'re excited to have you join us.\n\nBest regards,\nThe AgentCraft Team'
    }
  },
  {
    name: 'Send Password Reset Email',
    description: 'Send password reset link to users',
    action_type: 'send_email',
    category: 'communication',
    input_schema: {
      type: 'object',
      properties: {
        to: { type: 'string', description: 'User email' },
        resetLink: { type: 'string', description: 'Password reset URL' }
      },
      required: ['to', 'resetLink']
    },
    config: {
      subject: 'Password Reset Request',
      body: 'You requested a password reset. Click here: {{resetLink}}\n\nThis link expires in 1 hour.'
    }
  },
  {
    name: 'Team Notification',
    description: 'Send Slack notifications to your team',
    action_type: 'slack_message',
    category: 'communication',
    input_schema: {
      type: 'object',
      properties: {
        event: { type: 'string', description: 'What happened' },
        userName: { type: 'string', description: 'User involved' }
      },
      required: ['event']
    },
    config: {
      message_template: '🔔 {{event}}\nUser: {{userName}}\nTime: {{timestamp}}'
    }
  },
  {
    name: 'Customer Support Alert',
    description: 'Alert support team via Slack',
    action_type: 'slack_message',
    category: 'communication',
    input_schema: {
      type: 'object',
      properties: {
        ticketId: { type: 'string', description: 'Support ticket ID' },
        customerName: { type: 'string', description: 'Customer name' },
        priority: { type: 'string', description: 'high, medium, or low' }
      },
      required: ['ticketId', 'priority']
    },
    config: {
      message_template: '🚨 New {{priority}} priority ticket\nID: #{{ticketId}}\nCustomer: {{customerName}}'
    }
  },

  // Integration Templates
  {
    name: 'Webhook POST',
    description: 'Send data to any webhook URL',
    action_type: 'http_request',
    category: 'integration',
    input_schema: {
      type: 'object',
      properties: {
        data: { type: 'object', description: 'JSON data to send' }
      }
    },
    config: { method: 'POST', url: '', headers: { 'Content-Type': 'application/json' } }
  },
  {
    name: 'REST API GET',
    description: 'Fetch data from any REST API',
    action_type: 'http_request',
    category: 'integration',
    input_schema: {
      type: 'object',
      properties: {
        endpoint: { type: 'string', description: 'API endpoint path' }
      },
      required: ['endpoint']
    },
    config: { 
      method: 'GET', 
      url: 'https://api.example.com/{{endpoint}}',
      headers: { 'Content-Type': 'application/json' }
    }
  },
  {
    name: 'Update External CRM',
    description: 'Sync contact data to external CRM',
    action_type: 'http_request',
    category: 'integration',
    input_schema: {
      type: 'object',
      properties: {
        contactId: { type: 'string', description: 'Contact ID' },
        name: { type: 'string', description: 'Contact name' },
        email: { type: 'string', description: 'Contact email' },
        status: { type: 'string', description: 'Lead status' }
      },
      required: ['contactId', 'email']
    },
    config: { 
      method: 'PUT', 
      url: 'https://api.crm.com/contacts/{{contactId}}',
      body_template: '{"name": "{{name}}", "email": "{{email}}", "status": "{{status}}"}',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer YOUR_API_KEY' }
    }
  },

  // Data Templates
  {
    name: 'List Entities',
    description: 'Retrieve records from any entity',
    action_type: 'database_query',
    category: 'data',
    input_schema: {
      type: 'object',
      properties: {
        entity: { type: 'string', description: 'Entity name' },
        operation: { type: 'string', enum: ['list', 'filter'] }
      },
      required: ['entity', 'operation']
    },
    config: { operation: 'list' }
  },
  {
    name: 'Create Contact',
    description: 'Add new contact to database',
    action_type: 'database_query',
    category: 'data',
    input_schema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Contact name' },
        email: { type: 'string', description: 'Contact email' },
        company: { type: 'string', description: 'Company name' }
      },
      required: ['name', 'email']
    },
    config: { 
      entity: 'Contact',
      operation: 'create',
      data: '{"name": "{{name}}", "email": "{{email}}", "company": "{{company}}"}'
    }
  },
  {
    name: 'Update Agent Status',
    description: 'Change agent status in database',
    action_type: 'database_query',
    category: 'data',
    input_schema: {
      type: 'object',
      properties: {
        agentId: { type: 'string', description: 'Agent ID' },
        status: { type: 'string', description: 'New status' }
      },
      required: ['agentId', 'status']
    },
    config: { 
      entity: 'Agent',
      operation: 'update',
      filter: '{"id": "{{agentId}}"}',
      data: '{"is_active": "{{status}}"}'
    }
  },
  {
    name: 'Find Active Leads',
    description: 'Filter contacts by status',
    action_type: 'database_query',
    category: 'data',
    input_schema: {
      type: 'object',
      properties: {
        status: { type: 'string', description: 'Lead status to filter' }
      },
      required: ['status']
    },
    config: { 
      entity: 'Contact',
      operation: 'filter',
      filter: '{"status": "{{status}}"}'
    }
  },

  // Productivity Templates
  {
    name: 'Schedule Client Meeting',
    description: 'Create calendar event for client meetings',
    action_type: 'calendar_event',
    category: 'productivity',
    input_schema: {
      type: 'object',
      properties: {
        clientName: { type: 'string', description: 'Client name' },
        clientEmail: { type: 'string', description: 'Client email' },
        startTime: { type: 'string', description: 'ISO format datetime' },
        meetingType: { type: 'string', description: 'e.g., Discovery, Follow-up' }
      },
      required: ['clientName', 'clientEmail', 'startTime']
    },
    config: {
      title: '{{meetingType}} Meeting: {{clientName}}',
      description: 'Meeting with {{clientName}} to discuss project details',
      duration: 60,
      attendees: '{{clientEmail}}'
    }
  },
  {
    name: 'Team Standup',
    description: 'Schedule recurring team standups',
    action_type: 'calendar_event',
    category: 'productivity',
    input_schema: {
      type: 'object',
      properties: {
        startTime: { type: 'string', description: 'ISO format datetime' }
      },
      required: ['startTime']
    },
    config: {
      title: 'Daily Team Standup',
      description: 'Quick sync on daily progress and blockers',
      duration: 15,
      attendees: 'team@company.com'
    }
  },
  {
    name: 'Interview Scheduler',
    description: 'Schedule candidate interviews',
    action_type: 'calendar_event',
    category: 'productivity',
    input_schema: {
      type: 'object',
      properties: {
        candidateName: { type: 'string', description: 'Candidate name' },
        candidateEmail: { type: 'string', description: 'Candidate email' },
        position: { type: 'string', description: 'Role applying for' },
        startTime: { type: 'string', description: 'ISO format datetime' },
        interviewers: { type: 'string', description: 'Comma-separated emails' }
      },
      required: ['candidateName', 'candidateEmail', 'startTime']
    },
    config: {
      title: 'Interview: {{candidateName}} - {{position}}',
      description: 'Technical interview for {{position}} role',
      duration: 60,
      attendees: '{{candidateEmail}},{{interviewers}}'
    }
  }
];

export default function ActionBuilder() {
  const [user, setUser] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedAction, setSelectedAction] = useState(null);
  const [testInput, setTestInput] = useState('{}');
  const [testResult, setTestResult] = useState(null);
  const [validationErrors, setValidationErrors] = useState({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [previewTemplate, setPreviewTemplate] = useState(null);
  const queryClient = useQueryClient();

  const [form, setForm] = useState({
    name: '',
    description: '',
    action_type: 'http_request',
    category: 'utility',
    config: { method: 'GET', url: '', headers: {}, body_template: '' },
    input_schema: { type: 'object', properties: {} }
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: actions = [], isLoading } = useQuery({
    queryKey: ['agentActions'],
    queryFn: () => base44.entities.AgentAction.list('-created_date'),
    enabled: !!user
  });

  const { data: executions = [] } = useQuery({
    queryKey: ['actionExecutions'],
    queryFn: () => base44.entities.ActionExecution.list('-created_date', 20),
    enabled: !!user
  });

  const createActionMutation = useMutation({
    mutationFn: (data) => base44.entities.AgentAction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentActions'] });
      setShowCreate(false);
      resetForm();
    }
  });

  const deleteActionMutation = useMutation({
    mutationFn: (id) => base44.entities.AgentAction.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['agentActions'] })
  });

  const publishTemplateMutation = useMutation({
    mutationFn: ({ id, isPublic }) => base44.entities.AgentAction.update(id, { is_template: true, is_public: isPublic }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['agentActions'] })
  });

  const testActionMutation = useMutation({
    mutationFn: async ({ actionId, inputData }) => {
      const response = await base44.functions.invoke('executeAction', { actionId, inputData });
      return response.data;
    },
    onSuccess: (data) => {
      setTestResult(data);
      queryClient.invalidateQueries({ queryKey: ['actionExecutions'] });
    }
  });

  const resetForm = () => {
    setForm({
      name: '',
      description: '',
      action_type: 'http_request',
      category: 'utility',
      config: { method: 'GET', url: '', headers: {}, body_template: '' },
      input_schema: { type: 'object', properties: {} }
    });
    setValidationErrors({});
  };

  const handleCreateFromTemplate = (template) => {
    setForm({
      name: template.name,
      description: template.description,
      action_type: template.action_type,
      category: template.category,
      config: template.config,
      input_schema: template.input_schema
    });
    setShowCreate(true);
  };

  const validateForm = () => {
    const errors = {};
    
    if (!form.name.trim()) errors.name = 'Name is required';
    if (!form.description.trim()) errors.description = 'Description is required';
    
    // Type-specific validation
    if (form.action_type === 'http_request' && !form.config.url) {
      errors.url = 'URL is required';
    }
    if (form.action_type === 'send_email') {
      if (!form.config.to) errors.to = 'Recipient email is required';
      if (!form.config.subject) errors.subject = 'Subject is required';
      if (!form.config.body) errors.body = 'Email body is required';
    }
    if (form.action_type === 'slack_message' && !form.config.webhook_url) {
      errors.webhook_url = 'Webhook URL is required';
    }
    if (form.action_type === 'database_query' && !form.config.entity) {
      errors.entity = 'Entity name is required';
    }
    if (form.action_type === 'calendar_event') {
      if (!form.config.title) errors.title = 'Event title is required';
      if (!form.config.start_time) errors.start_time = 'Start time is required';
    }
    if (form.action_type === 'custom_function' && !form.config.function_name) {
      errors.function_name = 'Function name is required';
    }
    
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSave = () => {
    if (validateForm()) {
      createActionMutation.mutate(form);
    }
  };

  const handleTest = () => {
    if (!selectedAction) return;
    try {
      const inputData = JSON.parse(testInput);
      testActionMutation.mutate({ actionId: selectedAction.id, inputData });
    } catch (e) {
      setTestResult({ error: 'Invalid JSON input' });
    }
  };

  const myActions = actions.filter(a => !a.is_template);
  const templateActions = actions.filter(a => a.is_template);

  const filteredTemplates = TEMPLATES.filter(template => {
    const matchesSearch = !searchQuery || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ['all', ...new Set(TEMPLATES.map(t => t.category))];

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Action Builder</h1>
              <p className="text-gray-600">Create tools your agents can use</p>
            </div>
          </div>
          <Button
            onClick={() => setShowCreate(true)}
            className="bg-gradient-to-r from-amber-500 to-orange-500 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Action
          </Button>
        </div>

        <Tabs defaultValue="my-actions" className="space-y-6">
          <TabsList className="bg-gray-100 p-1 rounded-xl">
            <TabsTrigger value="my-actions">My Actions</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="executions">Execution Log</TabsTrigger>
          </TabsList>

          <TabsContent value="my-actions">
            <div className="grid md:grid-cols-3 gap-6">
              {myActions.map((action) => {
                const typeInfo = ACTION_TYPES.find(t => t.id === action.action_type);
                const Icon = typeInfo?.icon || Zap;
                return (
                  <Card key={action.id} className="p-5 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                        <Icon className="w-5 h-5 text-amber-600" />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteActionMutation.mutate(action.id)}
                        className="text-gray-400 hover:text-red-500"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <h3 className="font-semibold mb-1">{action.name}</h3>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{action.description}</p>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">{action.action_type}</span>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => publishTemplateMutation.mutate({ id: action.id, isPublic: true })}
                          disabled={publishTemplateMutation.isPending}
                        >
                          <Upload className="w-3 h-3 mr-1" />
                          Share
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { setSelectedAction(action); setTestResult(null); }}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Test
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
              {myActions.length === 0 && (
                <Card className="col-span-3 p-12 text-center">
                  <Zap className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="font-semibold text-lg mb-2">No actions yet</h3>
                  <p className="text-gray-600 mb-4">Create your first action or start from a template</p>
                  <Button onClick={() => setShowCreate(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Action
                  </Button>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="templates">
            <div className="mb-6 space-y-4">
              <Input
                placeholder="Search templates..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="max-w-md"
              />
              <div className="flex gap-2 flex-wrap">
                {categories.map(cat => (
                  <Button
                    key={cat}
                    size="sm"
                    variant={selectedCategory === cat ? 'primary' : 'outline'}
                    onClick={() => setSelectedCategory(cat)}
                    className="capitalize"
                  >
                    {cat === 'all' ? 'All' : cat}
                  </Button>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {filteredTemplates.map((template, i) => {
                const typeInfo = ACTION_TYPES.find(t => t.id === template.action_type);
                const Icon = typeInfo?.icon || Zap;
                return (
                  <Card key={i} className="p-5 border-dashed border-2 hover:border-amber-400 transition-colors cursor-pointer" onClick={() => setPreviewTemplate(template)}>
                    <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center mb-3">
                      <Icon className="w-5 h-5 text-gray-600" />
                    </div>
                    <h3 className="font-semibold mb-1">{template.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                    <span className="text-xs text-amber-600">Click to preview →</span>
                  </Card>
                );
              })}
              {filteredTemplates.length === 0 && (
                <Card className="col-span-3 p-12 text-center">
                  <p className="text-gray-600">No templates match your search</p>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="executions">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Recent Executions</h3>
              <div className="space-y-2">
                {executions.map((exec) => (
                  <div key={exec.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {exec.status === 'success' ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : exec.status === 'failed' ? (
                        <XCircle className="w-4 h-4 text-red-500" />
                      ) : (
                        <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />
                      )}
                      <div>
                        <span className="font-medium text-sm">{exec.action_name}</span>
                        {exec.agent_name && <span className="text-xs text-gray-500 ml-2">via {exec.agent_name}</span>}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {exec.execution_time_ms}ms • {new Date(exec.created_date).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
                {executions.length === 0 && (
                  <p className="text-center text-gray-500 py-8">No executions yet</p>
                )}
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Create/Edit Modal */}
        <AnimatePresence>
          {showCreate && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => setShowCreate(false)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto"
                onClick={e => e.stopPropagation()}
              >
                <h2 className="text-xl font-bold mb-6">Create Action</h2>
                <div className="space-y-4">
                  <div>
                    <Label>Name *</Label>
                    <Input
                      value={form.name}
                      onChange={e => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g., Send Welcome Email, Create Task"
                      className={`mt-1 ${validationErrors.name ? 'border-red-500' : ''}`}
                    />
                    {validationErrors.name && <p className="text-xs text-red-500 mt-1">{validationErrors.name}</p>}
                  </div>
                  <div>
                    <Label>Description *</Label>
                    <Textarea
                      value={form.description}
                      onChange={e => setForm({ ...form, description: e.target.value })}
                      placeholder="Explain what this action does and when it should be used"
                      className={`mt-1 ${validationErrors.description ? 'border-red-500' : ''}`}
                    />
                    {validationErrors.description && <p className="text-xs text-red-500 mt-1">{validationErrors.description}</p>}
                  </div>
                  <div>
                    <Label>Type</Label>
                    <Select value={form.action_type} onValueChange={v => setForm({ ...form, action_type: v })}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {ACTION_TYPES.map(t => (
                          <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {form.action_type === 'http_request' && (
                    <>
                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <Label>Method</Label>
                          <Select value={form.config.method} onValueChange={v => setForm({ ...form, config: { ...form.config, method: v } })}>
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map(m => (
                                <SelectItem key={m} value={m}>{m}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="col-span-2">
                          <Label>URL *</Label>
                          <Input
                            value={form.config.url}
                            onChange={e => setForm({ ...form, config: { ...form.config, url: e.target.value } })}
                            placeholder="https://api.example.com/users"
                            className={`mt-1 ${validationErrors.url ? 'border-red-500' : ''}`}
                          />
                          {validationErrors.url && <p className="text-xs text-red-500 mt-1">{validationErrors.url}</p>}
                          <p className="text-xs text-gray-500 mt-1">💡 Use {"{{variableName}}"} for dynamic values</p>
                        </div>
                      </div>
                      <div>
                        <Label>Body Template (JSON)</Label>
                        <Textarea
                          value={form.config.body_template}
                          onChange={e => setForm({ ...form, config: { ...form.config, body_template: e.target.value } })}
                          placeholder='{"userId": "{{userId}}", "name": "{{userName}}", "action": "signup"}'
                          className="mt-1 font-mono text-sm"
                          rows={3}
                        />
                        <p className="text-xs text-gray-500 mt-1">💡 For POST/PUT/PATCH only. Use JSON format with {"{{variables}}"}</p>
                      </div>
                    </>
                  )}

                  {form.action_type === 'send_email' && (
                    <>
                      <div>
                        <Label>Recipient Email *</Label>
                        <Input
                          value={form.config.to || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, to: e.target.value } })}
                          placeholder="user@example.com or {{userEmail}}"
                          className={`mt-1 ${validationErrors.to ? 'border-red-500' : ''}`}
                        />
                        {validationErrors.to && <p className="text-xs text-red-500 mt-1">{validationErrors.to}</p>}
                        <p className="text-xs text-gray-500 mt-1">💡 Use {"{{variableName}}"} for dynamic values</p>
                      </div>
                      <div>
                        <Label>Subject *</Label>
                        <Input
                          value={form.config.subject || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, subject: e.target.value } })}
                          placeholder="Welcome to AgentCraft, {{userName}}!"
                          className={`mt-1 ${validationErrors.subject ? 'border-red-500' : ''}`}
                        />
                        {validationErrors.subject && <p className="text-xs text-red-500 mt-1">{validationErrors.subject}</p>}
                      </div>
                      <div>
                        <Label>Email Body *</Label>
                        <Textarea
                          value={form.config.body || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, body: e.target.value } })}
                          placeholder="Hi {{userName}},&#10;&#10;Welcome to our platform! We're excited to have you.&#10;&#10;Best regards,&#10;The Team"
                          className={`mt-1 ${validationErrors.body ? 'border-red-500' : ''}`}
                          rows={5}
                        />
                        {validationErrors.body && <p className="text-xs text-red-500 mt-1">{validationErrors.body}</p>}
                      </div>
                    </>
                  )}

                  {form.action_type === 'slack_message' && (
                    <>
                      <div>
                        <Label>Slack Webhook URL *</Label>
                        <Input
                          value={form.config.webhook_url || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, webhook_url: e.target.value } })}
                          placeholder="https://hooks.slack.com/services/T00/B00/XXX"
                          className={`mt-1 ${validationErrors.webhook_url ? 'border-red-500' : ''}`}
                        />
                        {validationErrors.webhook_url && <p className="text-xs text-red-500 mt-1">{validationErrors.webhook_url}</p>}
                        <p className="text-xs text-gray-500 mt-1">💡 Get from Slack: Settings → Incoming Webhooks</p>
                      </div>
                      <div>
                        <Label>Message Template</Label>
                        <Textarea
                          value={form.config.message_template || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, message_template: e.target.value } })}
                          placeholder="🎉 New signup: {{userName}} ({{userEmail}})"
                          className="mt-1"
                          rows={3}
                        />
                        <p className="text-xs text-gray-500 mt-1">💡 Use emojis and {"{{variables}}"} for rich messages</p>
                      </div>
                    </>
                  )}

                  {form.action_type === 'database_query' && (
                    <>
                      <div>
                        <Label>Entity Name *</Label>
                        <Input
                          value={form.config.entity || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, entity: e.target.value } })}
                          placeholder="Agent, Contact, Deal, Task..."
                          className={`mt-1 ${validationErrors.entity ? 'border-red-500' : ''}`}
                        />
                        {validationErrors.entity && <p className="text-xs text-red-500 mt-1">{validationErrors.entity}</p>}
                        <p className="text-xs text-gray-500 mt-1">💡 Exact entity name (case-sensitive)</p>
                      </div>
                      <div>
                        <Label>Operation</Label>
                        <Select value={form.config.operation || 'list'} onValueChange={v => setForm({ ...form, config: { ...form.config, operation: v } })}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="list">List All</SelectItem>
                            <SelectItem value="filter">Filter By Criteria</SelectItem>
                            <SelectItem value="create">Create Record</SelectItem>
                            <SelectItem value="update">Update Record</SelectItem>
                            <SelectItem value="delete">Delete Record</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {(form.config.operation === 'filter' || form.config.operation === 'update' || form.config.operation === 'delete') && (
                        <div>
                          <Label>Filter Criteria (JSON)</Label>
                          <Textarea
                            value={form.config.filter || ''}
                            onChange={e => setForm({ ...form, config: { ...form.config, filter: e.target.value } })}
                            placeholder='{"status": "active", "category": "{{category}}"}'
                            className="mt-1 font-mono text-sm"
                            rows={2}
                          />
                          <p className="text-xs text-gray-500 mt-1">💡 Match records where all conditions are true</p>
                        </div>
                      )}
                      {(form.config.operation === 'create' || form.config.operation === 'update') && (
                        <div>
                          <Label>Data (JSON)</Label>
                          <Textarea
                            value={form.config.data || ''}
                            onChange={e => setForm({ ...form, config: { ...form.config, data: e.target.value } })}
                            placeholder='{"name": "{{name}}", "status": "active", "email": "{{email}}"}'
                            className="mt-1 font-mono text-sm"
                            rows={3}
                          />
                          <p className="text-xs text-gray-500 mt-1">💡 Fields to create/update with their values</p>
                        </div>
                      )}
                    </>
                  )}

                  {form.action_type === 'calendar_event' && (
                    <>
                      <div>
                        <Label>Event Title *</Label>
                        <Input
                          value={form.config.title || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, title: e.target.value } })}
                          placeholder="Meeting: {{clientName}} - Project Kickoff"
                          className={`mt-1 ${validationErrors.title ? 'border-red-500' : ''}`}
                        />
                        {validationErrors.title && <p className="text-xs text-red-500 mt-1">{validationErrors.title}</p>}
                      </div>
                      <div>
                        <Label>Description</Label>
                        <Textarea
                          value={form.config.description || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, description: e.target.value } })}
                          placeholder="Discuss project timeline, deliverables, and next steps"
                          className="mt-1"
                          rows={2}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label>Start Time *</Label>
                          <Input
                            value={form.config.start_time || ''}
                            onChange={e => setForm({ ...form, config: { ...form.config, start_time: e.target.value } })}
                            placeholder="2025-01-15T14:00:00"
                            className={`mt-1 ${validationErrors.start_time ? 'border-red-500' : ''}`}
                          />
                          {validationErrors.start_time && <p className="text-xs text-red-500 mt-1">{validationErrors.start_time}</p>}
                          <p className="text-xs text-gray-500 mt-1">💡 ISO format or {"{{variable}}"}</p>
                        </div>
                        <div>
                          <Label>Duration (minutes)</Label>
                          <Input
                            type="number"
                            value={form.config.duration || 60}
                            onChange={e => setForm({ ...form, config: { ...form.config, duration: parseInt(e.target.value) } })}
                            placeholder="60"
                            className="mt-1"
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Attendees (comma-separated)</Label>
                        <Input
                          value={form.config.attendees || ''}
                          onChange={e => setForm({ ...form, config: { ...form.config, attendees: e.target.value } })}
                          placeholder="john@company.com, {{clientEmail}}, team@company.com"
                          className="mt-1"
                        />
                        <p className="text-xs text-gray-500 mt-1">💡 Separate multiple emails with commas</p>
                      </div>
                    </>
                  )}

                  {form.action_type === 'custom_function' && (
                    <div>
                      <Label>Function Name *</Label>
                      <Input
                        value={form.config.function_name || ''}
                        onChange={e => setForm({ ...form, config: { ...form.config, function_name: e.target.value } })}
                        placeholder="myCustomFunction"
                        className={`mt-1 ${validationErrors.function_name ? 'border-red-500' : ''}`}
                      />
                      {validationErrors.function_name && <p className="text-xs text-red-500 mt-1">{validationErrors.function_name}</p>}
                      <p className="text-xs text-gray-500 mt-1">💡 Name of your backend function (camelCase)</p>
                    </div>
                  )}

                  <InputSchemaBuilder
                    schema={form.input_schema}
                    onChange={newSchema => setForm({ ...form, input_schema: newSchema })}
                  />
                </div>

                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={() => setShowCreate(false)} className="flex-1">Cancel</Button>
                  <Button
                    onClick={handleSave}
                    disabled={createActionMutation.isPending}
                    className="flex-1 bg-amber-500 hover:bg-amber-600"
                  >
                    {createActionMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    Save Action
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Template Preview Modal */}
        <AnimatePresence>
          {previewTemplate && (
            <TemplatePreviewModal
              template={previewTemplate}
              onClose={() => setPreviewTemplate(null)}
              onUse={(template) => {
                handleCreateFromTemplate(template);
                setPreviewTemplate(null);
              }}
            />
          )}
        </AnimatePresence>

        {/* Test Modal */}
        <AnimatePresence>
          {selectedAction && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
              onClick={() => setSelectedAction(null)}
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white rounded-2xl p-6 max-w-lg w-full"
                onClick={e => e.stopPropagation()}
              >
                <h2 className="text-xl font-bold mb-2">Test: {selectedAction.name}</h2>
                <p className="text-gray-600 text-sm mb-4">{selectedAction.description}</p>

                <div className="space-y-4">
                  <div>
                    <Label>Input (JSON)</Label>
                    <Textarea
                      value={testInput}
                      onChange={e => setTestInput(e.target.value)}
                      className="mt-1 font-mono text-sm h-24"
                      placeholder="{}"
                    />
                  </div>

                  {testResult && (
                    <div className={`p-4 rounded-lg ${testResult.success ? 'bg-green-50' : 'bg-red-50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        {testResult.success ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-600" />
                        )}
                        <span className={`font-semibold text-sm ${testResult.success ? 'text-green-700' : 'text-red-700'}`}>
                          {testResult.success ? 'Success' : 'Failed'}
                        </span>
                        {testResult.execution_time_ms && (
                          <span className="text-xs text-gray-500 ml-auto">{testResult.execution_time_ms}ms</span>
                        )}
                      </div>
                      <pre className="text-xs overflow-auto max-h-32 bg-white p-2 rounded">
                        {JSON.stringify(testResult.result || testResult.error, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>

                <div className="flex gap-3 mt-6">
                  <Button variant="outline" onClick={() => setSelectedAction(null)} className="flex-1">Close</Button>
                  <Button
                    onClick={handleTest}
                    disabled={testActionMutation.isPending}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    {testActionMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
                    Run Test
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}