import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Network, Play, CheckCircle, Clock, AlertCircle, 
  MessageSquare, Brain, Zap, ArrowRight, RefreshCw,
  Loader2, ChevronRight, Users, BookOpen, AlertTriangle
} from "lucide-react";
import ImprovementProposals from "../components/orchestration/ImprovementProposals";
import { motion, AnimatePresence } from "framer-motion";

export default function AgentOrchestration() {
  const [user, setUser] = useState(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: agents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: !!user
  });

  const { data: collaborations = [] } = useQuery({
    queryKey: ['collaborations'],
    queryFn: () => base44.entities.AgentCollaboration.list('-created_date', 20),
    enabled: !!user,
    refetchInterval: 5000
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['agentMessages'],
    queryFn: () => base44.entities.AgentMessage.list('-created_date', 50),
    enabled: !!user,
    refetchInterval: 3000
  });

  const { data: sharedKnowledge = [] } = useQuery({
    queryKey: ['sharedKnowledge'],
    queryFn: () => base44.entities.SharedKnowledge.list('-confidence_score', 20),
    enabled: !!user
  });

  const runWorkflowMutation = useMutation({
    mutationFn: async ({ workflowType, targetAgentId }) => {
      const response = await base44.functions.invoke('orchestrateWorkflow', {
        workflowType,
        targetAgentId
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['collaborations'] });
      queryClient.invalidateQueries({ queryKey: ['agentMessages'] });
    }
  });

  const syncKnowledgeMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('shareKnowledge', { action: 'sync' });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sharedKnowledge'] });
    }
  });

  const workflows = [
    {
      id: 'audit_pipeline',
      name: 'Full Audit Pipeline',
      description: 'Audit config, simulate, analyze, and suggest improvements',
      icon: CheckCircle,
      color: 'from-blue-500 to-cyan-500',
      steps: 4
    },
    {
      id: 'improvement_cycle',
      name: 'Improvement Cycle',
      description: 'Audit, apply improvements, test, and validate',
      icon: RefreshCw,
      color: 'from-purple-500 to-pink-500',
      steps: 4
    },
    {
      id: 'knowledge_sync',
      name: 'Knowledge Sync',
      description: 'Gather, consolidate, and distribute learnings',
      icon: Brain,
      color: 'from-amber-500 to-orange-500',
      steps: 3
    }
  ];

  const statusColors = {
    pending: 'bg-gray-100 text-gray-600',
    in_progress: 'bg-blue-100 text-blue-700',
    completed: 'bg-green-100 text-green-700',
    failed: 'bg-red-100 text-red-700'
  };

  const statusIcons = {
    pending: Clock,
    in_progress: Loader2,
    completed: CheckCircle,
    failed: AlertCircle
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Network className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Agent Orchestration</h1>
              <p className="text-gray-600">Manage collaborative AI workflows</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="proposals" className="space-y-6">
          <TabsList className="bg-gray-100 p-1 rounded-xl">
            <TabsTrigger value="proposals" className="rounded-lg">Proposals</TabsTrigger>
            <TabsTrigger value="workflows" className="rounded-lg">Workflows</TabsTrigger>
            <TabsTrigger value="messages" className="rounded-lg">Messages</TabsTrigger>
            <TabsTrigger value="knowledge" className="rounded-lg">Shared Knowledge</TabsTrigger>
            <TabsTrigger value="history" className="rounded-lg">History</TabsTrigger>
          </TabsList>

          <TabsContent value="proposals">
            <ImprovementProposals />
          </TabsContent>

          <TabsContent value="workflows">
            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              {workflows.map((workflow) => {
                const Icon = workflow.icon;
                return (
                  <Card 
                    key={workflow.id}
                    className={`p-6 cursor-pointer transition-all hover:shadow-lg ${
                      selectedWorkflow === workflow.id ? 'ring-2 ring-purple-500' : ''
                    }`}
                    onClick={() => setSelectedWorkflow(workflow.id)}
                  >
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${workflow.color} flex items-center justify-center mb-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold text-lg mb-2">{workflow.name}</h3>
                    <p className="text-gray-600 text-sm mb-4">{workflow.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{workflow.steps} steps</span>
                      <ChevronRight className="w-4 h-4 text-gray-400" />
                    </div>
                  </Card>
                );
              })}
            </div>

            {selectedWorkflow && (
              <Card className="p-6 mb-6">
                <h3 className="font-bold text-lg mb-4">Select Target Agent</h3>
                <div className="grid md:grid-cols-4 gap-4 mb-6">
                  {agents.map((agent) => (
                    <div
                      key={agent.id}
                      onClick={() => setSelectedAgent(agent.id)}
                      className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                        selectedAgent === agent.id
                          ? 'border-purple-500 bg-purple-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="font-semibold text-sm">{agent.name}</div>
                      <div className="text-xs text-gray-500 truncate">{agent.description}</div>
                    </div>
                  ))}
                </div>
                <Button
                  onClick={() => runWorkflowMutation.mutate({ 
                    workflowType: selectedWorkflow, 
                    targetAgentId: selectedAgent 
                  })}
                  disabled={!selectedAgent || runWorkflowMutation.isPending}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                >
                  {runWorkflowMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Run Workflow
                    </>
                  )}
                </Button>
              </Card>
            )}

            {collaborations.filter(c => c.status === 'in_progress').length > 0 && (
              <Card className="p-6">
                <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                  Active Workflows
                </h3>
                <div className="space-y-4">
                  {collaborations.filter(c => c.status === 'in_progress').map((collab) => (
                    <div key={collab.id} className="p-4 bg-blue-50 rounded-xl">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-semibold">{collab.workflow_name}</span>
                        <span className="text-xs text-blue-600">In Progress</span>
                      </div>
                      <div className="flex gap-2">
                        {collab.steps?.map((step, i) => {
                          const StepIcon = statusIcons[step.status] || Clock;
                          return (
                            <div
                              key={i}
                              className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs ${statusColors[step.status]}`}
                            >
                              <StepIcon className={`w-3 h-3 ${step.status === 'in_progress' ? 'animate-spin' : ''}`} />
                              {step.action}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="messages">
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-purple-500" />
                Inter-Agent Messages
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                <AnimatePresence>
                  {messages.map((msg, i) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="p-4 bg-gray-50 rounded-xl"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-semibold text-sm">{msg.from_agent}</span>
                        <ArrowRight className="w-3 h-3 text-gray-400" />
                        <span className="font-semibold text-sm">{msg.to_agent}</span>
                        <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                          msg.message_type === 'task_request' ? 'bg-blue-100 text-blue-700' :
                          msg.message_type === 'task_response' ? 'bg-green-100 text-green-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {msg.message_type}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{msg.subject}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(msg.created_date).toLocaleString()}
                      </p>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="knowledge">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <Brain className="w-5 h-5 text-amber-500" />
                Collective Intelligence
              </h3>
              <Button
                onClick={() => syncKnowledgeMutation.mutate()}
                disabled={syncKnowledgeMutation.isPending}
                variant="outline"
              >
                {syncKnowledgeMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Sync Learnings
              </Button>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {sharedKnowledge.map((k) => (
                <Card key={k.id} className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      k.knowledge_type === 'rule' ? 'bg-purple-100 text-purple-700' :
                      k.knowledge_type === 'insight' ? 'bg-blue-100 text-blue-700' :
                      k.knowledge_type === 'pattern' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {k.knowledge_type}
                    </span>
                    <div className="flex items-center gap-1">
                      {k.is_validated && <CheckCircle className="w-3 h-3 text-green-500" />}
                      <span className="text-xs text-gray-500">{k.confidence_score}%</span>
                    </div>
                  </div>
                  <h4 className="font-semibold text-sm mb-1">{k.title}</h4>
                  <p className="text-xs text-gray-600 line-clamp-2">{k.content}</p>
                  <div className="flex items-center justify-between mt-3 text-xs text-gray-400">
                    <span>By: {k.contributed_by}</span>
                    <span>Used {k.times_used}x ({k.success_rate}% success)</span>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4">Workflow History</h3>
              <div className="space-y-4">
                {collaborations.map((collab) => {
                  const StatusIcon = statusIcons[collab.status];
                  return (
                    <div key={collab.id} className="p-4 border rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold">{collab.workflow_name}</span>
                        <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${statusColors[collab.status]}`}>
                          <StatusIcon className={`w-3 h-3 ${collab.status === 'in_progress' ? 'animate-spin' : ''}`} />
                          {collab.status}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 mb-3">
                        Started: {new Date(collab.started_at).toLocaleString()}
                        {collab.completed_at && ` • Completed: ${new Date(collab.completed_at).toLocaleString()}`}
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {collab.steps?.map((step, i) => (
                          <div
                            key={i}
                            className={`text-xs px-2 py-1 rounded ${statusColors[step.status]}`}
                          >
                            {i + 1}. {step.action}
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}