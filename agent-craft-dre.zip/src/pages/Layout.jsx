
import { NavLink } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Sparkles,
  Home,
  Blocks,
  BookOpen,
  Grid3x3,
  MessageSquare,
  User,
  Users,
  Store,
  GraduationCap,
  Lock,
  BarChart3,
  Settings as SettingsIcon,
  Shield,
  Mail,
  Zap,
  GitBranch,
  Eye,
  Key,
} from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/Button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import OnboardingTour from "./components/OnboardingTour";
import FeedbackWidget from "./components/FeedbackWidget";
import { PlanAccessProvider } from "./components/PlanAccessProvider";
import { NavGuard } from "./components/NavGuard";
import Footer from "./components/Footer";

const navigationItems = [
  { title: "Home", url: createPageUrl("Dashboard"), icon: Home, tourId: "home" },

  // Build group
  { 
    title: "Build", 
    icon: Blocks,
    isGroup: true,
    children: [
      { title: "My Helpers", url: createPageUrl("Gallery"), icon: Grid3x3 },
      { title: "Create Helper", url: createPageUrl("GuidedBuilder"), icon: Blocks, tourId: "builder" },
      { title: "Chat", url: createPageUrl("Chat"), icon: MessageSquare, tourId: "chat" },
      { title: "Workflows", url: createPageUrl("WorkflowBuilder"), icon: GitBranch },
      { title: "Action Builder", url: createPageUrl("ActionBuilder"), icon: Zap },
      { title: "Action Marketplace", url: createPageUrl("ActionMarketplace"), icon: Store },
    ]
  },

  // Discover group
  { 
    title: "Discover", 
    icon: Store,
    isGroup: true,
    children: [
      { title: "Marketplace", url: createPageUrl("Marketplace"), icon: Store, tourId: "marketplace" },
      { title: "Learn", url: createPageUrl("Learn"), icon: BookOpen, tourId: "learn" },
      { title: "Tutorials", url: createPageUrl("TutorialCenter"), icon: GraduationCap },
    ]
  },

  // Advanced group
  { 
    title: "Advanced", 
    icon: Sparkles,
    isGroup: true,
    children: [
      { title: "Analytics", url: createPageUrl("CostDashboard"), icon: BarChart3 },
      { title: "Evolution", url: createPageUrl("AgentEvolution"), icon: Sparkles },
      { title: "Collaborations", url: createPageUrl("CollaborationDashboard"), icon: GitBranch },
      { title: "Creator Dashboard", url: createPageUrl("CreatorDashboard"), icon: Zap, tourId: "monetization" },
      { title: "API & Integrations", url: createPageUrl("ApiSettings"), icon: Key },
    ]
  },

  { title: "Settings", url: createPageUrl("Settings"), icon: SettingsIcon },
];

const adminNavigationItems = [
  {
    title: "Admin Dashboard",
    url: createPageUrl("AdminDashboard"),
    icon: Shield,
    adminOnly: true,
  },
];

const globalStyles = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

  :root {
    --primary-bg: #F9FAFB;
    --surface-white: #FFFFFF;
    --accent-blue: #6B7280;
    --accent-muted: #9CA3AF;
    --text-primary: #111827;
    --text-secondary: #6B7280;
    --border-subtle: #E5E7EB;
    --sidebar-background: #FFFFFF;
    --sidebar-foreground: #111827;
  }

  body {
    background: var(--primary-bg);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: var(--text-primary);
    min-height: 100vh;
    line-height: 1.6;
  }

  [data-sidebar="sidebar"] {
    background: var(--sidebar-background) !important;
    border-right: 1px solid var(--border-subtle);
  }

  [data-sidebar="sidebar"] ~ [data-sidebar-overlay] {
    background: rgba(0, 0, 0, 0.2);
  }

  h1, h2, h3, h4, h5, h6 {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
    font-weight: 600;
    letter-spacing: -0.01em;
    color: var(--text-primary);
    line-height: 1.2;
  }

  h1 { font-size: 2.5rem; font-weight: 700; }
  h2 { font-size: 2rem; font-weight: 600; }
  h3 { font-size: 1.5rem; }

  button {
    font-weight: 500;
    font-family: 'Inter', sans-serif;
  }

  .premium-card {
    background: var(--surface-white);
    border: 1px solid var(--border-subtle);
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    transition: all 0.2s ease;
  }

  .premium-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    transform: translateY(-1px);
  }

  input, textarea, select {
    background: var(--surface-white);
    border: 1px solid var(--border-subtle);
    border-radius: 8px;
    font-size: 15px;
    color: var(--text-primary);
    transition: all 0.15s ease;
    padding: 0.5rem 0.75rem;
  }

  input:focus, textarea:focus, select:focus {
    border-color: var(--accent-blue);
    outline: none;
    box-shadow: 0 0 0 3px rgba(107, 114, 128, 0.1);
  }

  input::placeholder, textarea::placeholder {
    color: var(--accent-muted);
  }

  ::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }

  ::-webkit-scrollbar-track {
    background: var(--primary-bg);
  }

  ::-webkit-scrollbar-thumb {
    background: var(--border-subtle);
    border-radius: 4px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: var(--accent-muted);
  }

  * {
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  }

  /* =========================================
     AGENTCRAFT CUSTOM THEME - LANDING PAGE
     ========================================= */

  .app-container {
    min-height: 100vh;
    width: 100%;
    background: linear-gradient(135deg, #f3e7ff 0%, #e0c3fc 100%);
    color: #1f2937;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }

  .landing-nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    position: fixed;
    width: 100%;
    top: 0;
    left: 0;
    z-index: 50;
    box-sizing: border-box;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.5);
  }

  .nav-logo {
    font-weight: 700;
    font-size: 1.2rem;
    color: #4338CA;
  }

  .hero {
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-height: 100vh;
    padding: 80px 10% 0;
    gap: 50px;
  }

  .hero-content {
    flex: 1;
    max-width: 600px;
  }

  .hero-content h1 {
    font-size: 3.5rem;
    line-height: 1.1;
    margin-bottom: 20px;
    font-weight: 800;
    color: #1f2937;
  }

  .hero-content p {
    font-size: 1.25rem;
    line-height: 1.6;
    color: #4b5563;
    margin-bottom: 40px;
  }

  .btn-glossy {
    display: inline-block;
    padding: 16px 32px;
    font-size: 1.1rem;
    font-weight: 600;
    color: white;
    text-decoration: none;
    border-radius: 50px;
    border: 1px solid rgba(255,255,255,0.4);
    background: linear-gradient(135deg, #a18cd1 0%, #fbc2eb 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 10px 20px rgba(161, 140, 209, 0.4);
    transition: all 0.2s ease;
  }

  .btn-glossy:hover {
    transform: translateY(-2px);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), 0 15px 30px rgba(161, 140, 209, 0.6);
  }

  .logo-container {
    width: 300px;
    height: 300px;
    border-radius: 60px;
    padding: 10px;
    background: rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.6);
    box-shadow: 0 20px 50px rgba(0,0,0,0.1);
    animation: float 6s ease-in-out infinite;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-shrink: 0;
  }

  .logo-img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    border-radius: 50px;
  }

  @keyframes float {
    0% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
    100% { transform: translateY(0px); }
  }

  @media (max-width: 768px) {
    .hero { 
      flex-direction: column-reverse; 
      text-align: center; 
      padding-top: 100px;
      justify-content: center;
    }
    .hero-content h1 { font-size: 2.5rem; }
    .logo-container { width: 200px; height: 200px; margin: 0 auto 40px auto; }
    .landing-nav { padding: 15px 20px; }
  }
`;

function SidebarNavItem({ item, onClick }) {
  const [isOpen, setIsOpen] = useState(false);

  if (item.isGroup) {
    return (
      <SidebarMenuItem>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full px-3 py-2 rounded-lg transition-all duration-200 flex items-center justify-between text-gray-600 hover:text-gray-900 hover:bg-gray-50 cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <item.icon className="w-[18px] h-[18px]" />
            <span className="font-normal text-[15px]">{item.title}</span>
          </div>
          <svg
            className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        {isOpen && (
          <div className="ml-6 mt-1 space-y-0.5">
            {item.children.map((child) => (
              <SidebarMenuButton
                key={child.title}
                asChild
                data-tour={child.tourId}
                className="px-3 py-2 rounded-lg transition-all duration-200 border-none"
              >
                <NavLink
                  to={child.url}
                  onClick={onClick}
                  className={({ isActive }) =>
                    [
                      "flex items-center gap-3 w-full cursor-pointer transition-colors duration-200",
                      isActive
                        ? "text-gray-900 bg-gray-100"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-50",
                    ].join(" ")
                  }
                >
                  <child.icon className="w-[16px] h-[16px]" />
                  <span className="font-normal text-[14px]">{child.title}</span>
                </NavLink>
              </SidebarMenuButton>
            ))}
          </div>
        )}
      </SidebarMenuItem>
    );
  }

  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        asChild
        data-tour={item.tourId}
        className="px-3 py-2 rounded-lg transition-all duration-200 border-none"
      >
        <NavLink
          to={item.url}
          onClick={onClick}
          className={({ isActive }) =>
            [
              "flex items-center gap-3 w-full cursor-pointer transition-colors duration-200",
              isActive
                ? "text-gray-900 bg-gray-100"
                : "text-gray-600 hover:text-gray-900 hover:bg-gray-50",
            ].join(" ")
          }
        >
          <item.icon className="w-[18px] h-[18px]" />
          <span className="font-normal text-[15px]">{item.title}</span>
        </NavLink>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

function SidebarContent_({ user, isAdmin }) {
  const { setOpenMobile } = useSidebar();

  const handleNavClick = () => {
    setOpenMobile(false);
  };

  return (
    <>
      <SidebarHeader className="px-6 py-8 border-b border-gray-100" data-tour="sidebar">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gray-900 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-lg tracking-tight text-gray-900">
              AgentCraft
            </h2>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="px-4">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-0.5">
              {navigationItems.map((item) => (
                <SidebarNavItem
                  key={item.title}
                  item={item}
                  onClick={handleNavClick}
                />
              ))}

              {isAdmin && (
                <>
                  <div className="my-4 px-3">
                    <div className="h-px bg-gray-200" />
                  </div>
                  {adminNavigationItems.map((item) => (
                    <SidebarNavItem
                      key={item.title}
                      item={item}
                      onClick={handleNavClick}
                    />
                  ))}
                </>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </>
  );
}

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    let isMounted = true;

    base44.auth
      .me()
      .then((data) => {
        if (isMounted) setUser(data);
      })
      .catch(() => {
        if (isMounted) setUser(null);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const isAdmin = useMemo(() => user?.role === "admin", [user?.role]);

  return (
    <PlanAccessProvider user={user}>
      <NavGuard enabled={true}>
        <SidebarProvider>
          <div className="min-h-screen flex w-full" style={{ background: 'var(--primary-bg)' }}>
            <style>{globalStyles}</style>

            <Sidebar className="border-r border-gray-100 w-56">
              <SidebarContent_ user={user} isAdmin={isAdmin} />
            </Sidebar>

            <main className="flex-1 overflow-auto">
              {/* Desktop Header */}
              <header className="sticky top-0 z-50 px-6 py-3 bg-white/95 backdrop-blur-lg shadow-sm border-b border-gray-100">
                <div className="flex items-center justify-between max-w-7xl mx-auto">
                  <div className="flex items-center gap-4">
                    <div className="md:hidden">
                      <SidebarTrigger className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors duration-200" />
                    </div>
                    <h1 className="text-xl font-bold text-gray-900 tracking-tight md:hidden">
                      AgentCraft
                    </h1>
                  </div>

                  <div className="flex items-center gap-3">
                    {!user ? (
                      <>
                        <Button
                          variant="secondary"
                          onClick={() => base44.auth.redirectToLogin()}
                          className="text-sm"
                        >
                          Log In
                        </Button>
                        <Button
                          variant="primary"
                          onClick={() => base44.auth.redirectToLogin()}
                          className="text-sm"
                        >
                          Get Started
                        </Button>
                      </>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-600 hidden md:inline">{user.full_name || user.email}</span>
                      </div>
                    )}
                  </div>
                </div>
              </header>

              <div className="pb-16">{children}</div>
              <Footer />
              </main>

              {user && <OnboardingTour user={user} />}
              {user && <FeedbackWidget user={user} />}
          </div>
        </SidebarProvider>
      </NavGuard>
    </PlanAccessProvider>
  );
}
