import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { PageShell } from "@/components/ui/PageShell";
import { Textarea } from "@/components/ui/Textarea";
import { Sparkles, Send, Loader2, MessageSquare, Trash2, ArrowLeft, Mail, Zap, Bug, Eye } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import EmailComposer from "../components/EmailComposer";
import ActionExecutionCard from "../components/chat/ActionExecutionCard";
import CertificationBadge from "../components/marketplace/CertificationBadge";
import AgentCollaborationPanel from "../components/chat/AgentCollaborationPanel";

export default function Chat() {
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isExecutingAction, setIsExecutingAction] = useState(false);
  const [user, setUser] = useState(null);
  const [showEmailComposer, setShowEmailComposer] = useState(false);
  const [debugMode, setDebugMode] = useState(false);
  const [currentTraceId, setCurrentTraceId] = useState(null);
  const [activeCollaborations, setActiveCollaborations] = useState([]);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  // Fetch actions assigned to the selected agent
  const { data: agentActions = [] } = useQuery({
    queryKey: ['agentActions', selectedAgent?.assigned_actions],
    queryFn: async () => {
      if (!selectedAgent?.assigned_actions?.length) return [];
      const allActions = await base44.entities.AgentAction.list();
      return allActions.filter(a => selectedAgent.assigned_actions.includes(a.id));
    },
    enabled: !!selectedAgent?.assigned_actions?.length
  });

  // Fetch all user's agents for cross-agent communication
  const { data: allAgents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date', 50),
    enabled: !!user,
    staleTime: 300000,
  });

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  const { data: agents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date', 20),
    initialData: [],
    staleTime: 300000,
    gcTime: 600000,
    enabled: !!user,
    retry: 1,
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async (agentId) => {
      await base44.entities.Agent.update(agentId, {
        chat_history: []
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agents'] });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (selectedAgent?.chat_history?.length) {
      scrollToBottom();
    }
  }, [selectedAgent?.chat_history?.length]);

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedAgent) return;

    const userMessage = {
      role: "user",
      content: message.trim(),
      timestamp: new Date().toISOString()
    };

    const updatedHistory = [...(selectedAgent.chat_history || []), userMessage];
    
    await base44.entities.Agent.update(selectedAgent.id, {
      chat_history: updatedHistory
    });

    const userInput = message.trim();
    setMessage("");
    setIsLoading(true);

    // Create trace for debugging
    const traceId = `trace-${Date.now()}`;
    setCurrentTraceId(traceId);
    const traceSteps = [];
    const traceStartTime = Date.now();

    try {
      // Build system prompt based on agent's abilities and personality
      let systemPrompt = `You are ${selectedAgent.name}, an AI assistant. ${selectedAgent.description}\n\n`;
      
      if (selectedAgent.personality) {
        systemPrompt += `Your personality: ${selectedAgent.personality}\n\n`;
      }

      systemPrompt += "Your capabilities:\n";
      const abilities = selectedAgent.abilities || [];
      if (abilities.includes("memory")) {
        systemPrompt += "- You can remember past conversations and context\n";
      }
      if (abilities.includes("personality")) {
        systemPrompt += "- You have a unique personality and communication style\n";
      }

      // Add action capabilities to prompt
      if (agentActions.length > 0) {
        systemPrompt += "\nYou have access to these actions:\n";
        agentActions.forEach(action => {
          systemPrompt += `- ${action.name}: ${action.description}\n`;
        });
        systemPrompt += "\nIf the user's request matches an action, respond with [ACTION:action_name] at the start of your response, followed by your explanation.\n";
      }

      systemPrompt += "\nRespond naturally and helpfully to the user's message.";

      // Get AI response
      const llmStartTime = Date.now();
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}\n\nUser: ${userInput}\n\nAssistant:`,
        add_context_from_internet: abilities.includes("web_search")
      });
      const llmDuration = Date.now() - llmStartTime;

      // Track usage
      const estimatedTokens = Math.ceil((systemPrompt.length + userInput.length + response.length) / 4);
      await base44.entities.UsageTracking.create({
        user_email: user.email,
        usage_type: "llm_call",
        resource_id: selectedAgent.id,
        resource_name: selectedAgent.name,
        tokens_total: estimatedTokens,
        cost_cents: Math.ceil(estimatedTokens * 0.002),
        duration_ms: llmDuration,
        status: "success"
      }).catch(() => {});

      // Add LLM step to trace
      traceSteps.push({
        step_id: `step-llm-${Date.now()}`,
        step_type: "llm_call",
        step_name: "Generate Response",
        started_at: new Date(llmStartTime).toISOString(),
        completed_at: new Date().toISOString(),
        duration_ms: llmDuration,
        input: { prompt: userInput.slice(0, 200) },
        output: { response: response.slice(0, 500) },
        tokens_used: estimatedTokens,
        status: "completed"
      });

      // Check for agent collaboration requests
      const agentRequestMatch = response.match(/\[REQUEST_AGENT:([^\]]+):([^\]]+)\]/);
      let collaborationResult = null;

      if (agentRequestMatch && allAgents.length > 1) {
        const [_, targetAgentName, requestContent] = agentRequestMatch;
        const targetAgent = allAgents.find(a => 
          a.name.toLowerCase().includes(targetAgentName.toLowerCase()) ||
          targetAgentName.toLowerCase().includes(a.name.toLowerCase())
        );

        if (targetAgent && targetAgent.id !== selectedAgent.id) {
          setActiveCollaborations(prev => [...prev, {
            from_agent: selectedAgent.name,
            to_agent: targetAgent.name,
            content: requestContent,
            status: "processing"
          }]);

          try {
            const collabResponse = await base44.functions.invoke('agentCommunicate', {
              fromAgentId: selectedAgent.id,
              toAgentId: targetAgent.id,
              messageType: "task_request",
              subject: `Request from ${selectedAgent.name}`,
              content: requestContent,
              payload: {
                context: { user_message: userInput },
                executeAction: true
              },
              priority: "high"
            });

            collaborationResult = {
              target_agent: targetAgent.name,
              response: collabResponse.data.response?.content,
              action_executed: collabResponse.data.action_executed
            };

            setActiveCollaborations(prev => 
              prev.map(c => 
                c.to_agent === targetAgent.name && c.status === "processing"
                  ? { ...c, status: "completed" }
                  : c
              )
            );

            // Append collaboration result to response
            cleanResponse = response.replace(/\[REQUEST_AGENT:[^\]]+\]/, '') + 
              `\n\n✓ Received response from ${targetAgent.name}: ${collaborationResult.response}`;

          } catch (error) {
            setActiveCollaborations(prev => 
              prev.map(c => 
                c.to_agent === targetAgent.name && c.status === "processing"
                  ? { ...c, status: "failed" }
                  : c
              )
            );
          }
        }
      }

      // Check if response suggests executing an action
      let actionExecution = null;
      let cleanResponse = collaborationResult ? cleanResponse : response;
      const actionMatch = response.match(/\[ACTION:([^\]]+)\]/);

      if (actionMatch && agentActions.length > 0) {
        const actionName = actionMatch[1].trim().toLowerCase();
        const matchedAction = agentActions.find(a => 
          a.name.toLowerCase().includes(actionName) || 
          actionName.includes(a.name.toLowerCase())
        );

        if (matchedAction) {
          setIsExecutingAction(true);
          cleanResponse = response.replace(/\[ACTION:[^\]]+\]\s*/g, '');

          const actionStartTime = Date.now();
          // Execute the action
          const execResponse = await base44.functions.invoke('executeAction', {
            actionId: matchedAction.id,
            agentId: selectedAgent.id,
            inputData: { userMessage: userInput }
          });
          const actionDuration = Date.now() - actionStartTime;

          actionExecution = {
            action_name: matchedAction.name,
            status: execResponse.data.success ? 'success' : 'failed',
            execution_time_ms: execResponse.data.execution_time_ms,
            output_data: execResponse.data.result,
            error_message: execResponse.data.error
          };

          // Add action step to trace
          traceSteps.push({
            step_id: `step-action-${Date.now()}`,
            step_type: "action",
            step_name: matchedAction.name,
            started_at: new Date(actionStartTime).toISOString(),
            completed_at: new Date().toISOString(),
            duration_ms: actionDuration,
            input: { userMessage: userInput },
            output: execResponse.data.result,
            status: execResponse.data.success ? "completed" : "failed",
            error: execResponse.data.error
          });

          setIsExecutingAction(false);
        }
      }

      const assistantMessage = {
        role: "assistant",
        content: cleanResponse,
        timestamp: new Date().toISOString(),
        action_executed: actionExecution,
        collaboration_result: collaborationResult
      };

      const finalHistory = [...updatedHistory, assistantMessage];
      
      await base44.entities.Agent.update(selectedAgent.id, {
        chat_history: finalHistory
      });

      queryClient.invalidateQueries({ queryKey: ['agents'] });
      
      // Update local state
      setSelectedAgent({
        ...selectedAgent,
        chat_history: finalHistory
      });

      // Save trace if debug mode is on
      if (debugMode) {
        const totalDuration = Date.now() - traceStartTime;
        await base44.entities.AgentTrace.create({
          trace_id: traceId,
          agent_id: selectedAgent.id,
          agent_name: selectedAgent.name,
          user_input: userInput,
          final_output: cleanResponse,
          status: "completed",
          duration_ms: totalDuration,
          steps: traceSteps,
          total_tokens: traceSteps.reduce((sum, s) => sum + (s.tokens_used || 0), 0),
          total_cost_cents: Math.ceil(traceSteps.reduce((sum, s) => sum + (s.tokens_used || 0), 0) * 0.002)
        }).catch(() => {});
      }

    } catch (error) {
      console.error("Error sending message:", error);
      
      // Save failed trace
      if (debugMode) {
        await base44.entities.AgentTrace.create({
          trace_id: traceId,
          agent_id: selectedAgent.id,
          agent_name: selectedAgent.name,
          user_input: userInput,
          status: "failed",
          duration_ms: Date.now() - traceStartTime,
          steps: traceSteps,
          error_message: error.message
        }).catch(() => {});
      }

      alert("Failed to send message. Please try again.");
      setIsExecutingAction(false);
    } finally {
      setIsLoading(false);
      setCurrentTraceId(null);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearHistory = async () => {
    if (!selectedAgent) return;
    if (window.confirm("Are you sure you want to clear this conversation?")) {
      await clearHistoryMutation.mutateAsync(selectedAgent.id);
      setSelectedAgent({
        ...selectedAgent,
        chat_history: []
      });
    }
  };

  const hasEmailAbility = selectedAgent?.abilities?.includes("email_compose");

  if (!selectedAgent) {
    return (
      <PageShell>
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">
              Chat with Your AI Helpers
            </h1>
            <p className="ui-muted">Select an AI Helper to start chatting</p>
          </div>

          {agents.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-24 h-24 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-12 h-12" />
              </div>
              <h2 className="text-2xl font-bold mb-2">No AI Helpers yet</h2>
              <p className="ui-muted mb-6">
                Create your first AI Helper to start chatting!
              </p>
              <Link to={createPageUrl("Builder")}>
                <Button variant="primary">
                  Create AI Helper
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {agents.map((agent) => (
                <Card
                  key={agent.id}
                  onClick={() => setSelectedAgent(agent)}
                  className="p-6 cursor-pointer hover:shadow-xl transition-shadow"
                >
                  <div className="w-14 h-14 rounded-xl bg-gray-100 flex items-center justify-center mb-4">
                    <MessageSquare className="w-7 h-7" />
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-bold text-lg">{agent.name}</h3>
                    <CertificationBadge status={agent.certification_status} size="sm" />
                  </div>
                  <p className="ui-muted text-sm mb-4 line-clamp-2">{agent.description}</p>
                  <div className="flex items-center justify-between text-xs ui-muted">
                    <span>{agent.abilities?.length || 0} superpowers</span>
                    {agent.assigned_actions?.length > 0 && (
                      <span className="flex items-center gap-1">
                        <Zap className="w-3 h-3" />
                        {agent.assigned_actions.length} tasks
                      </span>
                    )}
                    <span>{agent.chat_history?.length || 0} messages</span>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </PageShell>
    );
  }

  const chatHistory = selectedAgent.chat_history || [];

  return (
    <PageShell>
      <div className="max-w-5xl mx-auto w-full flex flex-col flex-1">
        {/* Header */}
        <div className="mb-6">
          <Card className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => setSelectedAgent(null)}
                variant="ghost"
                size="icon"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-bold text-xl">{selectedAgent.name}</h2>
                  <CertificationBadge status={selectedAgent.certification_status} size="sm" />
                </div>
                <p className="text-sm ui-muted">{selectedAgent.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={() => setDebugMode(!debugMode)}
                variant="ghost"
                size="icon"
                className={debugMode ? 'text-green-600' : ''}
                title={debugMode ? "Debug Mode ON" : "Enable Debug Mode"}
              >
                <Bug className="w-5 h-5" />
              </Button>
              {debugMode && (
                <Link to={createPageUrl("TraceDashboard")}>
                  <Button variant="ghost" size="icon" title="View Traces">
                    <Eye className="w-5 h-5" />
                  </Button>
                </Link>
              )}
              {hasEmailAbility && (
                <Button
                  onClick={() => setShowEmailComposer(true)}
                  variant="ghost"
                  size="icon"
                  title="Compose Email"
                >
                  <Mail className="w-5 h-5" />
                </Button>
              )}
              {chatHistory.length > 0 && (
                <Button
                  onClick={handleClearHistory}
                  variant="ghost"
                  size="icon"
                  className="text-red-600"
                >
                  <Trash2 className="w-5 h-5" />
                  </Button>
                  )}
                  </div>
                  </Card>
                  </div>

                  {/* Agent Collaboration Panel */}
                  <AgentCollaborationPanel 
                    activeCollaborations={activeCollaborations}
                    onDismiss={() => setActiveCollaborations([])}
                  />

                  {/* Chat Messages */}
                  <Card className="flex-1 p-6 mb-6 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 350px)', minHeight: '400px' }}>
          {chatHistory.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="w-20 h-20 rounded-xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="w-10 h-10" />
                </div>
                <h3 className="font-bold text-lg mb-2">Start a conversation</h3>
                <p className="ui-muted text-sm">
                  Say hello and start chatting with {selectedAgent.name}!
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <AnimatePresence>
                {chatHistory.map((msg, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className="space-y-2">
                      <div
                        className={`max-w-[80%] p-4 rounded-xl ${
                          msg.role === 'user' 
                            ? 'bg-gray-900 text-white' 
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        <p className={`text-xs mt-2 ${msg.role === 'user' ? 'text-gray-300' : 'text-gray-500'}`}>
                          {new Date(msg.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                      {msg.action_executed && (
                        <div className="ml-4">
                          <ActionExecutionCard execution={msg.action_executed} />
                        </div>
                      )}
                      {msg.collaboration_result && (
                        <div className="ml-4 mt-2">
                          <Card className="p-3 bg-blue-50 border-blue-200">
                            <div className="flex items-center gap-2 mb-1">
                              <Users className="w-4 h-4 text-blue-600" />
                              <span className="text-xs font-medium text-blue-900">
                                Collaborated with {msg.collaboration_result.target_agent}
                              </span>
                            </div>
                            {msg.collaboration_result.action_executed && (
                              <div className="text-xs text-blue-700 mt-1">
                                ✓ Executed: {msg.collaboration_result.action_executed.action_name}
                              </div>
                            )}
                          </Card>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="p-4 rounded-xl bg-gray-100">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">
                        {isExecutingAction ? 'Executing action...' : 'Thinking...'}
                      </span>
                    </div>
                    </div>
                    </motion.div>
                    )}
                    {isExecutingAction && !isLoading && (
                    <ActionExecutionCard isExecuting={true} />
                    )}
                    <div ref={messagesEndRef} />
                    </div>
                    )}
                    </Card>

                    {/* Input Area */}
                    <Card className="p-4">
            <div className="flex gap-3">
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={`Message ${selectedAgent.name}...`}
                className="flex-1 resize-none"
                rows={3}
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || isLoading}
                variant="primary"
                className="self-end"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </Button>
            </div>
            <p className="text-xs ui-muted mt-2">
              Press Enter to send, Shift+Enter for new line
            </p>
        </Card>
      </div>

      {/* Email Composer Modal */}
      <AnimatePresence>
        {showEmailComposer && (
          <EmailComposer
            agent={selectedAgent}
            onClose={() => setShowEmailComposer(false)}
          />
        )}
      </AnimatePresence>
    </PageShell>
  );
}