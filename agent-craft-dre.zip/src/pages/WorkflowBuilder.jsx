import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  GitBranch, Plus, Play, Pause, Trash2, Loader2, 
  CheckCircle, XCircle, Clock, MoreVertical, Eye, Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import WorkflowCanvas from "../components/workflow/WorkflowCanvas";
import WorkflowTemplates from "../components/workflow/WorkflowTemplates";

export default function WorkflowBuilder() {
  const [user, setUser] = useState(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newWorkflowName, setNewWorkflowName] = useState("");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: workflows = [], isLoading } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.Workflow.list('-created_date'),
    enabled: !!user
  });

  const { data: runs = [] } = useQuery({
    queryKey: ['workflowRuns', selectedWorkflow?.id],
    queryFn: () => base44.entities.WorkflowRun.filter({ workflow_id: selectedWorkflow.id }),
    enabled: !!selectedWorkflow?.id,
    refetchInterval: 5000
  });

  const createWorkflowMutation = useMutation({
    mutationFn: (data) => base44.entities.Workflow.create(data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      setSelectedWorkflow(data);
      setIsCreating(false);
      setNewWorkflowName("");
    }
  });

  const updateWorkflowMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Workflow.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
    }
  });

  const deleteWorkflowMutation = useMutation({
    mutationFn: (id) => base44.entities.Workflow.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      setSelectedWorkflow(null);
    }
  });

  const runWorkflowMutation = useMutation({
    mutationFn: async (workflowId) => {
      const workflow = workflows.find(w => w.id === workflowId);
      if (!workflow) return;

      const run = await base44.entities.WorkflowRun.create({
        workflow_id: workflowId,
        workflow_name: workflow.name,
        status: 'running',
        trigger_type: workflow.trigger?.type || 'manual',
        started_at: new Date().toISOString(),
        node_executions: [],
        variables: {}
      });

      // Simulate workflow execution
      setTimeout(async () => {
        await base44.entities.WorkflowRun.update(run.id, {
          status: 'completed',
          completed_at: new Date().toISOString(),
          duration_ms: Math.floor(Math.random() * 5000) + 1000
        });
        
        await base44.entities.Workflow.update(workflowId, {
          run_count: (workflow.run_count || 0) + 1,
          last_run: new Date().toISOString()
        });

        queryClient.invalidateQueries({ queryKey: ['workflowRuns'] });
        queryClient.invalidateQueries({ queryKey: ['workflows'] });
      }, 2000);

      return run;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflowRuns'] });
    }
  });

  const handleCreateWorkflow = () => {
    if (!newWorkflowName.trim()) return;
    createWorkflowMutation.mutate({
      name: newWorkflowName,
      status: 'draft',
      trigger: { type: 'manual', config: {} },
      nodes: []
    });
  };

  const handleSaveWorkflow = (nodes) => {
    if (!selectedWorkflow) return;
    updateWorkflowMutation.mutate({
      id: selectedWorkflow.id,
      data: { nodes }
    });
  };

  const handleToggleStatus = (workflow) => {
    const newStatus = workflow.status === 'active' ? 'paused' : 'active';
    updateWorkflowMutation.mutate({
      id: workflow.id,
      data: { status: newStatus }
    });
  };

  const statusColors = {
    draft: 'bg-gray-100 text-gray-700',
    active: 'bg-green-100 text-green-700',
    paused: 'bg-yellow-100 text-yellow-700',
    archived: 'bg-red-100 text-red-700'
  };

  const runStatusColors = {
    running: 'text-blue-500',
    completed: 'text-green-500',
    failed: 'text-red-500',
    cancelled: 'text-gray-500'
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (selectedWorkflow) {
    return (
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between px-4 md:px-6 py-3 md:py-4 border-b bg-white flex-shrink-0">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => setSelectedWorkflow(null)}>
              ← Back
            </Button>
            <div className="flex items-center gap-3">
              <GitBranch className="w-5 h-5 text-gray-900" />
              <div>
                <h1 className="font-bold text-lg text-gray-900">{selectedWorkflow.name}</h1>
                <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[selectedWorkflow.status]}`}>
                  {selectedWorkflow.status}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => handleToggleStatus(selectedWorkflow)}
            >
              {selectedWorkflow.status === 'active' ? (
                <><Pause className="w-4 h-4 mr-1" /> Pause</>
              ) : (
                <><Play className="w-4 h-4 mr-1" /> Activate</>
              )}
            </Button>
            <Button
              onClick={() => runWorkflowMutation.mutate(selectedWorkflow.id)}
              disabled={runWorkflowMutation.isPending}
              className="bg-gray-900 hover:bg-gray-800 text-white"
            >
              {runWorkflowMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <><Play className="w-4 h-4 mr-1" /> Run Now</>
              )}
            </Button>
          </div>
        </div>

        {/* Canvas */}
        <div className="flex-1 overflow-auto min-h-0">
          <WorkflowCanvas
            nodes={selectedWorkflow.nodes || []}
            onNodesChange={(nodes) => {
              setSelectedWorkflow({ ...selectedWorkflow, nodes });
            }}
            onSave={() => handleSaveWorkflow(selectedWorkflow.nodes)}
            isSaving={updateWorkflowMutation.isPending}
          />
        </div>

        {/* Runs Panel */}
        {runs.length > 0 && (
          <div className="border-t bg-white px-6 py-4 max-h-48 overflow-y-auto">
            <h3 className="font-semibold text-sm mb-2">Recent Runs</h3>
            <div className="space-y-1">
              {runs.slice(0, 5).map(run => (
                <div key={run.id} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    {run.status === 'running' && <Loader2 className="w-3 h-3 animate-spin text-blue-500" />}
                    {run.status === 'completed' && <CheckCircle className="w-3 h-3 text-green-500" />}
                    {run.status === 'failed' && <XCircle className="w-3 h-3 text-red-500" />}
                    <span className={runStatusColors[run.status]}>{run.status}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    {run.duration_ms && `${run.duration_ms}ms • `}
                    {new Date(run.started_at).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
              <GitBranch className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Workflow Builder</h1>
              <p className="text-gray-600">Create visual multi-agent workflows</p>
            </div>
          </div>
          <Button
            onClick={() => setIsCreating(true)}
            className="bg-gray-900 hover:bg-gray-800 text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Workflow
          </Button>
        </div>

        {/* Create Dialog */}
        <AnimatePresence>
          {isCreating && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <Card className="p-4 mb-6 flex items-center gap-3">
                <Input
                  value={newWorkflowName}
                  onChange={(e) => setNewWorkflowName(e.target.value)}
                  placeholder="Workflow name..."
                  className="flex-1"
                  onKeyPress={(e) => e.key === 'Enter' && handleCreateWorkflow()}
                />
                <Button onClick={handleCreateWorkflow} disabled={!newWorkflowName.trim()}>
                  Create
                </Button>
                <Button variant="ghost" onClick={() => setIsCreating(false)}>
                  Cancel
                </Button>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <Tabs defaultValue="my-workflows" className="space-y-6">
          <TabsList className="bg-gray-100 p-1 rounded-xl">
            <TabsTrigger value="my-workflows" className="rounded-lg data-[state=active]:bg-white">
              <GitBranch className="w-4 h-4 mr-2" />
              My Workflows
            </TabsTrigger>
            <TabsTrigger value="templates" className="rounded-lg data-[state=active]:bg-white">
              <Sparkles className="w-4 h-4 mr-2" />
              Templates
            </TabsTrigger>
          </TabsList>

          <TabsContent value="my-workflows">
            {/* Workflows Grid */}
            {isLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
              </div>
            ) : workflows.length === 0 ? (
              <Card className="p-12 text-center">
                <GitBranch className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">No workflows yet</h3>
                <p className="text-gray-600 mb-4">Create your first workflow to automate agent tasks</p>
                <Button onClick={() => setIsCreating(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Workflow
                </Button>
              </Card>
            ) : (
              <div className="grid md:grid-cols-3 gap-6">
                {workflows.map((workflow) => (
                  <Card key={workflow.id} className="p-5 hover:shadow-lg transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center">
                        <GitBranch className="w-5 h-5 text-gray-900" />
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[workflow.status]}`}>
                        {workflow.status}
                      </span>
                    </div>
                    <h3 className="font-semibold mb-1 text-gray-900">{workflow.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {workflow.nodes?.length || 0} nodes • {workflow.run_count || 0} runs
                    </p>
                    {workflow.last_run && (
                      <p className="text-xs text-gray-400 mb-3">
                        Last run: {new Date(workflow.last_run).toLocaleString()}
                      </p>
                    )}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1"
                        onClick={() => setSelectedWorkflow(workflow)}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => runWorkflowMutation.mutate(workflow.id)}
                        disabled={runWorkflowMutation.isPending}
                      >
                        <Play className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteWorkflowMutation.mutate(workflow.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="templates">
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-2">Workflow Templates</h2>
              <p className="text-gray-600">Start with a pre-built template and customize it for your needs</p>
            </div>
            <WorkflowTemplates
              onUseTemplate={(template) => {
                createWorkflowMutation.mutate({
                  name: template.name,
                  description: template.description,
                  status: 'draft',
                  trigger: template.nodes.find(n => n.type === 'trigger')?.data || { type: 'manual', config: {} },
                  nodes: template.nodes
                });
              }}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}