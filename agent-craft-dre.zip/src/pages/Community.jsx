import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Card } from "@/components/ui/Card";
import { Users, MessageSquare, Plus, ThumbsUp, Pin, Search, Filter, TrendingUp, Clock, Star } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/Select";

const CATEGORIES = [
  { value: "all", label: "All Posts", icon: MessageSquare },
  { value: "general", label: "General Discussion", icon: MessageSquare },
  { value: "tips", label: "Tips & Tricks", icon: TrendingUp },
  { value: "showcase", label: "Agent Showcase", icon: Star },
  { value: "help", label: "Help & Support", icon: MessageSquare },
  { value: "collaboration", label: "Collaboration", icon: Users },
];

export default function Community() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [showNewPost, setShowNewPost] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");
  const [newPost, setNewPost] = useState({ title: "", content: "", category: "general" });
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: posts = [] } = useQuery({
    queryKey: ['forumPosts'],
    queryFn: () => base44.entities.ForumPost.list('-created_date', 50), // Limit to 50 posts
    initialData: [],
    staleTime: 30000,
    retry: 1,
  });

  const createPostMutation = useMutation({
    mutationFn: async (postData) => {
      // The original implementation included sanitization, validation, and security wrappers.
      // As per the update request, these steps are removed from within this mutationFn.
      // This means postData is used directly for creation and moderation check.

      const post = await base44.entities.ForumPost.create({
        ...postData,
        author_name: user?.full_name || "Anonymous"
      });

      // Run content moderation check
      const moderationCheck = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a content moderation AI. Analyze this forum post for any inappropriate, harmful, or spam content.

Post Title: ${postData.title}
Post Content: ${postData.content}
Category: ${postData.category}

Score this content from 0-100 where:
- 0-30: Safe, appropriate content
- 31-70: Potentially problematic, needs human review  
- 71-100: Clearly inappropriate, should be blocked

Consider:
1. Inappropriate language, harassment, or hate speech
2. Spam, ads, or off-topic content
3. Misleading or deceptive information
4. Sexual, violent, or harmful content
5. Quality and value to the community

Return ONLY a JSON object with your analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            score: {type: "number"},
            reasons: {
              type: "array",
              items: {type: "string"}
            }
          }
        }
      });

      let status = "approved";
      
      if (moderationCheck.score > 70) {
        status = "blocked";
        await base44.entities.ForumPost.delete(post.id);
        // Removed logSecurityEvent as per the update outline.
      } else if (moderationCheck.score > 30) {
        status = "pending_review";
      }

      await base44.entities.ContentModeration.create({
        content_type: "forum_post",
        content_id: post.id,
        content_preview: `${postData.title}: ${postData.content.substring(0, 100)}`,
        moderation_score: moderationCheck.score,
        status: status,
        auto_decision: true,
        moderation_reasons: moderationCheck.reasons || [],
        author_email: user?.email
      });

      return { post, status, score: moderationCheck.score };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
      
      if (data.status === "blocked") {
        alert("⚠️ Your post was automatically blocked due to policy violations. Please review our community guidelines.");
        setShowNewPost(false);
        setNewPost({ title: "", content: "", category: "general" });
      } else if (data.status === "pending_review") {
        alert("⏳ Your post is under review. It will be visible once approved by our moderation team.");
        setShowNewPost(false);
        setNewPost({ title: "", content: "", category: "general" });
      } else {
        setShowNewPost(false);
        setNewPost({ title: "", content: "", category: "general" });
      }
    },
  });

  const upvotePostMutation = useMutation({
    mutationFn: (post) => base44.entities.ForumPost.update(post.id, {
      upvotes: (post.upvotes || 0) + 1
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forumPosts'] });
    },
  });

  const handleCreatePost = () => {
    if (!newPost.title || !newPost.content) return;
    createPostMutation.mutate(newPost);
  };

  const filteredPosts = posts
    .filter(post => selectedCategory === "all" || post.category === selectedCategory)
    .filter(post => 
      searchQuery === "" || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "recent") return new Date(b.created_date) - new Date(a.created_date);
      if (sortBy === "popular") return (b.upvotes || 0) - (a.upvotes || 0);
      return 0;
    })
    .slice(0, 20); // Show max 20 posts at a time

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-[20px] flex items-center justify-center" style={{
                background: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)',
                boxShadow: '8px 8px 16px rgba(240, 170, 200, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9)'
              }}>
                <Users className="w-7 h-7 text-pink-600" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-purple-800">Community</h1>
                <p className="text-purple-600">Connect, share, and learn together</p>
              </div>
            </div>
            <Button
              onClick={() => setShowNewPost(!showNewPost)}
              className="rounded-[16px] px-6 py-3 font-semibold text-white border-none"
              style={{
                background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                boxShadow: '6px 6px 12px rgba(180, 150, 220, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8)'
              }}
            >
              <Plus className="w-5 h-5 mr-2" />
              New Post
            </Button>
          </div>

          {/* Search and Filters */}
          <Card className="p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-purple-400" />
                  <Input
                    placeholder="Search posts..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 border-none text-base"
                    style={{
                      background: 'rgba(255, 255, 255, 0.5)',
                      boxShadow: 'inset 3px 3px 6px rgba(209, 196, 233, 0.2)'
                    }}
                  />
                </div>
              </div>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-48 h-12 text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent" className="text-base py-3 cursor-pointer">
                    <Clock className="w-5 h-5 inline mr-2" />
                    Recent
                  </SelectItem>
                  <SelectItem value="popular" className="text-base py-3 cursor-pointer">
                    <TrendingUp className="w-5 h-5 inline mr-2" />
                    Popular
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Card>

          {/* Categories */}
          <div className="flex gap-3 overflow-x-auto pb-2">
            {CATEGORIES.map(cat => (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap flex items-center gap-2 transition-all ${
                  selectedCategory === cat.value ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <cat.icon className="w-4 h-4" />
                {cat.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* New Post Form */}
        <AnimatePresence>
          {showNewPost && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6"
            >
              <Card className="p-6">
                <h3 className="text-xl font-bold text-purple-800 mb-4">Create New Post</h3>
                <div className="space-y-4">
                  <Input
                    placeholder="Post title..."
                    value={newPost.title}
                    onChange={(e) => setNewPost({...newPost, title: e.target.value})}
                    className="text-lg"
                  />
                  <Textarea
                    placeholder="What's on your mind?"
                    value={newPost.content}
                    onChange={(e) => setNewPost({...newPost, content: e.target.value})}
                    rows={4}
                  />
                  <Select value={newPost.category} onValueChange={(v) => setNewPost({...newPost, category: v})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.filter(c => c.value !== 'all').map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>
                          {cat.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex gap-3 justify-end">
                    <Button
                      onClick={() => setShowNewPost(false)}
                      variant="outline"
                      className="flex-1 h-12 text-base"
                    >
                      Cancel
                    </Button>
                    <Button
                      onClick={handleCreatePost}
                      disabled={createPostMutation.isPending || !newPost.title || !newPost.content}
                      className="flex-1 h-12 text-base"
                    >
                      {createPostMutation.isPending ? 'Posting...' : 'Post'}
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Posts List */}
        <div className="space-y-4">
          {filteredPosts.length === 0 ? (
            <Card className="p-12 text-center">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-purple-400" />
              <h3 className="text-xl font-bold text-purple-800 mb-2">No posts yet</h3>
              <p className="text-purple-600">Be the first to start a conversation!</p>
            </Card>
          ) : (
            filteredPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="ui-card p-6 hover:shadow-lg transition-all cursor-pointer"
              >
                {post.is_pinned && (
                  <div className="flex items-center gap-2 text-amber-600 mb-2">
                    <Pin className="w-4 h-4" />
                    <span className="text-sm font-semibold">Pinned Post</span>
                  </div>
                )}
                <h3 className="text-xl font-bold text-purple-800 mb-2">{post.title}</h3>
                <p className="text-purple-700 mb-4 line-clamp-2">{post.content}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-purple-600">
                    <span className="font-medium">{post.author_name}</span>
                    <span className="px-3 py-1 rounded-full text-xs" style={{
                      background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                      boxShadow: 'inset 2px 2px 4px rgba(209, 196, 233, 0.2)'
                    }}>
                      {CATEGORIES.find(c => c.value === post.category)?.label}
                    </span>
                    <span>{new Date(post.created_date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        upvotePostMutation.mutate(post);
                      }}
                      className="flex items-center gap-2 px-3 py-1 rounded-lg bg-white border border-gray-200 hover:bg-gray-50 transition-colors"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span>{post.upvotes || 0}</span>
                    </button>
                    <div className="flex items-center gap-2 text-purple-600">
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.comment_count || 0}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}