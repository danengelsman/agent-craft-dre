import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { PageShell } from "@/components/ui/PageShell";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Shield, 
  AlertTriangle, 
  Users, 
  FileText, 
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  Loader2
} from "lucide-react";

export default function AdminDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  // Fetch moderation queue
  const { data: moderationQueue = [] } = useQuery({
    queryKey: ['moderationQueue'],
    queryFn: () => base44.entities.ContentModeration.filter({ status: "pending_review" }),
    enabled: !!user && user.role === 'admin',
  });

  // Fetch security alerts
  const { data: securityAlerts = [] } = useQuery({
    queryKey: ['securityAlerts'],
    queryFn: () => base44.entities.SecurityAlert.filter({ status: "active" }, '-created_date', 10),
    enabled: !!user && user.role === 'admin',
  });

  // Fetch all users count
  const { data: allUsers = [] } = useQuery({
    queryKey: ['allUsers'],
    queryFn: () => base44.entities.User.list(),
    enabled: !!user && user.role === 'admin',
  });

  // Fetch content moderation stats
  const { data: allModeration = [] } = useQuery({
    queryKey: ['allModeration'],
    queryFn: () => base44.entities.ContentModeration.list('-created_date', 100),
    enabled: !!user && user.role === 'admin',
  });

  if (!user || user.role !== 'admin') {
    return (
      <PageShell>
        <div className="text-center py-20">
          <Shield className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This page is only accessible to administrators</p>
        </div>
      </PageShell>
    );
  }

  const pendingModeration = moderationQueue.length;
  const activeAlerts = securityAlerts.length;
  const totalUsers = allUsers.length;
  const approvedContent = allModeration.filter(m => m.status === 'approved').length;
  const blockedContent = allModeration.filter(m => m.status === 'blocked').length;
  const approvalRate = allModeration.length > 0 
    ? ((approvedContent / allModeration.length) * 100).toFixed(1) 
    : 0;

  return (
    <PageShell>
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gray-900 rounded-xl flex items-center justify-center">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Admin Dashboard</h1>
              <p className="ui-muted">Platform overview and management</p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{pendingModeration}</p>
                <p className="text-sm text-gray-500">Pending Review</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeAlerts}</p>
                <p className="text-sm text-gray-500">Active Alerts</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalUsers}</p>
                <p className="text-sm text-gray-500">Total Users</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{approvalRate}%</p>
                <p className="text-sm text-gray-500">Approval Rate</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Sections */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Moderation Queue */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Content Moderation Queue
              </CardTitle>
            </CardHeader>
            <CardContent>
              {moderationQueue.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-600" />
                  <p className="text-sm text-gray-600">All caught up! No pending reviews.</p>
                </div>
              ) : (
                <div className="space-y-3 mb-4">
                  {moderationQueue.slice(0, 5).map((item) => (
                    <div key={item.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-start justify-between mb-1">
                        <span className="text-xs font-semibold text-gray-700">
                          {item.content_type.toUpperCase()}
                        </span>
                        <span className="text-xs text-gray-500">
                          Score: {item.moderation_score}
                        </span>
                      </div>
                      <p className="text-sm text-gray-900 line-clamp-2 mb-2">
                        {item.content_preview}
                      </p>
                      <p className="text-xs text-gray-500">
                        By: {item.author_email}
                      </p>
                    </div>
                  ))}
                </div>
              )}
              <Link to={createPageUrl("AdminModeration")}>
                <Button variant="outline" className="w-full">
                  View All ({moderationQueue.length})
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Security Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Security Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {securityAlerts.length === 0 ? (
                <div className="text-center py-8">
                  <Shield className="w-12 h-12 mx-auto mb-3 text-green-600" />
                  <p className="text-sm text-gray-600">No active security alerts.</p>
                </div>
              ) : (
                <div className="space-y-3 mb-4">
                  {securityAlerts.slice(0, 5).map((alert) => (
                    <div key={alert.id} className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div className="flex items-start justify-between mb-1">
                        <span className="text-xs font-semibold text-red-700">
                          {alert.alert_type?.toUpperCase()}
                        </span>
                        <span className="text-xs text-red-600">
                          {alert.severity}
                        </span>
                      </div>
                      <p className="text-sm text-gray-900 line-clamp-2 mb-2">
                        {alert.description}
                      </p>
                      <p className="text-xs text-gray-500">
                        User: {alert.user_email || 'Unknown'}
                      </p>
                    </div>
                  ))}
                </div>
              )}
              <Link to={createPageUrl("SecurityDashboard")}>
                <Button variant="outline" className="w-full">
                  View All ({securityAlerts.length})
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Content Stats */}
        <Card>
          <CardHeader>
            <CardTitle>Content Moderation Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <FileText className="w-8 h-8 mx-auto mb-2 text-gray-600" />
                <p className="text-2xl font-bold mb-1">{allModeration.length}</p>
                <p className="text-sm text-gray-600">Total Reviewed</p>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <p className="text-2xl font-bold mb-1">{approvedContent}</p>
                <p className="text-sm text-gray-600">Approved</p>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <XCircle className="w-8 h-8 mx-auto mb-2 text-red-600" />
                <p className="text-2xl font-bold mb-1">{blockedContent}</p>
                <p className="text-sm text-gray-600">Blocked</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}