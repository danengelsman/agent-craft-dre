import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  DollarSign, TrendingUp, Zap, Bot, GitBranch, AlertTriangle,
  Calendar, Clock, BarChart3, PieChart, Settings, Loader2
} from "lucide-react";
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, Legend 
} from "recharts";

const COLORS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];

const USAGE_TYPE_LABELS = {
  llm_call: "AI Conversations",
  action_execution: "Action Executions",
  workflow_run: "Workflow Runs",
  image_generation: "Image Generation",
  file_upload: "File Uploads"
};

const USAGE_TYPE_ICONS = {
  llm_call: Bot,
  action_execution: Zap,
  workflow_run: GitBranch,
  image_generation: "🖼️",
  file_upload: "📁"
};

export default function CostDashboard() {
  const [user, setUser] = useState(null);
  const [dateRange, setDateRange] = useState("30d");
  const [showBudgetSettings, setShowBudgetSettings] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const getDateFilter = () => {
    const now = new Date();
    switch (dateRange) {
      case "7d":
        return new Date(now.setDate(now.getDate() - 7)).toISOString();
      case "30d":
        return new Date(now.setDate(now.getDate() - 30)).toISOString();
      case "90d":
        return new Date(now.setDate(now.getDate() - 90)).toISOString();
      default:
        return new Date(now.setDate(now.getDate() - 30)).toISOString();
    }
  };

  const { data: usage = [], isLoading } = useQuery({
    queryKey: ['usageTracking', user?.email, dateRange],
    queryFn: () => base44.entities.UsageTracking.filter(
      { user_email: user?.email },
      '-created_date',
      1000
    ),
    enabled: !!user?.email,
    staleTime: 60000,
  });

  const { data: budgetLimits = [] } = useQuery({
    queryKey: ['budgetLimits', user?.email],
    queryFn: () => base44.entities.BudgetLimit.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    staleTime: 300000,
  });

  const budgetLimit = budgetLimits[0];

  const saveBudgetMutation = useMutation({
    mutationFn: async (data) => {
      if (budgetLimit) {
        return base44.entities.BudgetLimit.update(budgetLimit.id, data);
      } else {
        return base44.entities.BudgetLimit.create({ ...data, user_email: user.email });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['budgetLimits'] });
      setShowBudgetSettings(false);
    }
  });

  // Calculate stats
  const stats = useMemo(() => {
    const totalCost = usage.reduce((sum, u) => sum + (u.cost_cents || 0), 0);
    const totalTokens = usage.reduce((sum, u) => sum + (u.tokens_total || 0), 0);
    const totalCalls = usage.length;
    const successRate = usage.length > 0 
      ? (usage.filter(u => u.status === 'success').length / usage.length * 100) 
      : 100;

    // This month's cost
    const thisMonth = new Date();
    thisMonth.setDate(1);
    const monthlyUsage = usage.filter(u => new Date(u.created_date) >= thisMonth);
    const monthlyCost = monthlyUsage.reduce((sum, u) => sum + (u.cost_cents || 0), 0);

    // Today's cost
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dailyUsage = usage.filter(u => new Date(u.created_date) >= today);
    const dailyCost = dailyUsage.reduce((sum, u) => sum + (u.cost_cents || 0), 0);

    return { totalCost, totalTokens, totalCalls, successRate, monthlyCost, dailyCost };
  }, [usage]);

  // Cost by type
  const costByType = useMemo(() => {
    const grouped = {};
    usage.forEach(u => {
      if (!grouped[u.usage_type]) {
        grouped[u.usage_type] = { type: u.usage_type, cost: 0, count: 0 };
      }
      grouped[u.usage_type].cost += u.cost_cents || 0;
      grouped[u.usage_type].count += 1;
    });
    return Object.values(grouped).map(g => ({
      name: USAGE_TYPE_LABELS[g.type] || g.type,
      value: g.cost / 100,
      count: g.count
    }));
  }, [usage]);

  // Daily cost trend
  const dailyTrend = useMemo(() => {
    const days = {};
    const now = new Date();
    const daysToShow = dateRange === "7d" ? 7 : dateRange === "30d" ? 30 : 90;
    
    for (let i = daysToShow - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const key = date.toISOString().split('T')[0];
      days[key] = { date: key, cost: 0, calls: 0 };
    }

    usage.forEach(u => {
      const key = u.created_date?.split('T')[0];
      if (days[key]) {
        days[key].cost += (u.cost_cents || 0) / 100;
        days[key].calls += 1;
      }
    });

    return Object.values(days).map(d => ({
      ...d,
      date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    }));
  }, [usage, dateRange]);

  // Budget progress
  const budgetProgress = useMemo(() => {
    if (!budgetLimit) return null;
    
    const monthlyPercent = budgetLimit.monthly_budget_cents > 0 
      ? (stats.monthlyCost / budgetLimit.monthly_budget_cents) * 100 
      : 0;
    const dailyPercent = budgetLimit.daily_budget_cents > 0 
      ? (stats.dailyCost / budgetLimit.daily_budget_cents) * 100 
      : 0;

    return {
      monthly: {
        used: stats.monthlyCost,
        limit: budgetLimit.monthly_budget_cents,
        percent: Math.min(monthlyPercent, 100),
        exceeded: monthlyPercent > 100
      },
      daily: {
        used: stats.dailyCost,
        limit: budgetLimit.daily_budget_cents,
        percent: Math.min(dailyPercent, 100),
        exceeded: dailyPercent > 100
      }
    };
  }, [budgetLimit, stats]);

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Cost Dashboard</h1>
              <p className="text-gray-600">Monitor usage and manage budgets</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="ui-control"
            >
              <option value="7d">Last 7 days</option>
              <option value="30d">Last 30 days</option>
              <option value="90d">Last 90 days</option>
            </select>
            <Button
              variant="outline"
              onClick={() => setShowBudgetSettings(!showBudgetSettings)}
            >
              <Settings className="w-4 h-4 mr-2" />
              Budget Settings
            </Button>
          </div>
        </div>

        {/* Budget Alert */}
        {budgetProgress && (budgetProgress.monthly.exceeded || budgetProgress.daily.exceeded) && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <div>
              <span className="font-semibold text-red-800">Budget Exceeded! </span>
              <span className="text-red-700">
                {budgetProgress.monthly.exceeded && "Monthly limit reached. "}
                {budgetProgress.daily.exceeded && "Daily limit reached."}
              </span>
            </div>
          </div>
        )}

        {/* Budget Settings Panel */}
        {showBudgetSettings && (
          <div className="mb-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Budget Settings
              </h3>
              <BudgetSettingsForm 
                budgetLimit={budgetLimit}
                onSave={(data) => saveBudgetMutation.mutate(data)}
                isSaving={saveBudgetMutation.isPending}
              />
            </Card>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard
            icon={DollarSign}
            label="Total Spent"
            value={`$${(stats.totalCost / 100).toFixed(2)}`}
            sublabel={`${dateRange === "7d" ? "7 days" : dateRange === "30d" ? "30 days" : "90 days"}`}
            color="emerald"
          />
          <StatCard
            icon={Zap}
            label="API Calls"
            value={stats.totalCalls.toLocaleString()}
            sublabel={`${stats.successRate.toFixed(1)}% success`}
            color="blue"
          />
          <StatCard
            icon={BarChart3}
            label="Tokens Used"
            value={stats.totalTokens.toLocaleString()}
            sublabel="Total tokens"
            color="purple"
          />
          <StatCard
            icon={Calendar}
            label="Today"
            value={`$${(stats.dailyCost / 100).toFixed(2)}`}
            sublabel={budgetLimit?.daily_budget_cents ? `of $${(budgetLimit.daily_budget_cents / 100).toFixed(2)} limit` : "No limit set"}
            color="amber"
          />
        </div>

        {/* Budget Progress */}
        {budgetProgress && (budgetLimit?.monthly_budget_cents > 0 || budgetLimit?.daily_budget_cents > 0) && (
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {budgetLimit?.monthly_budget_cents > 0 && (
              <Card className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Monthly Budget</span>
                  <span className="text-sm text-gray-500">
                    ${(budgetProgress.monthly.used / 100).toFixed(2)} / ${(budgetProgress.monthly.limit / 100).toFixed(2)}
                  </span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      budgetProgress.monthly.exceeded ? 'bg-red-500' : 
                      budgetProgress.monthly.percent > 80 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${budgetProgress.monthly.percent}%` }}
                  />
                </div>
              </Card>
            )}
            {budgetLimit?.daily_budget_cents > 0 && (
              <Card className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Daily Budget</span>
                  <span className="text-sm text-gray-500">
                    ${(budgetProgress.daily.used / 100).toFixed(2)} / ${(budgetProgress.daily.limit / 100).toFixed(2)}
                  </span>
                </div>
                <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all ${
                      budgetProgress.daily.exceeded ? 'bg-red-500' : 
                      budgetProgress.daily.percent > 80 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${budgetProgress.daily.percent}%` }}
                  />
                </div>
              </Card>
            )}
          </div>
        )}

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Cost Trend */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
              Cost Trend
            </h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={dailyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tickFormatter={(v) => `$${v}`} tick={{ fontSize: 11 }} />
                <Tooltip 
                  formatter={(value) => [`$${value.toFixed(2)}`, 'Cost']}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #e5e7eb' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="cost" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Cost by Type */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <PieChart className="w-5 h-5 text-purple-600" />
              Cost by Type
            </h3>
            {costByType.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <RechartsPie>
                  <Pie
                    data={costByType}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {costByType.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `$${value.toFixed(2)}`} />
                  <Legend />
                </RechartsPie>
              </ResponsiveContainer>
            ) : (
              <div className="h-[250px] flex items-center justify-center text-gray-500">
                No usage data yet
              </div>
            )}
          </Card>
        </div>

        {/* Recent Usage */}
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Recent Usage</h3>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            </div>
          ) : usage.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No usage recorded yet. Start using agents to see data here.
            </div>
          ) : (
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {usage.slice(0, 50).map((u, i) => (
                <div key={u.id || i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      u.usage_type === 'llm_call' ? 'bg-purple-100' :
                      u.usage_type === 'action_execution' ? 'bg-amber-100' :
                      u.usage_type === 'workflow_run' ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      {u.usage_type === 'llm_call' && <Bot className="w-4 h-4 text-purple-600" />}
                      {u.usage_type === 'action_execution' && <Zap className="w-4 h-4 text-amber-600" />}
                      {u.usage_type === 'workflow_run' && <GitBranch className="w-4 h-4 text-blue-600" />}
                    </div>
                    <div>
                      <div className="font-medium text-sm">{u.resource_name || USAGE_TYPE_LABELS[u.usage_type]}</div>
                      <div className="text-xs text-gray-500">
                        {u.tokens_total > 0 && `${u.tokens_total.toLocaleString()} tokens • `}
                        {u.duration_ms > 0 && `${u.duration_ms}ms • `}
                        {new Date(u.created_date).toLocaleString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">${((u.cost_cents || 0) / 100).toFixed(4)}</div>
                    <div className={`text-xs ${u.status === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                      {u.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sublabel, color }) {
  const colors = {
    emerald: "from-emerald-500 to-teal-600",
    blue: "from-blue-500 to-indigo-600",
    purple: "from-purple-500 to-pink-600",
    amber: "from-amber-500 to-orange-600"
  };

  return (
    <Card className="p-5">
      <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center mb-3">
        <Icon className="w-5 h-5 text-gray-900" />
      </div>
      <div className="text-2xl font-bold text-gray-900">{value}</div>
      <div className="text-sm text-gray-600">{label}</div>
      <div className="text-xs text-gray-500 mt-1">{sublabel}</div>
    </Card>
  );
}

function BudgetSettingsForm({ budgetLimit, onSave, isSaving }) {
  const [monthlyBudget, setMonthlyBudget] = useState(budgetLimit?.monthly_budget_cents / 100 || 0);
  const [dailyBudget, setDailyBudget] = useState(budgetLimit?.daily_budget_cents / 100 || 0);
  const [alertThreshold, setAlertThreshold] = useState(budgetLimit?.alert_threshold_percent || 80);
  const [hardLimit, setHardLimit] = useState(budgetLimit?.hard_limit || false);

  const handleSave = () => {
    onSave({
      monthly_budget_cents: Math.round(monthlyBudget * 100),
      daily_budget_cents: Math.round(dailyBudget * 100),
      alert_threshold_percent: alertThreshold,
      hard_limit: hardLimit,
      is_active: true
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label>Monthly Budget ($)</Label>
          <Input
            type="number"
            value={monthlyBudget}
            onChange={(e) => setMonthlyBudget(parseFloat(e.target.value) || 0)}
            placeholder="0 = unlimited"
            className="mt-1"
          />
        </div>
        <div>
          <Label>Daily Budget ($)</Label>
          <Input
            type="number"
            value={dailyBudget}
            onChange={(e) => setDailyBudget(parseFloat(e.target.value) || 0)}
            placeholder="0 = unlimited"
            className="mt-1"
          />
        </div>
      </div>
      <div>
        <Label>Alert Threshold (%)</Label>
        <Input
          type="number"
          value={alertThreshold}
          onChange={(e) => setAlertThreshold(parseInt(e.target.value) || 80)}
          min={0}
          max={100}
          className="mt-1 w-32"
        />
        <p className="text-xs text-gray-500 mt-1">Get notified when usage reaches this percentage</p>
      </div>
      <div className="flex items-center gap-3">
        <Switch checked={hardLimit} onCheckedChange={setHardLimit} />
        <div>
          <Label>Hard Limit</Label>
          <p className="text-xs text-gray-500">Block usage when budget is exceeded</p>
        </div>
      </div>
      <Button onClick={handleSave} disabled={isSaving}>
        {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
        Save Budget Settings
      </Button>
    </div>
  );
}