import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Textarea";
import { 
  Shield, 
  AlertTriangle, 
  Activity, 
  TrendingUp, 
  Users, 
  Ban,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  AlertCircle
} from "lucide-react";
import { motion } from "framer-motion";

export default function SecurityDashboard() {
  const [user, setUser] = useState(null);
  const [selectedTab, setSelectedTab] = useState("alerts");
  const [resolvingAlert, setResolvingAlert] = useState(null);
  const [resolutionNotes, setResolutionNotes] = useState("");
  const [timeRange, setTimeRange] = useState("24h");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  // Fetch security logs
  const { data: securityLogs = [] } = useQuery({
    queryKey: ['securityLogs', timeRange],
    queryFn: async () => {
      const logs = await base44.entities.SecurityLog.list('-created_date', 100);
      const cutoff = Date.now() - getTimeRangeMs(timeRange);
      return logs.filter(log => new Date(log.created_date).getTime() > cutoff);
    },
    initialData: [],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch security alerts
  const { data: securityAlerts = [] } = useQuery({
    queryKey: ['securityAlerts'],
    queryFn: () => base44.entities.SecurityAlert.list('-created_date', 50),
    initialData: [],
    refetchInterval: 30000,
  });

  const resolveAlertMutation = useMutation({
    mutationFn: async ({ alertId, status }) => {
      await base44.entities.SecurityAlert.update(alertId, {
        status: status,
        resolved_by: user.email,
        resolved_at: new Date().toISOString(),
        resolution_notes: resolutionNotes
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['securityAlerts'] });
      setResolvingAlert(null);
      setResolutionNotes("");
    },
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="bg-app min-h-screen flex items-center justify-center p-6">
        <Card className="p-12 text-center max-w-md">
          <Ban className="w-16 h-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold text-purple-800 mb-2">Access Denied</h2>
          <p className="text-purple-600">Security dashboard is admin-only.</p>
        </Card>
      </div>
    );
  }

  const activeAlerts = securityAlerts.filter(a => a.status === "active");
  const criticalAlerts = activeAlerts.filter(a => a.severity === "critical");
  const highAlerts = activeAlerts.filter(a => a.severity === "high");

  const recentLogs = securityLogs.slice(0, 20);
  const criticalLogs = securityLogs.filter(l => l.severity === "critical");
  const blockedEvents = securityLogs.filter(l => l.blocked);

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-[20px] flex items-center justify-center" style={{
              background: 'linear-gradient(145deg, #3b82f6, #2563eb)',
              boxShadow: '8px 8px 16px rgba(59, 130, 246, 0.3), -8px -8px 16px rgba(147, 197, 253, 0.8)'
            }}>
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-purple-800">Security Dashboard</h1>
              <p className="text-purple-600">Real-time Application Self-Protection (RASP)</p>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <span className="text-sm text-purple-600">Critical Alerts</span>
              </div>
              <div className="text-3xl font-bold text-purple-800">{criticalAlerts.length}</div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <span className="text-sm text-purple-600">High Priority</span>
              </div>
              <div className="text-3xl font-bold text-purple-800">{highAlerts.length}</div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Ban className="w-5 h-5 text-red-600" />
                <span className="text-sm text-purple-600">Blocked Events</span>
              </div>
              <div className="text-3xl font-bold text-purple-800">{blockedEvents.length}</div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <span className="text-sm text-purple-600">Total Events</span>
              </div>
              <div className="text-3xl font-bold text-purple-800">{securityLogs.length}</div>
            </Card>
          </div>

          {/* Time Range Filter & Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedTab("alerts")}
                className={`px-4 py-2 rounded-xl transition-all ${selectedTab === "alerts" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
              >
                Active Alerts ({activeAlerts.length})
              </button>
              <button
                onClick={() => setSelectedTab("logs")}
                className={`px-4 py-2 rounded-xl transition-all ${selectedTab === "logs" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
              >
                Security Logs
              </button>
              <button
                onClick={() => setSelectedTab("stats")}
                className={`px-4 py-2 rounded-xl transition-all ${selectedTab === "stats" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}
              >
                Statistics
              </button>
            </div>

            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
              className="ui-control"
            >
              <option value="1h">Last Hour</option>
              <option value="24h">Last 24 Hours</option>
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
            </select>
          </div>
        </motion.div>

        {/* Content */}
        <div className="space-y-4">
          {/* Alerts Tab */}
          {selectedTab === "alerts" && (
            <>
              {activeAlerts.length === 0 ? (
                <Card className="p-12 text-center">
                  <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
                  <h3 className="text-xl font-bold text-purple-800 mb-2">All Clear!</h3>
                  <p className="text-purple-600">No active security alerts</p>
                </Card>
              ) : (
                activeAlerts.map((alert, index) => {
                  const severityColors = {
                    critical: { bg: '#ff8a8a', text: '#991b1b' },
                    high: { bg: '#ffb8a8', text: '#dc2626' },
                    medium: { bg: '#ffd9a8', text: '#c2410c' },
                    low: { bg: '#ffd9e8', text: '#be185d' }
                  };
                  const color = severityColors[alert.severity];

                  return (
                    <motion.div
                      key={alert.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="ui-card p-6"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: color.bg,
                              color: color.text
                            }}>
                              {alert.severity.toUpperCase()}
                            </span>
                            <span className="px-3 py-1 rounded-[10px] text-xs font-bold" style={{
                              background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                              color: '#6b21a8'
                            }}>
                              {alert.alert_type.replace('_', ' ').toUpperCase()}
                            </span>
                            {alert.affected_count > 1 && (
                              <span className="text-xs text-purple-600 font-medium">
                                {alert.affected_count} incidents
                              </span>
                            )}
                          </div>
                          <h3 className="text-lg font-bold text-purple-800 mb-2">{alert.title}</h3>
                          <p className="text-purple-700 mb-2 whitespace-pre-wrap">{alert.description}</p>
                          <div className="text-xs text-purple-500">
                            {alert.user_email && `User: ${alert.user_email} • `}
                            Created: {new Date(alert.created_date).toLocaleString()}
                          </div>
                        </div>
                      </div>

                      {resolvingAlert === alert.id ? (
                        <div className="mt-4 p-4 rounded-[14px]" style={{
                          background: 'linear-gradient(145deg, #f5f3ff, #e8e6f7)',
                          boxShadow: 'inset 2px 2px 4px rgba(209, 196, 233, 0.2)'
                        }}>
                          <Textarea
                            placeholder="Resolution notes..."
                            value={resolutionNotes}
                            onChange={(e) => setResolutionNotes(e.target.value)}
                            className="mb-3"
                            rows={2}
                          />
                          <div className="flex gap-2">
                            <Button
                              onClick={() => resolveAlertMutation.mutate({ alertId: alert.id, status: "resolved" })}
                              className="flex-1"
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Mark Resolved
                            </Button>
                            <Button
                              onClick={() => resolveAlertMutation.mutate({ alertId: alert.id, status: "false_positive" })}
                              className="flex-1"
                              variant="secondary"
                            >
                              False Positive
                            </Button>
                            <Button
                              onClick={() => {
                                setResolvingAlert(null);
                                setResolutionNotes("");
                              }}
                              variant="outline"
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex gap-2">
                          <Button
                            onClick={() => setResolvingAlert(alert.id)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Review & Resolve
                          </Button>
                        </div>
                      )}
                    </motion.div>
                  );
                })
              )}
            </>
          )}

          {/* Logs Tab */}
          {selectedTab === "logs" && (
            <>
              {recentLogs.map((log, index) => {
                const severityColors = {
                  critical: 'text-red-700 bg-red-100',
                  high: 'text-orange-700 bg-orange-100',
                  medium: 'text-amber-700 bg-amber-100',
                  low: 'text-blue-700 bg-blue-100'
                };

                return (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.02 }}
                    className="ui-card p-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`px-2 py-1 rounded-[8px] text-xs font-bold ${severityColors[log.severity]}`}>
                            {log.severity}
                          </span>
                          <span className="text-sm font-medium text-purple-800">
                            {log.event_type.replace(/_/g, ' ').toUpperCase()}
                          </span>
                          {log.blocked && (
                            <Ban className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                        <p className="text-sm text-purple-700 mb-1">{log.details}</p>
                        <div className="text-xs text-purple-500">
                          User: {log.user_email} • 
                          Endpoint: {log.endpoint} • 
                          {new Date(log.created_date).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </>
          )}

          {/* Statistics Tab */}
          {selectedTab === "stats" && (
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-bold text-purple-800 mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Event Types
                </h3>
                <div className="space-y-3">
                  {getEventTypeStats(securityLogs).map(({ type, count }) => (
                    <div key={type} className="flex items-center justify-between">
                      <span className="text-sm text-purple-700">{type.replace(/_/g, ' ')}</span>
                      <span className="font-bold text-purple-800">{count}</span>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-bold text-purple-800 mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-600" />
                  Top Affected Users
                </h3>
                <div className="space-y-3">
                  {getTopUsers(securityLogs).map(({ email, count }) => (
                    <div key={email} className="flex items-center justify-between">
                      <span className="text-sm text-purple-700 truncate">{email}</span>
                      <span className="font-bold text-purple-800">{count}</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Helper functions
function getTimeRangeMs(range) {
  const ranges = {
    '1h': 3600000,
    '24h': 86400000,
    '7d': 604800000,
    '30d': 2592000000
  };
  return ranges[range] || 86400000;
}

function getEventTypeStats(logs) {
  const counts = {};
  logs.forEach(log => {
    counts[log.event_type] = (counts[log.event_type] || 0) + 1;
  });
  return Object.entries(counts)
    .map(([type, count]) => ({ type, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
}

function getTopUsers(logs) {
  const counts = {};
  logs.forEach(log => {
    if (log.user_email && log.user_email !== 'anonymous') {
      counts[log.user_email] = (counts[log.user_email] || 0) + 1;
    }
  });
  return Object.entries(counts)
    .map(([email, count]) => ({ email, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
}