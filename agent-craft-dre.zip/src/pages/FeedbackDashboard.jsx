import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Label } from "@/components/ui/label";
import {
  Shield,
  Loader2,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  Mail,
  Sparkles,
  ArrowUpDown,
  Filter,
  Send,
  Bot,
  Target,
  Zap,
  AlertTriangle,
  User,
  Calendar,
  MessageSquare
} from "lucide-react";
import { motion } from "framer-motion";

const STATUS_CONFIG = {
  new: { label: "New", icon: Clock, color: "from-blue-500 to-cyan-600", bg: "bg-blue-50", text: "text-blue-700" },
  in_progress: { label: "In Progress", icon: Target, color: "from-amber-500 to-orange-600", bg: "bg-amber-50", text: "text-amber-700" },
  completed: { label: "Completed", icon: CheckCircle2, color: "from-green-500 to-emerald-600", bg: "bg-green-50", text: "text-green-700" },
  unable_to_complete: { label: "Unable", icon: XCircle, color: "from-red-500 to-rose-600", bg: "bg-red-50", text: "text-red-700" }
};

const TYPE_CONFIG = {
  bug: { label: "Bug", emoji: "🐛", color: "text-red-600" },
  feature_request: { label: "Feature", emoji: "💡", color: "text-amber-600" },
  ui_ux: { label: "UI/UX", emoji: "🎨", color: "text-purple-600" },
  question: { label: "Question", emoji: "❓", color: "text-blue-600" },
  praise: { label: "Praise", emoji: "💝", color: "text-pink-600" }
};

export default function FeedbackDashboard() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [selectedFeedback, setSelectedFeedback] = useState(null);
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortBy, setSortBy] = useState("priority");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: allFeedback = [], isLoading } = useQuery({
    queryKey: ['adminFeedback'],
    queryFn: () => base44.entities.UserFeedback.list('-created_date'),
    enabled: !!user && user?.role === 'admin',
    staleTime: 30000,
  });

  const updateFeedbackMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.UserFeedback.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['adminFeedback'] });
    },
  });

  const handleAIAnalysis = async (feedback) => {
    setIsAnalyzing(true);
    try {
      const analysisPrompt = `Analyze this user feedback and provide numerical ratings:

Feedback Type: ${feedback.feedback_type}
Severity: ${feedback.severity}
User Message: ${feedback.message}
Page: ${feedback.page_url}

Context: AgentCraft is an educational SaaS platform for building AI agents. Users are learning to create and manage AI assistants.

Provide ratings (1-10 scale) for:
1. IMPACT: How many users would benefit?
2. EFFORT: Implementation difficulty (10=very easy, 1=very hard)
3. BUSINESS VALUE: Strategic importance for growth/retention
4. USER PAIN: Level of frustration this causes (10=critical blocker, 1=minor annoyance)

Also calculate: PRIORITY SCORE = (Impact × Business Value × User Pain) ÷ Effort

Provide detailed reasoning for each score.`;

      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: analysisPrompt,
        response_json_schema: {
          type: "object",
          properties: {
            impact_score: { type: "number" },
            effort_score: { type: "number" },
            business_value: { type: "number" },
            user_pain: { type: "number" },
            priority_score: { type: "number" },
            analysis: { type: "string" },
            recommendation: { type: "string" }
          }
        }
      });

      await updateFeedbackMutation.mutateAsync({
        id: feedback.id,
        data: {
          ai_impact_score: analysis.impact_score,
          ai_effort_score: analysis.effort_score,
          ai_business_value: analysis.business_value,
          ai_user_pain: analysis.user_pain,
          ai_priority_score: analysis.priority_score,
          ai_analysis: `${analysis.analysis}\n\nRecommendation: ${analysis.recommendation}`
        }
      });

      alert("✅ AI analysis complete!");
    } catch (error) {
      console.error("AI analysis error:", error);
      alert("Failed to analyze feedback. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleBulkAIAnalysis = async () => {
    const unanalyzed = allFeedback.filter(f => !f.ai_priority_score && f.status === 'new');
    
    if (unanalyzed.length === 0) {
      alert("No new feedback to analyze!");
      return;
    }

    if (!window.confirm(`Analyze ${unanalyzed.length} new feedback items with AI?`)) {
      return;
    }

    setIsAnalyzing(true);
    let successCount = 0;

    for (const feedback of unanalyzed) {
      try {
        await handleAIAnalysis(feedback);
        successCount++;
      } catch (error) {
        console.error(`Failed to analyze feedback ${feedback.id}:`, error);
      }
    }

    alert(`✅ Analyzed ${successCount} of ${unanalyzed.length} feedback items!`);
    setIsAnalyzing(false);
  };

  const handleStatusChange = async (feedback, newStatus, reason = "", timeframe = "") => {
    await updateFeedbackMutation.mutateAsync({
      id: feedback.id,
      data: {
        status: newStatus,
        completion_reason: reason || undefined,
        completion_timeframe: timeframe || undefined,
        assigned_to: user?.email
      }
    });

    // Send follow-up email if completed or unable to complete
    if ((newStatus === 'completed' || newStatus === 'unable_to_complete') && !feedback.follow_up_sent) {
      await handleFollowUpEmail(feedback, newStatus, reason, timeframe);
    }
  };

  const handleFollowUpEmail = async (feedback, status, reason, timeframe) => {
    setIsSendingEmail(true);
    try {
      const isCompleted = status === 'completed';
      const subject = isCompleted 
        ? `✅ We've implemented your feedback!`
        : `Thank you for your feedback`;

      const body = isCompleted
        ? `Hi there! 👋

Thank you for your valuable feedback about "${feedback.message.substring(0, 100)}..."

Great news! We've implemented your suggestion! 🎉

${reason ? `Details: ${reason}` : 'Your feedback has been incorporated into AgentCraft.'}
${timeframe ? `\nYou can expect to see this live: ${timeframe}` : '\nThis update is now live!'}

We truly appreciate you helping us build a better product. Keep the feedback coming!

Best regards,
The AgentCraft Team`
        : `Hi there! 👋

Thank you for taking the time to share your feedback about "${feedback.message.substring(0, 100)}..."

We've carefully reviewed your suggestion. While we appreciate your input, we're unable to implement this at the moment.

${reason || 'This doesn\'t align with our current product roadmap, but we\'ll keep it in mind for future considerations.'}

Your feedback is still incredibly valuable and helps us understand what matters to our users. Please continue sharing your thoughts!

Best regards,
The AgentCraft Team`;

      await base44.integrations.Core.SendEmail({
        from_name: "AgentCraft Team",
        to: feedback.user_email,
        subject: subject,
        body: body
      });

      await updateFeedbackMutation.mutateAsync({
        id: feedback.id,
        data: {
          follow_up_sent: true,
          follow_up_sent_date: new Date().toISOString()
        }
      });

      alert("✅ Follow-up email sent!");
    } catch (error) {
      console.error("Failed to send email:", error);
      alert("Failed to send follow-up email.");
    } finally {
      setIsSendingEmail(false);
    }
  };

  const handleSendDailyReport = async () => {
    setIsSendingEmail(true);
    try {
      const topFeedback = [...allFeedback]
        .filter(f => f.ai_priority_score && f.status === 'new')
        .sort((a, b) => (b.ai_priority_score || 0) - (a.ai_priority_score || 0))
        .slice(0, 10);

      if (topFeedback.length === 0) {
        alert("No prioritized feedback to send!");
        setIsSendingEmail(false);
        return;
      }

      const emailBody = `📊 AgentCraft Feedback Hot List - Top 10 Priorities

${topFeedback.map((f, i) => `
${i + 1}. [Priority: ${f.ai_priority_score?.toFixed(1)}] ${TYPE_CONFIG[f.feedback_type]?.emoji} ${f.message.substring(0, 100)}
   Impact: ${f.ai_impact_score}/10 | Effort: ${f.ai_effort_score}/10 | Value: ${f.ai_business_value}/10 | Pain: ${f.ai_user_pain}/10
   User: ${f.user_email}
   ${f.ai_analysis ? 'Analysis: ' + f.ai_analysis.substring(0, 200) + '...' : ''}
`).join('\n')}

---
View full dashboard: ${window.location.origin}${window.location.pathname}

This is your automated daily feedback report.
`;

      await base44.integrations.Core.SendEmail({
        from_name: "AgentCraft Feedback System",
        to: user?.email,
        subject: `🔥 Daily Feedback Hot List - ${new Date().toLocaleDateString()}`,
        body: emailBody
      });

      alert("✅ Daily report sent!");
    } catch (error) {
      console.error("Failed to send daily report:", error);
      alert("Failed to send daily report.");
    } finally {
      setIsSendingEmail(false);
    }
  };

  // Access control
  if (isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="p-8 max-w-md text-center">
          <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-gray-600">This page is only accessible to administrators.</p>
        </Card>
      </div>
    );
  }

  // Filter and sort
  let filteredFeedback = allFeedback.filter(f => {
    const statusMatch = statusFilter === 'all' || f.status === statusFilter;
    const typeMatch = typeFilter === 'all' || f.feedback_type === typeFilter;
    return statusMatch && typeMatch;
  });

  filteredFeedback = [...filteredFeedback].sort((a, b) => {
    if (sortBy === 'priority') return (b.ai_priority_score || 0) - (a.ai_priority_score || 0);
    if (sortBy === 'impact') return (b.ai_impact_score || 0) - (a.ai_impact_score || 0);
    if (sortBy === 'effort') return (b.ai_effort_score || 0) - (a.ai_effort_score || 0);
    if (sortBy === 'recent') return new Date(b.created_date) - new Date(a.created_date);
    return 0;
  });

  // Stats
  const stats = {
    total: allFeedback.length,
    new: allFeedback.filter(f => f.status === 'new').length,
    inProgress: allFeedback.filter(f => f.status === 'in_progress').length,
    completed: allFeedback.filter(f => f.status === 'completed').length,
    analyzed: allFeedback.filter(f => f.ai_priority_score).length,
  };

  const topPriority = allFeedback
    .filter(f => f.ai_priority_score && f.status === 'new')
    .sort((a, b) => b.ai_priority_score - a.ai_priority_score)[0];

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center">
                <MessageSquare className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">Feedback Command Center</h1>
                <p className="text-gray-600">AI-powered prioritization & management</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleBulkAIAnalysis}
                disabled={isAnalyzing}
                className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Bot className="w-4 h-4 mr-2" />
                    AI Analyze All
                  </>
                )}
              </Button>
              <Button
                onClick={handleSendDailyReport}
                disabled={isSendingEmail}
                variant="outline"
              >
                {isSendingEmail ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Send Hot List
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            <Card className="p-4">
              <div className="text-2xl font-bold">{stats.total}</div>
              <div className="text-sm text-gray-600">Total</div>
            </Card>
            <Card className="p-4">
              <div className="text-2xl font-bold text-blue-600">{stats.new}</div>
              <div className="text-sm text-gray-600">New</div>
            </Card>
            <Card className="p-4">
              <div className="text-2xl font-bold text-amber-600">{stats.inProgress}</div>
              <div className="text-sm text-gray-600">In Progress</div>
            </Card>
            <Card className="p-4">
              <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
              <div className="text-sm text-gray-600">Completed</div>
            </Card>
            <Card className="p-4">
              <div className="text-2xl font-bold text-purple-600">{stats.analyzed}</div>
              <div className="text-sm text-gray-600">AI Analyzed</div>
            </Card>
          </div>

          {/* Top Priority Alert */}
          {topPriority && (
            <Card className="p-4 bg-gradient-to-r from-red-50 to-orange-50 border-red-200 mb-6">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-bold text-red-900">🔥 Highest Priority</h3>
                    <span className="px-2 py-1 rounded-full bg-red-500 text-white text-xs font-bold">
                      {topPriority.ai_priority_score?.toFixed(1)}
                    </span>
                  </div>
                  <p className="text-sm text-red-800 mb-2">{topPriority.message}</p>
                  <div className="flex gap-4 text-xs text-red-700">
                    <span>Impact: {topPriority.ai_impact_score}/10</span>
                    <span>Effort: {topPriority.ai_effort_score}/10</span>
                    <span>Value: {topPriority.ai_business_value}/10</span>
                    <span>Pain: {topPriority.ai_user_pain}/10</span>
                  </div>
                </div>
                <Button
                  onClick={() => setSelectedFeedback(topPriority)}
                  size="sm"
                  className="bg-red-600 text-white hover:bg-red-700"
                >
                  Review
                </Button>
              </div>
            </Card>
          )}

          {/* Filters */}
          <div className="flex flex-wrap gap-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="ui-control"
            >
              <option value="all">All Status</option>
              <option value="new">New</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="unable_to_complete">Unable</option>
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="ui-control"
            >
              <option value="all">All Types</option>
              <option value="bug">🐛 Bugs</option>
              <option value="feature_request">💡 Features</option>
              <option value="ui_ux">🎨 UI/UX</option>
              <option value="question">❓ Questions</option>
              <option value="praise">💝 Praise</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="ui-control"
            >
              <option value="priority">Priority Score</option>
              <option value="impact">Impact Score</option>
              <option value="effort">Effort Score</option>
              <option value="recent">Most Recent</option>
            </select>
          </div>
        </div>

        {/* Feedback Table */}
        <div className="space-y-3">
          {filteredFeedback.map((feedback, index) => {
            const statusConfig = STATUS_CONFIG[feedback.status];
            const typeConfig = TYPE_CONFIG[feedback.feedback_type];
            const StatusIcon = statusConfig.icon;

            return (
              <motion.div
                key={feedback.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.02 }}
              >
                <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedFeedback(feedback)}>
                  <div className="flex items-start gap-4">
                    {/* Priority Badge */}
                    <div className="flex-shrink-0">
                      {feedback.ai_priority_score ? (
                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 flex flex-col items-center justify-center text-white">
                          <div className="text-xs font-semibold">Priority</div>
                          <div className="text-xl font-bold">{feedback.ai_priority_score.toFixed(1)}</div>
                        </div>
                      ) : (
                        <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center">
                          <Sparkles className="w-6 h-6 text-gray-400" />
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-lg">{typeConfig.emoji}</span>
                          <span className={`text-xs font-bold ${statusConfig.text} ${statusConfig.bg} px-2 py-1 rounded-full`}>
                            {statusConfig.label}
                          </span>
                          {feedback.severity && (
                            <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-2 py-1 rounded-full">
                              {feedback.severity}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(feedback.created_date).toLocaleDateString()}
                        </div>
                      </div>

                      <p className="font-medium text-gray-900 mb-2 line-clamp-2">{feedback.message}</p>

                      <div className="flex items-center gap-4 text-xs text-gray-600 mb-2">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {feedback.user_email}
                        </span>
                        <span>📍 {feedback.page_url?.split('/').pop() || 'Unknown page'}</span>
                      </div>

                      {/* AI Scores */}
                      {feedback.ai_priority_score && (
                        <div className="flex gap-3 text-xs">
                          <span className="flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" />
                            Impact: {feedback.ai_impact_score}/10
                          </span>
                          <span className="flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            Effort: {feedback.ai_effort_score}/10
                          </span>
                          <span className="flex items-center gap-1">
                            <Target className="w-3 h-3" />
                            Value: {feedback.ai_business_value}/10
                          </span>
                          <span className="flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />
                            Pain: {feedback.ai_user_pain}/10
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Quick Actions */}
                    <div className="flex-shrink-0 flex flex-col gap-2">
                      {!feedback.ai_priority_score && (
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAIAnalysis(feedback);
                          }}
                          disabled={isAnalyzing}
                          size="sm"
                          variant="outline"
                        >
                          <Bot className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Detail Modal */}
        {selectedFeedback && (
          <FeedbackDetailModal
            feedback={selectedFeedback}
            onClose={() => setSelectedFeedback(null)}
            onStatusChange={handleStatusChange}
            onAIAnalysis={handleAIAnalysis}
            isAnalyzing={isAnalyzing}
            isSendingEmail={isSendingEmail}
            currentUser={user}
          />
        )}
      </div>
    </div>
  );
}

// Detail Modal Component
function FeedbackDetailModal({ feedback, onClose, onStatusChange, onAIAnalysis, isAnalyzing, isSendingEmail, currentUser }) {
  const [status, setStatus] = useState(feedback.status);
  const [reason, setReason] = useState(feedback.completion_reason || "");
  const [timeframe, setTimeframe] = useState(feedback.completion_timeframe || "");
  const [adminNotes, setAdminNotes] = useState(feedback.admin_notes || "");

  const statusConfig = STATUS_CONFIG[status];
  const typeConfig = TYPE_CONFIG[feedback.feedback_type];

  const handleSave = async () => {
    await onStatusChange(feedback, status, reason, timeframe);
    
    // Update admin notes separately
    if (adminNotes !== feedback.admin_notes) {
      const queryClient = useQueryClient();
      await base44.entities.UserFeedback.update(feedback.id, { admin_notes: adminNotes });
      queryClient.invalidateQueries({ queryKey: ['adminFeedback'] });
    }
    
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 z-50 w-auto md:max-w-3xl max-h-[90vh] overflow-y-auto"
      >
        <Card className="p-6 md:p-8">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${statusConfig.color} flex items-center justify-center text-white`}>
                <statusConfig.icon className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl">{typeConfig.emoji}</span>
                  <h2 className="text-xl font-bold">{typeConfig.label}</h2>
                </div>
                <p className="text-sm text-gray-600">{feedback.user_email}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <XCircle className="w-5 h-5" />
            </Button>
          </div>

          {/* Priority Score */}
          {feedback.ai_priority_score && (
            <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200">
              <div className="grid grid-cols-5 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-purple-600">{feedback.ai_priority_score.toFixed(1)}</div>
                  <div className="text-xs text-gray-600">Priority</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{feedback.ai_impact_score}</div>
                  <div className="text-xs text-gray-600">Impact</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{feedback.ai_effort_score}</div>
                  <div className="text-xs text-gray-600">Effort</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{feedback.ai_business_value}</div>
                  <div className="text-xs text-gray-600">Value</div>
                </div>
                <div>
                  <div className="text-2xl font-bold">{feedback.ai_user_pain}</div>
                  <div className="text-xs text-gray-600">Pain</div>
                </div>
              </div>
            </div>
          )}

          {/* AI Analysis */}
          {feedback.ai_analysis && (
            <div className="mb-6 p-4 rounded-2xl bg-blue-50 border border-blue-200">
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Bot className="w-4 h-4" />
                AI Analysis
              </h3>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">{feedback.ai_analysis}</p>
            </div>
          )}

          {/* Message */}
          <div className="mb-6">
            <Label className="font-bold mb-2 block">User Message</Label>
            <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
              <p className="text-gray-700 whitespace-pre-wrap">{feedback.message}</p>
            </div>
          </div>

          {/* Screenshot */}
          {feedback.screenshot_url && (
            <div className="mb-6">
              <Label className="font-bold mb-2 block">Screenshot</Label>
              <img src={feedback.screenshot_url} alt="Feedback screenshot" className="rounded-xl border border-gray-200 w-full" />
            </div>
          )}

          {/* Metadata */}
          <div className="mb-6 grid grid-cols-2 gap-4 text-sm">
            <div>
              <Label className="font-bold mb-1 block">Page</Label>
              <p className="text-gray-600">{feedback.page_url}</p>
            </div>
            <div>
              <Label className="font-bold mb-1 block">Submitted</Label>
              <p className="text-gray-600">{new Date(feedback.created_date).toLocaleString()}</p>
            </div>
            <div>
              <Label className="font-bold mb-1 block">Severity</Label>
              <p className="text-gray-600">{feedback.severity}</p>
            </div>
            <div>
              <Label className="font-bold mb-1 block">Assigned To</Label>
              <p className="text-gray-600">{feedback.assigned_to || 'Unassigned'}</p>
            </div>
          </div>

          {/* Status Management */}
          <div className="mb-6">
            <Label className="font-bold mb-2 block">Status</Label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="ui-control w-full"
            >
              <option value="new">New</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="unable_to_complete">Unable to Complete</option>
            </select>
          </div>

          {/* Completion Details */}
          {(status === 'completed' || status === 'unable_to_complete') && (
            <div className="space-y-4 mb-6">
              <div>
                <Label htmlFor="reason" className="font-bold mb-2 block">
                  {status === 'completed' ? 'What did you implement?' : 'Why unable to complete?'}
                </Label>
                <Textarea
                  id="reason"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder={status === 'completed' 
                    ? "Describe what was implemented..."
                    : "Explain why this can't be done at this time..."
                  }
                  className="min-h-24"
                />
              </div>
              {status === 'completed' && (
                <div>
                  <Label htmlFor="timeframe" className="font-bold mb-2 block">
                    When will it be live? (optional)
                  </Label>
                  <Input
                    id="timeframe"
                    value={timeframe}
                    onChange={(e) => setTimeframe(e.target.value)}
                    placeholder="e.g., Next release, Already live, Next week"
                  />
                </div>
              )}
            </div>
          )}

          {/* Admin Notes */}
          <div className="mb-6">
            <Label htmlFor="notes" className="font-bold mb-2 block">Internal Notes</Label>
            <Textarea
              id="notes"
              value={adminNotes}
              onChange={(e) => setAdminNotes(e.target.value)}
              placeholder="Private notes for team..."
              className="min-h-24"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            {!feedback.ai_priority_score && (
              <Button
                onClick={() => onAIAnalysis(feedback)}
                disabled={isAnalyzing}
                variant="outline"
                className="flex-1"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Bot className="w-4 h-4 mr-2" />
                    AI Analyze
                  </>
                )}
              </Button>
            )}
            <Button onClick={handleSave} className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </div>

          {feedback.follow_up_sent && (
            <p className="text-xs text-gray-500 text-center mt-4">
              ✅ Follow-up email sent on {new Date(feedback.follow_up_sent_date).toLocaleDateString()}
            </p>
          )}
        </Card>
      </motion.div>
    </>
  );
}