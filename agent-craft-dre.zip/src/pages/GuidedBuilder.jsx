import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Card } from "@/components/ui/Card";
import { Sparkles, Check, ArrowRight, ArrowLeft, Loader2, ChevronDown, ChevronUp, Plus, Zap, Send, Bot, User as UserIcon, RotateCcw, Lightbulb } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import IntentSelector from "../components/builder/IntentSelector";
import ActionSelector from "../components/builder/ActionSelector";
import ContextualHelp from "../components/ContextualHelp";

const STEPS = [
  { id: 1, title: "What's Your Channel About?", subtitle: "Pick your niche" },
  { id: 2, title: "Name Your Content Helper", subtitle: "Give it personality" },
  { id: 3, title: "Try It Out", subtitle: "Get video ideas" },
  { id: 4, title: "Review & Create", subtitle: "One last look" }
];

const PERSONALITY_PRESETS = [
  {
    id: "professional",
    label: "Professional",
    description: "Formal, precise, business-focused",
    emoji: "💼",
    template: "You are {name}, a professional assistant. Communicate clearly and formally. Always maintain a respectful, business-appropriate tone."
  },
  {
    id: "friendly",
    label: "Friendly",
    description: "Warm, conversational, empathetic",
    emoji: "😊",
    template: "You are {name}, a warm and helpful assistant. Use a conversational, empathetic tone. Make users feel comfortable and supported."
  },
  {
    id: "concise",
    label: "Concise",
    description: "Brief, direct, efficiency-focused",
    emoji: "⚡",
    template: "You are {name}, a concise and efficient assistant. Provide brief, direct responses. Focus on efficiency and clarity."
  },
  {
    id: "expert",
    label: "Expert",
    description: "Technical, detailed, authoritative",
    emoji: "🎓",
    template: "You are {name}, an expert assistant. Provide detailed, technical responses with authoritative knowledge. Be thorough and precise."
  }
];

const SCRIPTED_CONVERSATIONS = {
  youtube_ideas: [
    { role: "user", content: "I need video ideas for my channel" },
    { role: "assistant", content: "Hi! I'm {name}, your YouTube content assistant. I'd love to help you brainstorm video ideas! What's been on your mind lately? Any topics you're excited about?", abilities_used: ["content_brainstorming"] },
    { role: "user", content: "I want to talk about getting started" },
    { role: "assistant", content: "Perfect! Here are 5 video ideas for beginners: 1) 'My First Week as a Creator - What I Learned', 2) '5 Mistakes I Made Starting Out', 3) 'Budget Setup Guide for New Creators', 4) 'How I Got My First 100 Subscribers', 5) 'Day in the Life - Behind the Scenes'. Which one speaks to you?", abilities_used: ["trend_research", "viral_analysis"] }
  ],
  customer_support: [
    { role: "user", content: "Hi, I need help with my account" },
    { role: "assistant", content: "Hello! I'm {name}, your support assistant. I'd be happy to help with your account. What specific issue are you experiencing?", abilities_used: ["conversation_history"] },
    { role: "user", content: "I can't log in" },
    { role: "assistant", content: "I understand login issues can be frustrating. Let me help you resolve this. First, have you tried resetting your password? I can also check if there are any issues with your account status.", abilities_used: ["knowledge_base_search", "sentiment_detection"] }
  ],
  sales_assistant: [
    { role: "user", content: "I'm interested in your enterprise plan" },
    { role: "assistant", content: "Great to hear from you! I'm {name}, your sales assistant. Our enterprise plan is perfect for growing teams. Can you tell me a bit about your company size and current needs?", abilities_used: ["product_catalog"] },
    { role: "user", content: "We're a team of 50 people" },
    { role: "assistant", content: "Perfect! For a 50-person team, our Enterprise plan offers unlimited users, priority support, and advanced integrations. Would you like to schedule a demo to see how it works?", abilities_used: ["crm_integration", "calendar_booking"] }
  ],
  scheduling_coordinator: [
    { role: "user", content: "I need to schedule a meeting with 3 people" },
    { role: "assistant", content: "Hi! I'm {name}, your scheduling coordinator. I'll help you find the perfect time for all 3 people. Could you share the names or email addresses of the attendees?", abilities_used: ["calendar_integration"] },
    { role: "user", content: "Sarah, Mike, and John from the marketing team" },
    { role: "assistant", content: "Got it! I'll check their calendars to find available times. Looking at this week, I see Thursday at 2 PM works for everyone. Should I send the invites?", abilities_used: ["availability_finder", "email_sender"] }
  ],
  research_assistant: [
    { role: "user", content: "What are the latest trends in AI?" },
    { role: "assistant", content: "Hello! I'm {name}, your research assistant. I'd be happy to research the latest AI trends for you. Let me search for current information...", abilities_used: ["web_search"] },
    { role: "user", content: "Focus on business applications" },
    { role: "assistant", content: "Based on recent data, the top AI trends in business are: 1) Generative AI for content creation, 2) AI-powered customer service automation, 3) Predictive analytics for decision-making. Would you like me to dive deeper into any of these?", abilities_used: ["web_search", "data_extraction"] }
  ],
  content_creator: [
    { role: "user", content: "I need a blog post about productivity" },
    { role: "assistant", content: "Hi! I'm {name}, your content creation assistant. I'll help you create an engaging blog post about productivity. What's your target audience and desired tone?", abilities_used: ["content_templates"] },
    { role: "user", content: "Young professionals, friendly tone" },
    { role: "assistant", content: "Perfect! Here's a draft title: '5 Productivity Hacks That Actually Work for Busy Professionals'. I'll craft content with actionable tips, relatable examples, and a conversational style. Would you like me to proceed?", abilities_used: ["brand_voice_library", "grammar_checker"] }
  ],
  data_analyst: [
    { role: "user", content: "Show me our sales performance this quarter" },
    { role: "assistant", content: "Hello! I'm {name}, your data analyst. I'll analyze your sales performance for this quarter. Let me query the database...", abilities_used: ["database_query"] },
    { role: "user", content: "Compare it to last quarter" },
    { role: "assistant", content: "Analysis complete! Your Q4 sales increased by 23% compared to Q3. Top performing products: Product A (+45%), Product B (+32%). I can generate a detailed report with charts if you'd like.", abilities_used: ["database_query", "chart_generator", "statistical_analysis"] }
  ]
};

const SUGGESTED_QUERIES = {
  youtube_ideas: [
    "Give me 5 video ideas about productivity",
    "What's trending in my niche?",
    "Help me write a catchy title",
    "How can I make this topic engaging?",
    "What should I film this week?",
    "Ideas for short-form content",
    "Help me plan a content series",
    "What hooks work best for beginners?"
  ],
  customer_support: [
    "How do I reset my password?",
    "What's the status of my ticket?",
    "I need help with billing",
    "Can you escalate my issue?",
    "How do I update my account info?",
    "Is there a known outage?",
    "What are your support hours?",
    "I'm getting an error message"
  ],
  sales_assistant: [
    "What's included in your plans?",
    "Can I schedule a demo?",
    "What's your pricing for teams?",
    "Do you offer discounts?",
    "How does billing work?",
    "What integrations do you support?",
    "Can I see a product comparison?",
    "What's your refund policy?"
  ],
  scheduling_coordinator: [
    "Find time for a team meeting",
    "What's my schedule tomorrow?",
    "Cancel my 3pm meeting",
    "Book a 1-hour slot next week",
    "Who's available Friday afternoon?",
    "Reschedule my meeting",
    "Set up a recurring weekly call",
    "What time zones can you handle?"
  ],
  research_assistant: [
    "Research competitors in my industry",
    "Summarize this article for me",
    "What's trending in tech?",
    "Find statistics on market growth",
    "Compare these two companies",
    "What are best practices for SEO?",
    "Gather data on customer behavior",
    "Create a citation for this source"
  ],
  content_creator: [
    "Write a social media caption",
    "Create an email newsletter",
    "Draft a product announcement",
    "Generate blog post ideas",
    "Write a compelling headline",
    "Improve this paragraph",
    "Create a content calendar",
    "What's our brand voice?"
  ],
  data_analyst: [
    "Show me revenue trends",
    "What's our conversion rate?",
    "Analyze customer churn",
    "Create a sales report",
    "What products are top sellers?",
    "Compare this month vs last",
    "Show regional performance",
    "Calculate average order value"
  ]
};

export default function GuidedBuilder() {
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Step 1: Intent Selection
  const [selectedIntent, setSelectedIntent] = useState(null);

  // Step 2: Details
  const [agentName, setAgentName] = useState("");
  const [agentDescription, setAgentDescription] = useState("");
  const [personalityPreset, setPersonalityPreset] = useState("friendly");
  const [toneLevel, setToneLevel] = useState(3);
  const [verbosityLevel, setVerbosityLevel] = useState(3);
  const [customInstructions, setCustomInstructions] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);



  // Step 4: Chat Preview
  const [chatMessages, setChatMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [suggestedQueries, setSuggestedQueries] = useState([]);
  const [previewStartTime, setPreviewStartTime] = useState(null);
  const [messagesSent, setMessagesSent] = useState(0);
  const chatEndRef = useRef(null);

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  // Auto-populate name and description when intent is selected
  useEffect(() => {
    if (selectedIntent && currentStep === 2 && !agentName) {
      setAgentName(selectedIntent.name);
      setAgentDescription(selectedIntent.description);
    }
  }, [selectedIntent, currentStep, agentName]);



  // Initialize scripted chat when moving to Step 3 (changed from Step 4)
  useEffect(() => {
    if (currentStep === 3 && chatMessages.length === 0) {
      const scriptedConvo = SCRIPTED_CONVERSATIONS[selectedIntent?.id] || SCRIPTED_CONVERSATIONS.youtube_ideas;
      const initialMessages = scriptedConvo.map(msg => ({
        ...msg,
        content: msg.content.replace('{name}', agentName)
      }));
      setChatMessages(initialMessages);
      
      // Initialize suggested queries
      const queries = SUGGESTED_QUERIES[selectedIntent?.id] || SUGGESTED_QUERIES.youtube_ideas;
      setSuggestedQueries(getRandomQueries(queries, 4));
      
      // Track preview start time
      setPreviewStartTime(Date.now());
    }
  }, [currentStep, chatMessages.length, selectedIntent, agentName]);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const getRandomQueries = (queriesArray, count) => {
    const shuffled = [...queriesArray].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };

  const resetChat = () => {
    setChatMessages([]);
    setCurrentMessage("");
    setMessagesSent(0);
    setPreviewStartTime(Date.now());
    
    // Reinitialize with scripted conversation
    const scriptedConvo = SCRIPTED_CONVERSATIONS[selectedIntent?.id] || SCRIPTED_CONVERSATIONS.youtube_ideas;
    const initialMessages = scriptedConvo.map(msg => ({
      ...msg,
      content: msg.content.replace('{name}', agentName)
    }));
    setChatMessages(initialMessages);
    
    // Refresh suggested queries
    const queries = SUGGESTED_QUERIES[selectedIntent?.id] || SUGGESTED_QUERIES.youtube_ideas;
    setSuggestedQueries(getRandomQueries(queries, 4));
  };

  const createAgentMutation = useMutation({
    mutationFn: async (agentData) => {
      if (!user?.email) throw new Error("User not logged in");
      
      const agent = await base44.entities.Agent.create(agentData);
      
      // Content moderation check
      const moderationCheck = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a content moderation AI. Analyze this AI agent for any inappropriate, harmful, or spam content.
        
Agent Name: ${agentData.name}
Agent Description: ${agentData.description}
Custom Instructions: ${agentData.custom_instructions || 'None'}

Score this content from 0-100 where:
- 0-30: Safe, appropriate content
- 31-70: Potentially problematic, needs human review
- 71-100: Clearly inappropriate, should be blocked

Consider:
1. Inappropriate language or hate speech
2. Spam or promotional content
3. Misleading or deceptive descriptions
4. Sexual, violent, or harmful content
5. Off-topic or low-quality content

Return ONLY a JSON object with your analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            score: {type: "number"},
            reasons: {
              type: "array",
              items: {type: "string"}
            },
            decision: {
              type: "string",
              enum: ["approved", "pending_review", "blocked"]
            }
          }
        }
      });

      let status = "approved";
      let autoDecision = true;
      
      if (moderationCheck.score > 70) {
        status = "blocked";
      } else if (moderationCheck.score > 30) {
        status = "pending_review";
      }

      await base44.entities.ContentModeration.create({
        content_type: "agent",
        content_id: agent.id,
        content_preview: `${agentData.name}: ${agentData.description.substring(0, 100)}`,
        moderation_score: moderationCheck.score,
        status: status,
        auto_decision: autoDecision,
        moderation_reasons: moderationCheck.reasons || [],
        author_email: user.email
      });

      return { agent, status, score: moderationCheck.score };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['agents'] });
      
      if (previewStartTime) {
        const timeInPreview = (Date.now() - previewStartTime) / 1000;
        console.log('Preview Analytics:', {
          time_in_preview_seconds: timeInPreview,
          messages_sent: messagesSent,
          completed_creation: true
        });
      }
      
      if (data.status === "blocked") {
        alert("⚠️ Your agent was automatically blocked due to policy violations.");
        navigate(createPageUrl("Gallery"));
      } else if (data.status === "pending_review") {
        alert("⏳ Your agent is under review. It will be visible once approved.");
        navigate(createPageUrl("Gallery"));
      } else {
        alert("🎉 Agent created successfully!");
        navigate(createPageUrl("Gallery"));
      }
    },
  });



  const handleSendMessage = async (messageText = null) => {
    const textToSend = messageText || currentMessage;
    if (!textToSend.trim()) return;

    const userMessage = { role: "user", content: textToSend };
    setChatMessages([...chatMessages, userMessage]);
    setCurrentMessage("");
    setIsTyping(true);
    setMessagesSent(messagesSent + 1);

    // Regenerate suggested queries
    const queries = SUGGESTED_QUERIES[selectedIntent?.id] || SUGGESTED_QUERIES.youtube_ideas;
    setSuggestedQueries(getRandomQueries(queries, 4));

    // Simulate AI response after a delay
    setTimeout(async () => {
      const selectedPersonality = PERSONALITY_PRESETS.find(p => p.id === personalityPreset);
      let systemPrompt = selectedPersonality.template.replace('{name}', agentName);
      
      systemPrompt += `\n\n${agentDescription}`;
      systemPrompt += `\n\nYou are a YouTube content creation assistant focused on helping creators brainstorm video ideas, titles, and content strategies.`;
      
      if (toneLevel <= 2) {
        systemPrompt += " Use a formal tone.";
      } else if (toneLevel >= 4) {
        systemPrompt += " Use a casual tone.";
      }
      
      if (verbosityLevel <= 2) {
        systemPrompt += " Be brief.";
      } else if (verbosityLevel >= 4) {
        systemPrompt += " Be detailed.";
      }

      try {
        const response = await base44.integrations.Core.InvokeLLM({
          prompt: `${systemPrompt}\n\nUser: ${textToSend}\n\nAssistant:`,
        });

        setChatMessages(prev => [...prev, { 
          role: "assistant", 
          content: response
        }]);
      } catch (error) {
        setChatMessages(prev => [...prev, { 
          role: "assistant", 
          content: "I'm ready to help! This is a preview of how I'll respond."
        }]);
      } finally {
        setIsTyping(false);
      }
    }, 1500); // 1.5 second delay for realism
  };

  const handleNext = () => {
    if (currentStep === 1 && !selectedIntent) {
      return;
    }

    if (currentStep === 2) {
      if (!agentName.trim()) {
        alert("Please provide a name for your agent");
        return;
      }
      if (agentName.trim().length < 3) {
        alert("Agent name must be at least 3 characters long");
        return;
      }
      if (!agentDescription.trim()) {
        alert("Please provide a description for your agent");
        return;
      }
    }



    if (currentStep === 3) {
      // Log analytics when leaving preview
      if (previewStartTime) {
        const timeInPreview = (Date.now() - previewStartTime) / 1000;
        console.log('Preview Analytics:', {
          time_in_preview_seconds: timeInPreview,
          messages_sent: messagesSent,
          reached_review: true
        });
      }
    }

    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleCreate = async () => {
    setIsCreating(true);
    try {
      const selectedPersonality = PERSONALITY_PRESETS.find(p => p.id === personalityPreset);
      
      // Build personality prompt with template and customizations
      let personalityPrompt = selectedPersonality.template.replace('{name}', agentName);
      
      // Add tone adjustment
      if (toneLevel <= 2) {
        personalityPrompt += " Use a formal and professional tone.";
      } else if (toneLevel >= 4) {
        personalityPrompt += " Use a casual and relaxed tone.";
      }
      
      // Add verbosity adjustment
      if (verbosityLevel <= 2) {
        personalityPrompt += " Keep responses brief and to the point.";
      } else if (verbosityLevel >= 4) {
        personalityPrompt += " Provide detailed and comprehensive responses.";
      }
      
      // Add custom instructions if provided
      if (customInstructions.trim()) {
        personalityPrompt += `\n\nAdditional Instructions: ${customInstructions.trim()}`;
      }
      
      await createAgentMutation.mutateAsync({
        name: agentName,
        description: agentDescription,
        personality: personalityPrompt,
        personality_preset: personalityPreset,
        tone_level: toneLevel,
        verbosity_level: verbosityLevel,
        custom_instructions: customInstructions.trim() || undefined,
        color_theme: "purple",
        is_active: true,
        intent_id: selectedIntent?.id,
        intent_name: selectedIntent?.name
      });
    } finally {
      setIsCreating(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  const canProceed = currentStep === 1 ? !!selectedIntent : true;
  const canCreateAgent = messagesSent >= 1; // Must send at least 1 message in preview

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app pb-24">
        {/* Progress Steps */}
        <div className="mb-6 md:mb-12">
          <div className="flex items-center justify-center gap-1 md:gap-4 mb-6 md:mb-8 overflow-x-auto pb-2 md:pb-4 px-2">
            {STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center flex-shrink-0">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center font-bold text-sm md:text-lg transition-all ${
                      currentStep > step.id
                        ? 'bg-gray-900 text-white'
                        : currentStep === step.id
                        ? 'bg-gray-900 text-white'
                        : 'bg-gray-200 text-gray-500'
                    }`}
                  >
                    {currentStep > step.id ? (
                      <Check className="w-4 h-4 md:w-6 md:h-6" />
                    ) : (
                      step.id
                    )}
                  </div>
                  <div className="text-center mt-2 hidden md:block">
                    <div className={`text-xs md:text-sm font-semibold ${
                      currentStep >= step.id ? 'text-gray-900' : 'text-gray-500'
                    }`}>
                      {step.title}
                    </div>
                    <div className="text-xs text-gray-500">
                      {step.subtitle}
                    </div>
                  </div>
                </div>
                {index < STEPS.length - 1 && (
                  <div
                    className={`w-8 md:w-16 h-1 mx-2 md:mx-4 rounded-full transition-all flex-shrink-0 ${
                      currentStep > step.id
                        ? 'bg-gray-900'
                        : 'bg-gray-200'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          {currentStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
            >
              <IntentSelector
                selectedIntent={selectedIntent}
                onSelect={setSelectedIntent}
              />
            </motion.div>
          )}

          {currentStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-2xl mx-auto"
            >
              <div className="text-center mb-4 md:mb-8">
                <h2 className="text-2xl md:text-3xl font-bold mb-2 text-gray-900">Name Your AI Helper</h2>
                <p className="text-sm md:text-base text-gray-600">
                  Make it yours with a name and personality that fits your style
                </p>
              </div>

              <Card className="p-4 md:p-8 space-y-4 md:space-y-6 max-h-[70vh] overflow-y-auto">
                <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-1">
                      What should we call it? <span className="text-red-500">*</span>
                      <ContextualHelp helpKey="agent_name" />
                    </label>
                  <Input
                    placeholder="e.g., Sarah, ContentPro, MyAssistant"
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    className="text-lg"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Pick a friendly name you'll remember (at least 3 characters)
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2 flex items-center gap-1">
                    What will it help you with? <span className="text-red-500">*</span>
                    <ContextualHelp helpKey="agent_description" />
                  </label>
                  <Textarea
                    placeholder="Example: Help me reply to customer emails faster and more professionally"
                    value={agentDescription}
                    onChange={(e) => setAgentDescription(e.target.value)}
                    className="min-h-32"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Be specific about the tasks it'll handle for you
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-3 flex items-center gap-1">
                    How should it talk to you? <span className="text-red-500">*</span>
                    <ContextualHelp helpKey="personality" />
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {PERSONALITY_PRESETS.map((preset) => {
                      const isSelected = personalityPreset === preset.id;
                      
                      return (
                        <button
                          key={preset.id}
                          onClick={() => setPersonalityPreset(preset.id)}
                          className={`p-4 rounded-xl text-left transition-all border-2 ${
                            isSelected
                              ? 'border-gray-900 bg-gray-50'
                              : 'border-gray-200 bg-white hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-start gap-3">
                            <div className="text-2xl flex-shrink-0">{preset.emoji}</div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-bold text-gray-900">
                                  {preset.label}
                                </span>
                                {isSelected && (
                                  <div className="w-5 h-5 rounded-full bg-gray-900 flex items-center justify-center">
                                    <Check className="w-3 h-3 text-white" />
                                  </div>
                                )}
                              </div>
                              <p className="text-xs text-gray-600">
                                {preset.description}
                              </p>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Pick the communication style that matches your needs
                  </p>
                </div>

                {/* Advanced Options - Collapsed by Default */}
                <div className="border-t border-gray-200 pt-6">
                  <button
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="flex items-center justify-between w-full text-left mb-4"
                  >
                    <span className="text-sm font-semibold text-gray-900">
                      Advanced Options
                    </span>
                    {showAdvanced ? (
                      <ChevronUp className="w-5 h-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-500" />
                    )}
                  </button>

                  <AnimatePresence>
                    {showAdvanced && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-6 overflow-hidden"
                      >
                        {/* Tone Slider */}
                        <div>
                          <label className="block text-sm font-semibold text-gray-900 mb-2">
                            Tone
                          </label>
                          <div className="flex items-center gap-4">
                            <span className="text-xs text-gray-600 whitespace-nowrap">Formal</span>
                            <input
                              type="range"
                              min="1"
                              max="5"
                              value={toneLevel}
                              onChange={(e) => setToneLevel(Number(e.target.value))}
                              className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-900"
                            />
                            <span className="text-xs text-gray-600 whitespace-nowrap">Casual</span>
                          </div>
                          <div className="flex justify-between mt-1 px-2">
                            {[1, 2, 3, 4, 5].map((level) => (
                              <div
                                key={level}
                                className={`w-2 h-2 rounded-full ${
                                  toneLevel >= level ? 'bg-gray-900' : 'bg-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <p className="text-xs text-gray-500 mt-2">
                            Adjust how formal or casual your agent sounds
                          </p>
                        </div>

                        {/* Verbosity Slider */}
                        <div>
                          <label className="block text-sm font-semibold text-gray-900 mb-2">
                            Verbosity
                          </label>
                          <div className="flex items-center gap-4">
                            <span className="text-xs text-gray-600 whitespace-nowrap">Brief</span>
                            <input
                              type="range"
                              min="1"
                              max="5"
                              value={verbosityLevel}
                              onChange={(e) => setVerbosityLevel(Number(e.target.value))}
                              className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-900"
                            />
                            <span className="text-xs text-gray-600 whitespace-nowrap">Detailed</span>
                          </div>
                          <div className="flex justify-between mt-1 px-2">
                            {[1, 2, 3, 4, 5].map((level) => (
                              <div
                                key={level}
                                className={`w-2 h-2 rounded-full ${
                                  verbosityLevel >= level ? 'bg-purple-500' : 'bg-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                          <p className="text-xs text-gray-500 mt-2">
                            Control response length and detail level
                          </p>
                        </div>

                        {/* Custom System Prompt */}
                        <div>
                          <label className="block text-sm font-semibold text-gray-900 mb-2">
                            Custom Instructions (Advanced)
                          </label>
                          <Textarea
                            placeholder="Add custom instructions for your agent's behavior..."
                            value={customInstructions}
                            onChange={(e) => setCustomInstructions(e.target.value)}
                            className="min-h-24 font-mono text-sm"
                          />
                          <p className="text-xs text-gray-500 mt-1">
                            Override default personality with custom system prompt instructions
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>


              </Card>
            </motion.div>
          )}

          {currentStep === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
            >
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold mb-2 text-gray-900">Test drive your content helper</h2>
                <p className="text-gray-600">
                  See how {agentName} helps you brainstorm video ideas
                </p>
              </div>

              {/* Split-Screen Layout */}
              <div className="grid lg:grid-cols-[30%_70%] gap-6">
                {/* Left: Configuration Summary */}
                <Card className="p-6 h-fit">
                  <h3 className="text-lg font-bold mb-4 text-gray-900">Helper Configuration</h3>
                  
                  {/* Agent Avatar/Icon */}
                  <div className="w-20 h-20 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-4">
                    <Bot className="w-10 h-10 text-white" />
                  </div>

                  <div className="text-center mb-6">
                    <h4 className="font-bold text-xl text-gray-900">{agentName}</h4>
                    <p className="text-sm text-gray-600 mt-1">{selectedIntent?.name}</p>
                  </div>

                  <div className="space-y-4 text-sm">
                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Personality
                      </label>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">
                          {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.emoji}
                        </span>
                        <span className="font-medium text-gray-900">
                          {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.label}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Description
                      </label>
                      <p className="text-gray-700 text-xs leading-relaxed">
                        {agentDescription}
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Preview Stats
                      </label>
                      <div className="space-y-1 text-xs text-gray-600">
                        <div>💬 {messagesSent} messages sent</div>
                        <div>⏱️ {previewStartTime ? Math.floor((Date.now() - previewStartTime) / 1000) : 0}s in preview</div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Right: Chat Simulator */}
                <Card className="p-6 flex flex-col" style={{ height: '600px' }}>
                  <div className="flex items-center justify-between pb-4 border-b border-gray-200 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center">
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{agentName}</h4>
                        <p className="text-xs text-gray-500">Online • Responds instantly</p>
                      </div>
                    </div>
                    <Button
                      onClick={resetChat}
                      variant="outline"
                      size="sm"
                      className="gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Reset
                    </Button>
                  </div>

                  {/* Chat Messages */}
                  <div className="flex-1 overflow-y-auto mb-4 space-y-4">
                    {chatMessages.map((msg, index) => (
                      <div key={index}>
                        <div
                          className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          {msg.role === 'assistant' && (
                            <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center flex-shrink-0">
                              <Bot className="w-4 h-4 text-white" />
                            </div>
                          )}
                          <div
                            className={`max-w-[80%] p-3 rounded-xl ${
                              msg.role === 'user'
                                ? 'bg-gray-900 text-white'
                                : 'bg-gray-100 text-gray-900'
                            }`}
                          >
                            <p className="text-sm leading-relaxed">{msg.content}</p>
                          </div>
                          {msg.role === 'user' && (
                            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center flex-shrink-0">
                              <UserIcon className="w-4 h-4 text-gray-600" />
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                        <div className="bg-gray-100 p-3 rounded-2xl">
                          <div className="flex gap-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Suggested Queries */}
                  {!isTyping && suggestedQueries.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mb-3"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Lightbulb className="w-4 h-4 text-amber-500" />
                        <span className="text-xs font-semibold text-gray-600">Try asking:</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {suggestedQueries.map((query, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSendMessage(query)}
                            className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-xs text-gray-700 transition-colors border border-gray-200"
                          >
                            {query}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Chat Input */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Ask for video ideas..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={isTyping}
                      className="flex-1"
                    />
                    <Button
                      onClick={() => handleSendMessage()}
                      disabled={!currentMessage.trim() || isTyping}
                      className="bg-gray-900 hover:bg-gray-800 text-white"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>

                  <p className="text-xs text-gray-500 mt-2 text-center">
                    💡 This is a live preview. Try the suggested questions or ask your own!
                  </p>
                </Card>
              </div>

              {/* Enhanced CTA Section */}
              <div className="mt-8 flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto">
                <Button
                  onClick={() => setCurrentStep(1)}
                  variant="outline"
                  className="flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Go Back and Adjust
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={!canCreateAgent}
                  className={`flex-1 h-12 font-semibold ${
                    canCreateAgent
                      ? 'bg-gray-900 hover:bg-gray-800 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {canCreateAgent ? (
                    <>
                      Looks Good! Create My Helper
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  ) : (
                    <>
                      Send 1 message to continue
                      <ArrowRight className="w-4 h-4 ml-2 opacity-50" />
                    </>
                  )}
                </Button>
              </div>
              
              {!canCreateAgent && (
                <motion.p
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center text-xs text-gray-500 mt-2"
                >
                  💬 Try asking for video ideas first!
                </motion.p>
              )}
            </motion.div>
          )}

          {currentStep === 999 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-3xl mx-auto"
            >
              <div className="text-center mb-8">
                <div className="w-16 h-16 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold mb-2 text-gray-900">Choose Your Helper's Superpowers</h2>
                <p className="text-gray-600">
                  We've picked the best skills for your needs. You can add or remove any you'd like!
                </p>
              </div>

              {/* Progress Indicator */}
              <Card className="p-4 mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-700">
                    Abilities Configured
                  </span>
                  <span className="text-sm font-bold text-gray-900">
                    {enabledCount} of {totalAvailable}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gray-900 h-2 rounded-full transition-all"
                    style={{ width: `${(enabledCount / totalAvailable) * 100}%` }}
                  />
                </div>
              </Card>

              {/* Default Abilities */}
              <Card className="p-6 mb-6">
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-gray-900">
                  Core Abilities (Pre-selected)
                  <ContextualHelp helpKey="abilities" />
                </h3>
                <div className="space-y-3">
                  {defaultAbilities.map((ability) => {
                    const isEnabled = enabledAbilities.includes(ability.id);
                    
                    return (
                      <button
                        key={ability.id}
                        onClick={() => toggleAbility(ability.id)}
                        className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
                          isEnabled
                            ? 'border-gray-900 bg-gray-50'
                            : 'border-gray-200 bg-gray-50 opacity-60'
                        }`}
                      >
                        <div className="flex items-start gap-4">
                          <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            isEnabled ? 'bg-gray-900' : 'bg-gray-300'
                          }`}>
                            {isEnabled && <Check className="w-4 h-4 text-white" />}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-bold text-gray-900">{ability.name}</h4>
                              {ability.auto_selected && (
                                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-medium">
                                  Auto-selected
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-gray-600">{ability.description}</p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </Card>

              {/* Additional Abilities */}
              {additionalAbilities.length > 0 && (
                <Card className="p-6">
                  <button
                    onClick={() => setShowAdditional(!showAdditional)}
                    className="flex items-center justify-between w-full text-left mb-4"
                  >
                    <div className="flex items-center gap-2">
                      <Plus className="w-5 h-5 text-gray-900" />
                      <span className="text-lg font-bold text-gray-900">
                        Add More Abilities ({additionalAbilities.length} available)
                      </span>
                    </div>
                    {showAdditional ? (
                      <ChevronUp className="w-5 h-5 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-gray-500" />
                    )}
                  </button>

                  <AnimatePresence>
                    {showAdditional && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-3 overflow-hidden"
                      >
                        {additionalAbilities.map((ability) => {
                          const isEnabled = enabledAbilities.includes(ability.id);
                          
                          return (
                            <button
                              key={ability.id}
                              onClick={() => toggleAbility(ability.id)}
                              className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
                                isEnabled
                                  ? 'border-purple-500 bg-purple-50'
                                  : 'border-gray-200 bg-white hover:border-gray-300'
                              }`}
                            >
                              <div className="flex items-start gap-4">
                                <div className={`w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 ${
                                  isEnabled ? 'bg-purple-500' : 'bg-gray-200'
                                }`}>
                                  {isEnabled && <Check className="w-4 h-4 text-white" />}
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-gray-900 mb-1">{ability.name}</h4>
                                  <p className="text-sm text-gray-600">{ability.description}</p>
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </Card>
              )}

              {/* Warning if too few abilities */}
              {enabledCount === 1 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200"
                >
                  <p className="text-sm text-amber-800">
                    ⚠️ Your agent must have at least 1 ability enabled. Consider enabling more for better functionality.
                  </p>
                </motion.div>
              )}

              {/* Actions Section */}
              <Card className="p-6 mt-6">
                <ActionSelector
                  selectedActions={selectedActions}
                  onSelectAction={(actionId) => setSelectedActions([...selectedActions, actionId])}
                  onRemoveAction={(actionId) => setSelectedActions(selectedActions.filter(id => id !== actionId))}
                />
              </Card>
            </motion.div>
          )}

          {currentStep === 999 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
            >
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold mb-2 text-gray-900">Test drive your agent</h2>
                <p className="text-gray-600">
                  See how {agentName} responds in a real conversation
                </p>
              </div>

              {/* Split-Screen Layout */}
              <div className="grid lg:grid-cols-[30%_70%] gap-6">
                {/* Left: Configuration Summary */}
                <Card className="p-6 h-fit">
                  <h3 className="text-lg font-bold mb-4 text-gray-900">Agent Configuration</h3>
                  
                  {/* Agent Avatar/Icon */}
                  <div className="w-20 h-20 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-4">
                    <Bot className="w-10 h-10 text-white" />
                  </div>

                  <div className="text-center mb-6">
                    <h4 className="font-bold text-xl text-gray-900">{agentName}</h4>
                    <p className="text-sm text-gray-600 mt-1">{selectedIntent?.name}</p>
                  </div>

                  <div className="space-y-4 text-sm">
                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Personality
                      </label>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">
                          {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.emoji}
                        </span>
                        <span className="font-medium text-gray-900">
                          {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.label}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Active Abilities
                      </label>
                      <p className="font-bold text-gray-900">
                        {enabledCount} abilities configured
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Description
                      </label>
                      <p className="text-gray-700 text-xs leading-relaxed">
                        {agentDescription}
                      </p>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase block mb-1">
                        Preview Stats
                      </label>
                      <div className="space-y-1 text-xs text-gray-600">
                        <div>💬 {messagesSent} messages sent</div>
                        <div>⏱️ {previewStartTime ? Math.floor((Date.now() - previewStartTime) / 1000) : 0}s in preview</div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Right: Chat Simulator */}
                <Card className="p-6 flex flex-col" style={{ height: '600px' }}>
                  <div className="flex items-center justify-between pb-4 border-b border-gray-200 mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gray-900 flex items-center justify-center">
                        <Bot className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{agentName}</h4>
                        <p className="text-xs text-gray-500">Online • Responds instantly</p>
                      </div>
                    </div>
                    <Button
                      onClick={resetChat}
                      variant="outline"
                      size="sm"
                      className="gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Reset
                    </Button>
                  </div>

                  {/* Chat Messages */}
                  <div className="flex-1 overflow-y-auto mb-4 space-y-4">
                    {chatMessages.map((msg, index) => (
                      <div key={index}>
                        <div
                          className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          {msg.role === 'assistant' && (
                            <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center flex-shrink-0">
                              <Bot className="w-4 h-4 text-white" />
                            </div>
                          )}
                          <div
                            className={`max-w-[80%] p-3 rounded-xl ${
                              msg.role === 'user'
                                ? 'bg-gray-900 text-white'
                                : 'bg-gray-100 text-gray-900'
                            }`}
                          >
                            <p className="text-sm leading-relaxed">{msg.content}</p>
                          </div>
                          {msg.role === 'user' && (
                            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center flex-shrink-0">
                              <UserIcon className="w-4 h-4 text-gray-600" />
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                        <div className="bg-gray-100 p-3 rounded-2xl">
                          <div className="flex gap-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Suggested Queries */}
                  {!isTyping && suggestedQueries.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mb-3"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Lightbulb className="w-4 h-4 text-amber-500" />
                        <span className="text-xs font-semibold text-gray-600">Try these questions:</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {suggestedQueries.map((query, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSendMessage(query)}
                            className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-xs text-gray-700 transition-colors border border-gray-200"
                          >
                            {query}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {/* Chat Input */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your message..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      disabled={isTyping}
                      className="flex-1"
                    />
                    <Button
                      onClick={() => handleSendMessage()}
                      disabled={!currentMessage.trim() || isTyping}
                      className="bg-gray-900 hover:bg-gray-800 text-white"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>

                  <p className="text-xs text-gray-500 mt-2 text-center">
                    💡 This is a live preview. Try the suggested questions or ask your own!
                  </p>
                </Card>
              </div>

              {/* Enhanced CTA Section */}
              <div className="mt-8 flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto">
                <Button
                  onClick={() => setCurrentStep(1)}
                  variant="outline"
                  className="flex-1"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Go Back and Adjust
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={!canCreateAgent}
                  className={`flex-1 h-12 font-semibold ${
                    canCreateAgent
                      ? 'bg-gray-900 hover:bg-gray-800 text-white'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {canCreateAgent ? (
                    <>
                      Looks Good! Create My Agent
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  ) : (
                    <>
                      Send 1 message to continue
                      <ArrowRight className="w-4 h-4 ml-2 opacity-50" />
                    </>
                  )}
                </Button>
              </div>
              
              {!canCreateAgent && (
                <motion.p
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center text-xs text-gray-500 mt-2"
                >
                  💬 Try having a conversation with your agent first!
                </motion.p>
              )}
            </motion.div>
          )}

          {currentStep === 4 && (
            <motion.div
              key="step5"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="max-w-2xl mx-auto"
            >
              <div className="text-center mb-8">
                <div className="w-16 h-16 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold mb-2 text-gray-900">Review Your Agent</h2>
                <p className="text-gray-600">
                  Everything look good? Let's create your agent!
                </p>
              </div>

              <Card className="p-4 md:p-8 space-y-4 md:space-y-6 max-h-[70vh] overflow-y-auto">
                <div>
                  <label className="text-sm font-semibold text-gray-500 block mb-1">
                    TYPE
                  </label>
                  <p className="text-lg font-bold text-gray-900">{selectedIntent?.name}</p>
                </div>

                <div className="h-px bg-gray-200" />

                <div>
                  <label className="text-sm font-semibold text-gray-500 block mb-1">
                    NAME
                  </label>
                  <p className="text-lg font-bold">{agentName}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-gray-500 block mb-1">
                    DESCRIPTION
                  </label>
                  <p className="text-gray-700">{agentDescription}</p>
                </div>

                <div>
                  <label className="text-sm font-semibold text-gray-500 block mb-1">
                    PERSONALITY
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">
                      {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.emoji}
                    </span>
                    <div>
                      <p className="font-bold text-gray-900">
                        {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.label}
                      </p>
                      <p className="text-sm text-gray-600">
                        {PERSONALITY_PRESETS.find(p => p.id === personalityPreset)?.description}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Show advanced settings if customized */}
                {(toneLevel !== 3 || verbosityLevel !== 3 || customInstructions.trim()) && (
                  <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
                    <h4 className="text-sm font-semibold text-gray-700 mb-3">
                      Advanced Settings:
                    </h4>
                    <div className="space-y-2 text-sm">
                      {toneLevel !== 3 && (
                        <div className="flex items-center gap-2">
                          <span className="text-gray-600">Tone:</span>
                          <span className="font-medium">
                            {toneLevel <= 2 ? '🎩 Formal' : toneLevel >= 4 ? '😎 Casual' : '📝 Balanced'}
                          </span>
                        </div>
                      )}
                      {verbosityLevel !== 3 && (
                        <div className="flex items-center gap-2">
                          <span className="text-gray-600">Verbosity:</span>
                          <span className="font-medium">
                            {verbosityLevel <= 2 ? '⚡ Brief' : verbosityLevel >= 4 ? '📚 Detailed' : '📝 Balanced'}
                          </span>
                        </div>
                      )}
                      {customInstructions.trim() && (
                        <div>
                          <span className="text-gray-600">Custom Instructions:</span>
                          <p className="mt-1 text-gray-700 italic bg-white p-2 rounded border border-gray-200">
                            "{customInstructions.trim()}"
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-sm font-semibold text-gray-500 block mb-2">
                    EXAMPLE QUERIES
                  </label>
                  <div className="space-y-2">
                    {selectedIntent?.example_queries?.map((query, i) => (
                      <div
                        key={i}
                        className="text-sm text-gray-600 flex items-start gap-2"
                      >
                        <span className="text-gray-400 flex-shrink-0">•</span>
                        <span>"{query}"</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-6 md:mt-8 max-w-2xl mx-auto gap-3">
          <Button
            onClick={handleBack}
            variant="outline"
            disabled={currentStep === 1}
            className="px-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          {currentStep < STEPS.length ? (
            currentStep === 3 ? null : ( // Hide next button on Step 3, CTAs are shown above
              <div className="flex flex-col items-end gap-2">
                <Button
                  onClick={handleNext}
                  disabled={!canProceed}
                  className={`px-8 h-12 font-semibold ${
                    canProceed 
                      ? 'bg-gray-900 hover:bg-gray-800 text-white' 
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed opacity-60'
                  }`}
                >
                  {!canProceed && currentStep === 1 ? (
                    <>
                      Select an Intent
                      <ArrowRight className="w-4 h-4 ml-2 opacity-50" />
                    </>
                  ) : (
                    <>
                      Next
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </>
                  )}
                </Button>
                {!canProceed && currentStep === 1 && (
                  <motion.p
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-xs text-gray-500"
                  >
                    👆 Choose a template above to continue
                  </motion.p>
                )}
              </div>
            )
          ) : (
            <Button
              onClick={handleCreate}
              disabled={isCreating}
              className="bg-gray-900 hover:bg-gray-800 text-white px-8"
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Create Agent
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}