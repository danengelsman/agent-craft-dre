import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { PageShell } from "@/components/ui/PageShell";
import { DollarSign, TrendingUp, Download, Package, Eye, Star, Calendar, BarChart3, Shield, Tag, History, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import CertificationBadge from "../components/marketplace/CertificationBadge";
import { motion } from "framer-motion";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const COLORS = ['#a78bfa', '#60a5fa', '#34d399', '#fbbf24', '#f87171', '#ec4899'];

export default function CreatorDashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const { data: purchases = [] } = useQuery({
    queryKey: ['creatorPurchases', user?.email],
    queryFn: () => base44.entities.AgentPurchase.filter({ seller_email: user?.email }),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: myAgents = [] } = useQuery({
    queryKey: ['myPublicAgents', user?.email],
    queryFn: async () => {
      const agents = await base44.entities.Agent.filter({ created_by: user?.email, is_public: true });
      return agents;
    },
    enabled: !!user?.email,
    initialData: [],
  });

  // Calculate stats
  const totalRevenue = purchases.reduce((sum, p) => sum + (p.seller_revenue || 0), 0);
  const platformFees = purchases.reduce((sum, p) => sum + (p.platform_fee || 0), 0);
  const totalSales = purchases.length;
  const totalDownloads = myAgents.reduce((sum, a) => sum + (a.download_count || 0), 0);

  // Revenue by agent
  const revenueByAgent = myAgents.map(agent => {
    const agentPurchases = purchases.filter(p => p.agent_id === agent.id);
    const revenue = agentPurchases.reduce((sum, p) => sum + (p.seller_revenue || 0), 0);
    return {
      name: agent.name,
      revenue: revenue,
      sales: agentPurchases.length,
      downloads: agent.download_count || 0,
      price: agent.price || 0,
      rating: agent.average_rating || 0,
    };
  }).sort((a, b) => b.revenue - a.revenue);

  // Revenue over time (last 30 days)
  const getLast30Days = () => {
    const days = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      days.push(date.toISOString().split('T')[0]);
    }
    return days;
  };

  const revenueTimeline = getLast30Days().map(date => {
    const dayPurchases = purchases.filter(p => 
      p.created_date && p.created_date.startsWith(date)
    );
    return {
      date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      revenue: dayPurchases.reduce((sum, p) => sum + (p.seller_revenue || 0), 0),
      sales: dayPurchases.length,
    };
  });

  // Price distribution
  const priceDistribution = [
    { name: 'Free', value: myAgents.filter(a => a.price === 0).length },
    { name: '$0.99', value: myAgents.filter(a => a.price === 0.99).length },
    { name: '$2.99', value: myAgents.filter(a => a.price === 2.99).length },
    { name: '$4.99', value: myAgents.filter(a => a.price === 4.99).length },
    { name: '$9.99', value: myAgents.filter(a => a.price === 9.99).length },
  ].filter(item => item.value > 0);

  return (
    <PageShell>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
              <BarChart3 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Creator Dashboard</h1>
              <p className="ui-muted">Track your marketplace performance</p>
            </div>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>
            <div className="text-3xl font-bold mb-1">
              ${totalRevenue.toFixed(2)}
            </div>
            <div className="text-sm ui-muted">Total Revenue</div>
            <div className="text-xs ui-muted mt-2">
              Platform Fee: ${platformFees.toFixed(2)}
            </div>
          </Card>

          <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6" />
                </div>
              </div>
              <div className="text-3xl font-bold mb-1">{totalSales}</div>
              <div className="text-sm ui-muted">Total Sales</div>
              <div className="text-xs ui-muted mt-2">
                Avg: ${totalSales > 0 ? (totalRevenue / totalSales).toFixed(2) : '0.00'} per sale
              </div>
          </Card>

          <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                  <Download className="w-6 h-6" />
                </div>
              </div>
              <div className="text-3xl font-bold mb-1">{totalDownloads}</div>
              <div className="text-sm ui-muted">Total Downloads</div>
              <div className="text-xs ui-muted mt-2">
                {myAgents.length} public agents
              </div>
          </Card>

          <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                  <Star className="w-6 h-6" />
                </div>
              </div>
              <div className="text-3xl font-bold mb-1">
                {myAgents.length > 0 
                  ? (myAgents.reduce((sum, a) => sum + (a.average_rating || 0), 0) / myAgents.length).toFixed(1)
                  : '0.0'}
              </div>
              <div className="text-sm ui-muted">Avg Rating</div>
              <div className="text-xs ui-muted mt-2">
                {myAgents.reduce((sum, a) => sum + (a.review_count || 0), 0)} reviews
              </div>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue Timeline */}
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Revenue Trend (30 Days)
            </h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={revenueTimeline}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12, fill: '#6b7280' }}
                    tickMargin={10}
                  />
                  <YAxis 
                    tick={{ fontSize: 12, fill: '#6b7280' }}
                    tickFormatter={(value) => `$${value}`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      background: '#ffffff',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0, 0, 0, 0.05)'
                    }}
                    formatter={(value) => [`$${value.toFixed(2)}`, 'Revenue']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#111827" 
                    strokeWidth={2}
                    dot={{ fill: '#111827', r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
          </Card>

          {/* Price Distribution */}
          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <Package className="w-5 h-5" />
              Agent Price Distribution
            </h3>
              {priceDistribution.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={priceDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {priceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ 
                        background: '#ffffff',
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.05)'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[250px] flex items-center justify-center ui-muted">
                  No agents published yet
                </div>
              )}
          </Card>
        </div>

        {/* Top Performing Agents */}
        <Card className="p-6">
          <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
            <Star className="w-5 h-5" />
            Top Performing Agents
          </h3>

          {revenueByAgent.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 mx-auto mb-4 text-gray-400 opacity-50" />
              <h3 className="text-xl font-bold mb-2">No Sales Yet</h3>
              <p className="ui-muted">
                Publish your agents to the marketplace to start earning!
              </p>
            </div>
            ) : (
              <div className="space-y-4">
                {myAgents.map((agent, index) => {
                  const agentPurchases = purchases.filter(p => p.agent_id === agent.id);
                  const revenue = agentPurchases.reduce((sum, p) => sum + (p.seller_revenue || 0), 0);
                  const sales = agentPurchases.length;

                  return (
                    <div
                      key={agent.id}
                      className="p-5 ui-card hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-bold text-lg">{agent.name}</h4>
                            <CertificationBadge status={agent.certification_status} size="xs" />
                          </div>
                          <div className="flex items-center gap-4 text-sm ui-muted">
                            <div className="flex items-center gap-1">
                              <DollarSign className="w-4 h-4" />
                              <span className="font-medium">${(agent.price || 0).toFixed(2)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                              <span>{(agent.average_rating || 0).toFixed(1)}</span>
                            </div>
                            <span className="text-xs bg-gray-200 px-2 py-0.5 rounded">v{agent.version || '1.0.0'}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-green-600">
                            ${revenue.toFixed(2)}
                          </div>
                          <div className="text-xs text-purple-600">Revenue</div>
                        </div>
                      </div>

                      {/* Quality Score */}
                      {agent.last_audit_score && (
                        <div className="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 flex items-center gap-2">
                          <Shield className="w-4 h-4 text-green-600" />
                          <span className="text-sm text-green-700">Quality Score: <strong>{agent.last_audit_score}%</strong></span>
                          {agent.certification_status === 'none' && agent.last_audit_score >= 80 && (
                            <span className="text-xs text-green-600 ml-auto">Eligible for certification!</span>
                          )}
                        </div>
                      )}

                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-3 rounded-lg text-center bg-gray-50 border border-gray-200">
                          <TrendingUp className="w-5 h-5 text-gray-900 mx-auto mb-1" />
                          <div className="text-xl font-bold text-gray-900">{sales}</div>
                          <div className="text-xs text-gray-600">Sales</div>
                        </div>

                        <div className="p-3 rounded-lg text-center bg-gray-50 border border-gray-200">
                          <Download className="w-5 h-5 text-gray-900 mx-auto mb-1" />
                          <div className="text-xl font-bold text-gray-900">{agent.download_count || 0}</div>
                          <div className="text-xs text-gray-600">Downloads</div>
                        </div>

                        <div className="p-3 rounded-lg text-center bg-gray-50 border border-gray-200">
                          <Eye className="w-5 h-5 text-gray-900 mx-auto mb-1" />
                          <div className="text-xl font-bold text-gray-900">
                            {(agent.download_count || 0) > 0 ? ((sales / (agent.download_count || 1)) * 100).toFixed(1) : '0'}%
                          </div>
                          <div className="text-xs text-gray-600">Conv. Rate</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
        </Card>

        {/* Payout Information */}
        <Card className="p-6 mt-8">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Payout Information
          </h3>
          <div className="space-y-4">
              <div className="p-5 rounded-xl bg-gray-50 border border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-sm ui-muted mb-1">Available Balance</div>
                    <div className="text-3xl font-bold">${totalRevenue.toFixed(2)}</div>
                  </div>
                  <div className="px-4 py-2 rounded-lg text-sm font-semibold bg-green-100 text-green-800">
                    Ready for Payout
                  </div>
                </div>
                <div className="text-sm ui-muted">
                  Revenue Share: <span className="font-semibold">85%</span> You • <span className="font-semibold">15%</span> Platform
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 ui-card">
                  <div className="text-sm ui-muted mb-2">Payout Method</div>
                  <div className="text-lg font-bold">PayPal / Bank Transfer</div>
                  <div className="text-xs ui-muted mt-1">Configure in settings</div>
                </div>

                <div className="p-4 ui-card">
                  <div className="text-sm ui-muted mb-2">Next Payout</div>
                  <div className="text-lg font-bold">Monthly - 1st</div>
                  <div className="text-xs ui-muted mt-1">Minimum $10 threshold</div>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-gray-50 border border-gray-200">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                    💡
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold mb-1">Pro Tips for Creators</div>
                    <ul className="text-sm ui-muted space-y-1">
                      <li>• Price competitively - $2.99-$4.99 converts best</li>
                      <li>• Update agent descriptions with clear value propositions</li>
                      <li>• Respond to reviews to build trust</li>
                      <li>• Bundle related agents for higher revenue</li>
                    </ul>
                  </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </PageShell>
  );
}