import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/Card";
import { Loader2, GitBranch, Users, Play, Pause, Trash2, CheckCircle, Clock, XCircle, ArrowRight, Eye } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import WorkflowVisualization from "../components/collaboration/WorkflowVisualization";

const statusConfig = {
  pending: { icon: Clock, color: "text-amber-600", bg: "bg-amber-50", label: "Pending" },
  in_progress: { icon: Play, color: "text-blue-600", bg: "bg-blue-50", label: "In Progress" },
  completed: { icon: CheckCircle, color: "text-green-600", bg: "bg-green-50", label: "Completed" },
  failed: { icon: XCircle, color: "text-red-600", bg: "bg-red-50", label: "Failed" },
  paused: { icon: Pause, color: "text-gray-600", bg: "bg-gray-50", label: "Paused" },
};

const workflowTypeLabels = {
  audit_pipeline: "Audit Pipeline",
  improvement_cycle: "Improvement Cycle",
  knowledge_sync: "Knowledge Sync",
  custom: "Custom",
};

export default function CollaborationDashboard() {
  const [user, setUser] = useState(null);
  const [selectedCollab, setSelectedCollab] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: collaborations = [], isLoading } = useQuery({
    queryKey: ['agentCollaborations'],
    queryFn: () => base44.entities.AgentCollaboration.list('-created_date'),
    enabled: !!user,
  });

  const { data: allAgents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list(),
    enabled: !!user,
  });

  const deleteCollaborationMutation = useMutation({
    mutationFn: (id) => base44.entities.AgentCollaboration.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentCollaborations'] });
      toast.success("Collaboration deleted");
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.AgentCollaboration.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentCollaborations'] });
      toast.success("Status updated");
    },
    onError: (error) => {
      toast.error(`Error: ${error.message}`);
    },
  });

  const executeCollaborationMutation = useMutation({
    mutationFn: (collaboration_id) => base44.functions.invoke('executeCollaboration', { collaboration_id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agentCollaborations'] });
      toast.success("Collaboration executed successfully!");
    },
    onError: (error) => {
      toast.error(`Execution failed: ${error.message}`);
    },
  });

  const getAgentName = (agentId) => {
    const agent = allAgents.find(a => a.id === agentId);
    return agent?.name || "Unknown Agent";
  };

  if (!user || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  const statsData = {
    total: collaborations.length,
    active: collaborations.filter(c => c.status === 'in_progress').length,
    completed: collaborations.filter(c => c.status === 'completed').length,
    failed: collaborations.filter(c => c.status === 'failed').length,
  };

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Agent Collaborations
            </h1>
            <p className="text-gray-600">Manage multi-agent workflows</p>
          </div>
          <Link to={createPageUrl("CollaborationBuilder")}>
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
              <GitBranch className="w-4 h-4 mr-2" />
              New Collaboration
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                <GitBranch className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{statsData.total}</p>
                <p className="text-sm text-gray-600">Total</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Play className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{statsData.active}</p>
                <p className="text-sm text-gray-600">Active</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{statsData.completed}</p>
                <p className="text-sm text-gray-600">Completed</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{statsData.failed}</p>
                <p className="text-sm text-gray-600">Failed</p>
              </div>
            </div>
          </Card>
        </div>

        {collaborations.length === 0 ? (
          <Card className="p-12 text-center">
            <GitBranch className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h2 className="text-xl font-bold mb-2 text-gray-900">No collaborations yet</h2>
            <p className="text-gray-600 mb-6">Create your first multi-agent workflow</p>
            <Link to={createPageUrl("CollaborationBuilder")}>
              <Button>Create Collaboration</Button>
            </Link>
          </Card>
        ) : (
          <div className="space-y-4">
            {collaborations.map((collab, index) => {
              const StatusIcon = statusConfig[collab.status]?.icon || Clock;
              const statusColor = statusConfig[collab.status]?.color || "text-gray-600";
              const statusBg = statusConfig[collab.status]?.bg || "bg-gray-50";
              const statusLabel = statusConfig[collab.status]?.label || collab.status;

              return (
                <motion.div
                  key={collab.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="p-6 hover:shadow-lg transition-all">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-bold text-gray-900">{collab.workflow_name}</h3>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusBg} ${statusColor} flex items-center gap-1`}>
                            <StatusIcon className="w-3 h-3" />
                            {statusLabel}
                          </span>
                          <span className="px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                            {workflowTypeLabels[collab.workflow_type] || collab.workflow_type}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                          <Users className="w-4 h-4" />
                          <span>{collab.participating_agents?.length || 0} agents participating</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {collab.status === 'pending' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => executeCollaborationMutation.mutate(collab.id)}
                            disabled={executeCollaborationMutation.isPending}
                          >
                            <Play className="w-4 h-4" />
                          </Button>
                        )}
                        {collab.status === 'in_progress' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateStatusMutation.mutate({ id: collab.id, status: 'paused' })}
                          >
                            <Pause className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedCollab(collab)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteCollaborationMutation.mutate(collab.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="text-xs font-semibold text-gray-500 mb-2">ORCHESTRATOR</p>
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center">
                            <Users className="w-4 h-4 text-purple-600" />
                          </div>
                          <span className="font-medium text-gray-900">{getAgentName(collab.orchestrator_agent)}</span>
                        </div>
                      </div>

                      <div>
                        <p className="text-xs font-semibold text-gray-500 mb-2">PARTICIPATING AGENTS</p>
                        <div className="flex flex-wrap gap-2">
                          {collab.participating_agents?.map((agentId) => (
                            <span key={agentId} className="px-3 py-1 rounded-full bg-gray-100 text-gray-700 text-sm">
                              {getAgentName(agentId)}
                            </span>
                          ))}
                        </div>
                      </div>

                      {collab.steps?.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-gray-500 mb-2">WORKFLOW PROGRESS</p>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all"
                                style={{
                                  width: `${(collab.steps.filter(s => s.status === 'completed').length / collab.steps.length) * 100}%`
                                }}
                              />
                            </div>
                            <span className="text-sm text-gray-600">
                              {collab.steps.filter(s => s.status === 'completed').length}/{collab.steps.length}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Workflow Visualization Dialog */}
        <Dialog open={!!selectedCollab} onOpenChange={() => setSelectedCollab(null)}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedCollab?.workflow_name}</DialogTitle>
            </DialogHeader>
            {selectedCollab && (
              <WorkflowVisualization 
                collaboration={selectedCollab} 
                agents={allAgents}
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}