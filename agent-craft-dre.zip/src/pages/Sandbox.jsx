import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Textarea } from "@/components/ui/Textarea";
import { Sparkles, Send, Loader2, MessageSquare, Trash2, ArrowLeft, Lock, Eye, EyeOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Sandbox() {
  const [user, setUser] = useState(null);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const { data: agents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    initialData: [],
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedAgent) return;

    const userMessage = {
      role: "user",
      content: message.trim(),
      timestamp: new Date().toISOString()
    };

    setChatHistory([...chatHistory, userMessage]);
    setMessage("");
    setIsLoading(true);

    try {
      // Build system prompt based on agent's abilities and personality
      let systemPrompt = `You are ${selectedAgent.name}, an AI assistant. ${selectedAgent.description}\n\n`;
      
      if (selectedAgent.personality) {
        systemPrompt += `Your personality: ${selectedAgent.personality}\n\n`;
      }

      systemPrompt += "Your capabilities:\n";
      const abilities = selectedAgent.abilities || [];
      if (abilities.includes("memory")) {
        systemPrompt += "- You can remember past conversations and context\n";
      }
      if (abilities.includes("personality")) {
        systemPrompt += "- You have a unique personality and communication style\n";
      }
      systemPrompt += "\nRespond naturally and helpfully to the user's message.";

      // Get AI response
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `${systemPrompt}\n\nUser: ${message.trim()}\n\nAssistant:`,
        add_context_from_internet: abilities.includes("web_search")
      });

      const assistantMessage = {
        role: "assistant",
        content: response,
        timestamp: new Date().toISOString()
      };

      setChatHistory([...chatHistory, userMessage, assistantMessage]);

    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearHistory = () => {
    if (window.confirm("Clear this sandbox conversation? (This won't affect your agent's stored data)")) {
      setChatHistory([]);
    }
  };

  const handleBackToAgents = () => {
    setSelectedAgent(null);
    setChatHistory([]);
  };

  if (!selectedAgent) {
    return (
      <div className="bg-app min-h-screen">
        <div className="container-app" style={{ maxWidth: '56rem' }}>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="ui-card p-6 mb-6">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-[16px] flex items-center justify-center" style={{
                  background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                  boxShadow: '6px 6px 12px rgba(180, 150, 220, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8)'
                }}>
                  <Lock className="w-7 h-7 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h1 className="text-2xl md:text-3xl font-bold text-purple-800">Private Sandbox</h1>
                    <div className="px-3 py-1 rounded-[10px] text-xs font-bold text-purple-700" style={{
                      background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                      boxShadow: '3px 3px 6px rgba(180, 150, 220, 0.3)'
                    }}>
                      <EyeOff className="w-3 h-3 inline mr-1" />
                      NOT TRACKED
                    </div>
                  </div>
                  <p className="text-purple-600 text-sm md:text-base">
                    Test agents privately without affecting analytics or storing conversations
                  </p>
                  <div className="mt-3 p-3 rounded-[12px]" style={{
                    background: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)',
                    boxShadow: '4px 4px 8px rgba(240, 170, 200, 0.3)'
                  }}>
                    <div className="text-sm text-pink-800">
                      <strong>Sandbox Mode:</strong> All conversations here are temporary and won't be saved to your agents or counted in statistics.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {agents.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-20"
            >
              <div 
                className="w-24 h-24 rounded-[24px] flex items-center justify-center mx-auto mb-6"
                style={{
                  background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                  boxShadow: '8px 8px 16px rgba(180, 150, 220, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9)'
                }}
              >
                <Sparkles className="w-12 h-12 text-purple-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2 text-purple-800">No agents yet</h2>
              <p className="text-purple-600">
                Create an agent first to test it in the sandbox
              </p>
            </motion.div>
          ) : (
            <div>
              <h2 className="text-xl font-bold mb-4 text-purple-800">Select an Agent to Test</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {agents.map((agent, index) => (
                  <motion.div
                    key={agent.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => setSelectedAgent(agent)}
                    className="ui-card p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div 
                      className="w-14 h-14 rounded-[16px] flex items-center justify-center mb-4"
                      style={{
                        background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                        boxShadow: '6px 6px 12px rgba(180, 150, 220, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8)'
                      }}
                    >
                      <MessageSquare className="w-7 h-7 text-purple-600" />
                    </div>
                    <h3 className="font-bold text-lg mb-2 text-purple-800">{agent.name}</h3>
                    <p className="text-purple-600 text-sm mb-4 line-clamp-2">{agent.description}</p>
                    <div className="flex items-center justify-between text-xs text-purple-500">
                      <span>{agent.abilities?.length || 0} abilities</span>
                      <span className="px-2 py-1 rounded-[8px]" style={{
                        background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                        boxShadow: '2px 2px 4px rgba(180, 150, 220, 0.3)'
                      }}>
                        Test Mode
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen flex flex-col">
      <div className="container-app w-full flex flex-col flex-1" style={{ maxWidth: '64rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div 
            className="ui-card p-6"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-4">
                <Button
                  onClick={handleBackToAgents}
                  variant="ghost"
                  size="icon"
                >
                  <ArrowLeft className="w-5 h-5 text-purple-700" />
                </Button>
                <div 
                  className="w-12 h-12 rounded-[14px] flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                    boxShadow: '6px 6px 12px rgba(180, 150, 220, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8)'
                  }}
                >
                  <Sparkles className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h2 className="font-bold text-xl text-purple-800">{selectedAgent.name}</h2>
                  <p className="text-sm text-purple-600">{selectedAgent.description}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="px-3 py-1 rounded-[10px] text-xs font-bold text-purple-700 flex items-center gap-1" style={{
                  background: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)',
                  boxShadow: '3px 3px 6px rgba(240, 170, 200, 0.3)'
                }}>
                  <Lock className="w-3 h-3" />
                  SANDBOX MODE
                </div>
                {chatHistory.length > 0 && (
                  <Button
                    onClick={handleClearHistory}
                    variant="ghost"
                    size="icon"
                    className="text-purple-700 hover:text-red-600"
                  >
                    <Trash2 className="w-5 h-5" />
                  </Button>
                )}
              </div>
            </div>
            <div className="p-3 rounded-[10px] text-xs" style={{
              background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
              boxShadow: 'inset 2px 2px 4px rgba(209, 196, 233, 0.2)'
            }}>
              <EyeOff className="w-3 h-3 inline mr-2 text-purple-600" />
              <span className="text-purple-700">This conversation is temporary and won't be saved</span>
            </div>
          </div>
        </motion.div>

        {/* Chat Messages */}
        <div 
          className="ui-card flex-1 p-6 mb-6 overflow-y-auto"
          style={{ maxHeight: 'calc(100vh - 350px)', minHeight: '400px' }}
        >
          {chatHistory.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div 
                  className="w-20 h-20 rounded-[20px] flex items-center justify-center mx-auto mb-4"
                  style={{
                    background: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)',
                    boxShadow: '6px 6px 12px rgba(150, 200, 240, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8)'
                  }}
                >
                  <MessageSquare className="w-10 h-10 text-blue-600" />
                </div>
                <h3 className="font-bold text-lg mb-2 text-purple-800">Sandbox Testing</h3>
                <p className="text-purple-600 text-sm">
                  Test {selectedAgent.name} without saving conversation history
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <AnimatePresence>
                {chatHistory.map((msg, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-4 rounded-[18px] ${
                        msg.role === 'user' 
                          ? 'text-purple-800' 
                          : 'text-purple-800'
                      }`}
                      style={{
                        background: msg.role === 'user' 
                          ? 'linear-gradient(145deg, #d4b9f5, #e6d5ff)'
                          : 'linear-gradient(145deg, #f5f3ff, #e8e6f7)',
                        boxShadow: msg.role === 'user'
                          ? '6px 6px 12px rgba(180, 150, 220, 0.3), -6px -6px 12px rgba(255, 255, 255, 0.8), inset 1px 1px 2px rgba(255, 255, 255, 0.3)'
                          : 'inset 4px 4px 8px rgba(209, 196, 233, 0.2), inset -2px -2px 6px rgba(255, 255, 255, 0.7)'
                      }}
                    >
                      <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                      <p className="text-xs text-purple-500 mt-2">
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div
                    className="p-4 rounded-[18px]"
                    style={{
                      background: 'linear-gradient(145deg, #f5f3ff, #e8e6f7)',
                      boxShadow: 'inset 4px 4px 8px rgba(209, 196, 233, 0.2), inset -2px -2px 6px rgba(255, 255, 255, 0.7)'
                    }}
                  >
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                      <span className="text-sm text-purple-600">Thinking...</span>
                    </div>
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div 
            className="ui-card p-4"
          >
            <div className="flex gap-3">
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={`Test message to ${selectedAgent.name}...`}
                className="flex-1 resize-none border-none bg-white/50 rounded-[16px] focus:ring-2 focus:ring-purple-300"
                style={{
                  boxShadow: 'inset 3px 3px 6px rgba(209, 196, 233, 0.2), inset -2px -2px 4px rgba(255, 255, 255, 0.6)'
                }}
                rows={3}
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                disabled={!message.trim() || isLoading}
                className="self-end px-6 py-3 rounded-xl disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin text-purple-700" />
                ) : (
                  <Send className="w-5 h-5 text-purple-700" />
                )}
              </Button>
            </div>
            <div className="flex items-center justify-between mt-2">
              <p className="text-xs text-purple-500">
                Press Enter to send, Shift+Enter for new line
              </p>
              <p className="text-xs text-purple-600 flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Not tracked or saved
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}