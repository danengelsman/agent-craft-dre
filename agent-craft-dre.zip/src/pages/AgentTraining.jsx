import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Loader2, Plus, ArrowRight } from "lucide-react";
import DatasetUploader from "../components/training/DatasetUploader";
import TrainingJobCard from "../components/training/TrainingJobCard";
import TrainingConfigModal from "../components/training/TrainingConfigModal";

export default function AgentTraining() {
  const [user, setUser] = useState(null);
  const [showUploader, setShowUploader] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [selectedDataset, setSelectedDataset] = useState(null);
  const [activeTab, setActiveTab] = useState("datasets");

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  const { data: datasets = [], isLoading: datasetsLoading } = useQuery({
    queryKey: ['training_datasets'],
    queryFn: () => base44.entities.TrainingDataset.list('-created_date'),
    enabled: !!user
  });

  const { data: trainingJobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ['training_jobs'],
    queryFn: () => base44.entities.TrainingJob.list('-created_date'),
    enabled: !!user
  });

  const { data: agents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    enabled: !!user
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-black" />
      </div>
    );
  }

  const activeJobs = trainingJobs.filter(j => ['queued', 'initializing', 'training', 'validating'].includes(j.status));
  const readyDatasets = datasets.filter(d => d.status === 'ready');

  return (
    <div className="bg-app min-h-screen">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-5xl lg:text-7xl font-semibold tracking-tight text-gray-900 mb-6">
              Train your agents.
              <br />
              Make them yours.
            </h1>
            <p className="text-xl lg:text-2xl text-gray-600 mb-12 font-normal">
              Fine-tune AI agents with your own data. Custom knowledge, custom behavior.
            </p>
            <Button
              onClick={() => setShowUploader(true)}
              className="h-12 px-8 bg-black hover:bg-gray-800 text-white rounded-xl font-normal text-base"
            >
              <Plus className="w-4 h-4 mr-2" />
              Upload training data
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <div className="text-center">
            <div className="text-5xl lg:text-6xl font-semibold text-gray-900 mb-2">
              {datasets.length}
            </div>
            <div className="text-base text-gray-600">Datasets</div>
          </div>
          <div className="text-center">
            <div className="text-5xl lg:text-6xl font-semibold text-blue-600 mb-2">
              {activeJobs.length}
            </div>
            <div className="text-base text-gray-600">Training</div>
          </div>
          <div className="text-center">
            <div className="text-5xl lg:text-6xl font-semibold text-green-600 mb-2">
              {trainingJobs.filter(j => j.status === 'completed').length}
            </div>
            <div className="text-base text-gray-600">Completed</div>
          </div>
          <div className="text-center">
            <div className="text-5xl lg:text-6xl font-semibold text-gray-900 mb-2">
              {agents.length}
            </div>
            <div className="text-base text-gray-600">Agents</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <nav className="flex gap-8">
            {[
              { id: 'datasets', label: 'Datasets' },
              { id: 'jobs', label: 'Training Jobs' },
              { id: 'strategies', label: 'Strategies' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 text-[15px] font-normal relative ${
                  activeTab === tab.id
                    ? 'text-gray-900'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-black" />
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-16">
        {activeTab === 'datasets' && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-3xl font-semibold text-gray-900">Training datasets</h2>
              <Button
                onClick={() => setShowUploader(true)}
                variant="outline"
                className="h-10"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add dataset
              </Button>
            </div>

            {datasetsLoading ? (
              <div className="text-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-black mx-auto" />
              </div>
            ) : datasets.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-xl text-gray-600 mb-4">No datasets yet</p>
                <Button onClick={() => setShowUploader(true)} variant="outline">
                  Upload your first dataset
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {datasets.map((dataset) => (
                  <div
                    key={dataset.id}
                    className="p-6 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="font-semibold text-gray-900 text-lg">{dataset.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        dataset.status === 'ready' 
                          ? 'bg-green-100 text-green-700'
                          : dataset.status === 'processing'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-red-100 text-red-700'
                      }`}>
                        {dataset.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-4">{dataset.description}</p>
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <span>{dataset.total_records} examples</span>
                      <span>{(dataset.total_tokens / 1000).toFixed(1)}K tokens</span>
                    </div>
                    {dataset.status === 'ready' && (
                      <Button
                        onClick={() => {
                          setSelectedDataset(dataset);
                          setShowConfigModal(true);
                        }}
                        className="w-full h-10 bg-black hover:bg-gray-800 text-white"
                      >
                        Start training
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'jobs' && (
          <div className="space-y-8">
            <h2 className="text-3xl font-semibold text-gray-900">Training jobs</h2>

            {jobsLoading ? (
              <div className="text-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-black mx-auto" />
              </div>
            ) : trainingJobs.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-xl text-gray-600">No training jobs yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {trainingJobs.map((job) => (
                  <TrainingJobCard key={job.id} job={job} agents={agents} datasets={datasets} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'strategies' && (
          <div className="space-y-16">
            <div className="text-center max-w-2xl mx-auto">
              <h2 className="text-4xl font-semibold text-gray-900 mb-4">
                Fine-tuning strategies
              </h2>
              <p className="text-xl text-gray-600">
                Choose the right approach for your use case
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div className="p-8 bg-gray-50 rounded-2xl">
                <h3 className="text-2xl font-semibold text-gray-900 mb-3">LoRA</h3>
                <p className="text-base text-gray-600 mb-4">
                  Low-Rank Adaptation. Efficient fine-tuning by updating only a small set of parameters.
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Fast training time</li>
                  <li>• Lower compute cost</li>
                  <li>• Great for most use cases</li>
                  <li>• Recommended for beginners</li>
                </ul>
              </div>

              <div className="p-8 bg-gray-50 rounded-2xl">
                <h3 className="text-2xl font-semibold text-gray-900 mb-3">Full Fine-tune</h3>
                <p className="text-base text-gray-600 mb-4">
                  Update all model parameters. Maximum customization and performance.
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Best performance</li>
                  <li>• Longer training time</li>
                  <li>• Higher compute cost</li>
                  <li>• For advanced users</li>
                </ul>
              </div>

              <div className="p-8 bg-gray-50 rounded-2xl">
                <h3 className="text-2xl font-semibold text-gray-900 mb-3">Prompt Tuning</h3>
                <p className="text-base text-gray-600 mb-4">
                  Optimize prompt prefixes while keeping the model frozen.
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Fastest approach</li>
                  <li>• Minimal compute</li>
                  <li>• Limited customization</li>
                  <li>• Good for simple tasks</li>
                </ul>
              </div>

              <div className="p-8 bg-gray-50 rounded-2xl">
                <h3 className="text-2xl font-semibold text-gray-900 mb-3">Few-Shot</h3>
                <p className="text-base text-gray-600 mb-4">
                  No training required. Provide examples in the prompt at inference time.
                </p>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Instant setup</li>
                  <li>• No training cost</li>
                  <li>• Limited to prompt context</li>
                  <li>• Best for small datasets</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {showUploader && (
        <DatasetUploader onClose={() => setShowUploader(false)} />
      )}

      {showConfigModal && selectedDataset && (
        <TrainingConfigModal
          dataset={selectedDataset}
          agents={agents}
          onClose={() => {
            setShowConfigModal(false);
            setSelectedDataset(null);
          }}
        />
      )}
    </div>
  );
}