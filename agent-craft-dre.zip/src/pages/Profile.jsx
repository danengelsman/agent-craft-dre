import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Progress } from "@/components/ui/progress";
import { Trophy, Zap, Sparkles, Award, Star, Target, Flame, Crown, Medal, Users, BookOpen, MessageSquare, TrendingUp, Lock } from "lucide-react";
import { motion } from "framer-motion";

const ACHIEVEMENTS = [
  {
    id: "first_agent",
    title: "First Steps",
    description: "Created your first AI agent",
    icon: Sparkles,
    color: { bg: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)', shadow: 'rgba(180, 150, 220, 0.3)' },
    requirement: (stats) => stats.agentsCreated >= 1,
  },
  {
    id: "agent_master",
    title: "Agent Master",
    description: "Created 5 AI agents",
    icon: Crown,
    color: { bg: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)', shadow: 'rgba(240, 200, 150, 0.3)' },
    requirement: (stats) => stats.agentsCreated >= 5,
  },
  {
    id: "first_lesson",
    title: "Eager Learner",
    description: "Completed your first lesson",
    icon: BookOpen,
    color: { bg: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)', shadow: 'rgba(150, 200, 240, 0.3)' },
    requirement: (stats) => stats.lessonsCompleted >= 1,
  },
  {
    id: "all_lessons",
    title: "Knowledge Seeker",
    description: "Completed all lessons",
    icon: Award,
    color: { bg: 'linear-gradient(145deg, #b8f0c8, #d5f7de)', shadow: 'rgba(160, 220, 180, 0.3)' },
    requirement: (stats) => stats.lessonsCompleted >= stats.totalLessons && stats.totalLessons > 0,
  },
  {
    id: "level_5",
    title: "Rising Star",
    description: "Reached Level 5",
    icon: Star,
    color: { bg: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)', shadow: 'rgba(240, 170, 200, 0.3)' },
    requirement: (stats) => stats.level >= 5,
  },
  {
    id: "level_10",
    title: "Expert Crafter",
    description: "Reached Level 10",
    icon: Trophy,
    color: { bg: 'linear-gradient(145deg, #fbbf24, #f59e0b)', shadow: 'rgba(251, 191, 36, 0.3)' },
    requirement: (stats) => stats.level >= 10,
  },
  {
    id: "xp_1000",
    title: "XP Collector",
    description: "Earned 1,000 XP",
    icon: Zap,
    color: { bg: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)', shadow: 'rgba(150, 200, 240, 0.3)' },
    requirement: (stats) => stats.totalXP >= 1000,
  },
  {
    id: "xp_5000",
    title: "XP Hoarder",
    description: "Earned 5,000 XP",
    icon: Flame,
    color: { bg: 'linear-gradient(145deg, #ffb8a8, #ffd5c9)', shadow: 'rgba(240, 170, 160, 0.3)' },
    requirement: (stats) => stats.totalXP >= 5000,
  },
  {
    id: "conversationalist",
    title: "Master Conversationalist",
    description: "Sent 100 messages to your agents",
    icon: MessageSquare,
    color: { bg: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)', shadow: 'rgba(180, 150, 220, 0.3)' },
    requirement: (stats) => stats.totalMessages >= 100,
  },
  {
    id: "all_abilities",
    title: "Ability Collector",
    description: "Unlocked all abilities",
    icon: Target,
    color: { bg: 'linear-gradient(145deg, #b8f0c8, #d5f7de)', shadow: 'rgba(160, 220, 180, 0.3)' },
    requirement: (stats) => stats.abilitiesUnlocked >= 6,
  },
  {
    id: "speed_learner",
    title: "Speed Learner",
    description: "Completed 3 lessons in one day",
    icon: TrendingUp,
    color: { bg: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)', shadow: 'rgba(240, 200, 150, 0.3)' },
    requirement: (stats) => stats.lessonsCompleted >= 3,
  },
  {
    id: "dedicated",
    title: "Dedicated Crafter",
    description: "Used the app for 7 days",
    icon: Medal,
    color: { bg: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)', shadow: 'rgba(240, 170, 200, 0.3)' },
    requirement: (stats) => stats.daysActive >= 7,
  },
];

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existingProgress = await base44.entities.UserProgress.filter({ user_email: user.email });
      return existingProgress[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
  });

  const { data: agents = [] } = useQuery({
    queryKey: ['agents'],
    queryFn: () => base44.entities.Agent.list('-created_date'),
    initialData: [],
    enabled: !!user && !isLoadingUser,
    retry: 1,
  });

  const { data: lessons = [] } = useQuery({
    queryKey: ['lessons'],
    queryFn: () => base44.entities.Lesson.list('order'),
    initialData: [],
    retry: 1,
  });

  const stats = {
    level: progress?.level || 1,
    totalXP: progress?.xp || 0,
    agentsCreated: agents.length,
    lessonsCompleted: progress?.completed_lessons?.length || 0,
    totalLessons: lessons.length,
    abilitiesUnlocked: progress?.unlocked_abilities?.length || 0,
    totalMessages: agents.reduce((sum, agent) => sum + (agent.chat_history?.length || 0), 0),
    daysActive: 1,
  };

  const xpToNextLevel = stats.level * 200;
  const xpProgress = (stats.totalXP % 200) / 2;

  const unlockedAchievements = ACHIEVEMENTS.filter(achievement => 
    achievement.requirement(stats)
  );

  const lockedAchievements = ACHIEVEMENTS.filter(achievement => 
    !achievement.requirement(stats)
  );

  const achievementPercentage = (unlockedAchievements.length / ACHIEVEMENTS.length) * 100;

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app space-y-6" style={{ maxWidth: '72rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="flex items-center justify-center gap-3 mb-3">
            <div 
              className="w-14 h-14 md:w-16 md:h-16 rounded-[22px] flex items-center justify-center"
              style={{
                background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                boxShadow: '8px 8px 16px rgba(180, 150, 220, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
              }}
            >
              <Trophy className="w-7 h-7 md:w-8 md:h-8 text-purple-600" />
            </div>
          </div>
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-purple-800 mb-2 px-4 break-words">
            {user?.full_name || 'Your Profile'}
          </h1>
          <p className="text-sm md:text-base text-purple-600 px-4 break-all">{user?.email}</p>
        </motion.div>

        {/* Level & XP Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6 md:p-8 relative overflow-hidden">
            <div 
              className="absolute -top-20 -right-20 w-48 h-48 rounded-full opacity-20"
              style={{ background: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)' }}
            />
            <div 
              className="absolute -bottom-20 -left-20 w-48 h-48 rounded-full opacity-20"
              style={{ background: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)' }}
            />

            <div className="relative">
              <div className="flex flex-col md:flex-row items-center md:justify-between gap-4 mb-6">
                <div className="flex items-center gap-3 md:gap-4">
                  <div 
                    className="w-16 h-16 md:w-20 md:h-20 rounded-[20px] flex items-center justify-center flex-shrink-0"
                    style={{
                      background: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)',
                      boxShadow: '8px 8px 16px rgba(240, 200, 150, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
                    }}
                  >
                    <Crown className="w-8 h-8 md:w-10 md:h-10 text-orange-600" />
                  </div>
                  <div>
                    <div className="text-3xl md:text-5xl font-bold text-purple-800">Level {stats.level}</div>
                    <div className="text-sm md:text-base text-purple-600 font-medium">Agent Crafter</div>
                  </div>
                </div>
                <div className="text-center md:text-right">
                  <div className="text-3xl md:text-4xl font-bold text-purple-800">{stats.totalXP}</div>
                  <div className="text-xs md:text-sm text-purple-600 whitespace-nowrap">Total XP</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between text-xs md:text-sm text-purple-700 font-medium">
                  <span>Progress to Level {stats.level + 1}</span>
                  <span className="whitespace-nowrap">{stats.totalXP % 200} / 200 XP</span>
                </div>
                <div 
                  className="h-3 md:h-4 rounded-full overflow-hidden relative"
                  style={{
                    background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                    boxShadow: 'inset 4px 4px 8px rgba(209, 196, 233, 0.4), inset -2px -2px 6px rgba(255, 255, 255, 0.8)'
                  }}
                >
                  <div 
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${xpProgress}%`,
                      background: 'linear-gradient(90deg, #b8a9d6, #c9b9e8)',
                      boxShadow: '4px 4px 8px rgba(160, 140, 200, 0.3)'
                    }}
                  />
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6 text-purple-800 flex items-center gap-2 px-2">
            <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
            Your Statistics
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
            <div 
              className="p-4 md:p-6 rounded-[20px] text-center"
              style={{
                background: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)',
                boxShadow: '8px 8px 16px rgba(180, 150, 220, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
              }}
            >
              <Sparkles className="w-6 h-6 md:w-8 md:h-8 text-purple-600 mx-auto mb-2 md:mb-3" />
              <div className="text-2xl md:text-4xl font-bold text-purple-800 mb-1">{stats.agentsCreated}</div>
              <div className="text-xs md:text-sm text-purple-600 font-medium">Agents Created</div>
            </div>

            <div 
              className="p-4 md:p-6 rounded-[20px] text-center"
              style={{
                background: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)',
                boxShadow: '8px 8px 16px rgba(150, 200, 240, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
              }}
            >
              <BookOpen className="w-6 h-6 md:w-8 md:h-8 text-blue-600 mx-auto mb-2 md:mb-3" />
              <div className="text-2xl md:text-4xl font-bold text-blue-800 mb-1">{stats.lessonsCompleted}</div>
              <div className="text-xs md:text-sm text-blue-600 font-medium">Lessons Done</div>
            </div>

            <div 
              className="p-4 md:p-6 rounded-[20px] text-center"
              style={{
                background: 'linear-gradient(145deg, #b8f0c8, #d5f7de)',
                boxShadow: '8px 8px 16px rgba(160, 220, 180, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
              }}
            >
              <Target className="w-6 h-6 md:w-8 md:h-8 text-green-600 mx-auto mb-2 md:mb-3" />
              <div className="text-2xl md:text-4xl font-bold text-green-800 mb-1">{stats.abilitiesUnlocked}</div>
              <div className="text-xs md:text-sm text-green-600 font-medium">Abilities</div>
            </div>

            <div 
              className="p-4 md:p-6 rounded-[20px] text-center"
              style={{
                background: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)',
                boxShadow: '8px 8px 16px rgba(240, 170, 200, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9), inset 2px 2px 4px rgba(255, 255, 255, 0.3)'
              }}
            >
              <MessageSquare className="w-6 h-6 md:w-8 md:h-8 text-pink-600 mx-auto mb-2 md:mb-3" />
              <div className="text-2xl md:text-4xl font-bold text-pink-800 mb-1">{stats.totalMessages}</div>
              <div className="text-xs md:text-sm text-pink-600 font-medium">Messages</div>
            </div>
          </div>
        </motion.div>

        {/* Achievements Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 md:mb-6 px-2">
            <h2 className="text-xl md:text-2xl font-bold text-purple-800 flex items-center gap-2">
              <Award className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
              Achievements
            </h2>
            <div className="text-left sm:text-right">
              <div className="text-xl md:text-2xl font-bold text-purple-800">
                {unlockedAchievements.length} / {ACHIEVEMENTS.length}
              </div>
              <div className="text-xs md:text-sm text-purple-600">Unlocked</div>
            </div>
          </div>

          <Card className="p-4 md:p-6 mb-4 md:mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs md:text-sm font-medium text-purple-700">Achievement Progress</span>
              <span className="text-xs md:text-sm font-bold text-purple-800">{Math.round(achievementPercentage)}%</span>
            </div>
            <div 
              className="h-2 md:h-3 rounded-full overflow-hidden relative"
              style={{
                background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                boxShadow: 'inset 4px 4px 8px rgba(209, 196, 233, 0.4), inset -2px -2px 6px rgba(255, 255, 255, 0.8)'
              }}
            >
              <div 
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${achievementPercentage}%`,
                  background: 'linear-gradient(90deg, #fbbf24, #f59e0b)',
                  boxShadow: '4px 4px 8px rgba(251, 191, 36, 0.3)'
                }}
              />
            </div>
          </Card>

          {/* Unlocked Achievements */}
          {unlockedAchievements.length > 0 && (
            <div className="mb-6 md:mb-8">
              <h3 className="text-lg md:text-xl font-bold text-purple-800 mb-3 md:mb-4 px-2">Unlocked</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                {unlockedAchievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + index * 0.05 }}
                    className="p-4 md:p-5 rounded-[18px]"
                    style={{
                      background: achievement.color.bg,
                      boxShadow: `6px 6px 12px ${achievement.color.shadow}, -6px -6px 12px rgba(255, 255, 255, 0.8), inset 1px 1px 2px rgba(255, 255, 255, 0.3)`
                    }}
                  >
                    <div className="flex items-start gap-3">
                      <div 
                        className="w-10 h-10 md:w-12 md:h-12 rounded-[14px] flex items-center justify-center flex-shrink-0"
                        style={{
                          background: 'rgba(255, 255, 255, 0.5)',
                          boxShadow: '4px 4px 8px rgba(0, 0, 0, 0.1), inset 2px 2px 4px rgba(255, 255, 255, 0.5)'
                        }}
                      >
                        <achievement.icon className="w-5 h-5 md:w-6 md:h-6 text-purple-700" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm md:text-base text-purple-800 mb-1 break-words">{achievement.title}</h4>
                        <p className="text-xs md:text-sm text-purple-700 break-words">{achievement.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Locked Achievements */}
          {lockedAchievements.length > 0 && (
            <div>
              <h3 className="text-lg md:text-xl font-bold text-purple-800 mb-3 md:mb-4 flex items-center gap-2 px-2">
                <Lock className="w-4 h-4 md:w-5 md:h-5 text-purple-600" />
                Locked Achievements
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                {lockedAchievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + index * 0.05 }}
                    className="p-4 md:p-5 rounded-[18px] opacity-60"
                    style={{
                      background: 'linear-gradient(145deg, #e8e6f7, #f5f3ff)',
                      boxShadow: 'inset 4px 4px 8px rgba(209, 196, 233, 0.3), inset -2px -2px 6px rgba(255, 255, 255, 0.7)'
                    }}
                  >
                    <div className="flex items-start gap-3">
                      <div 
                        className="w-10 h-10 md:w-12 md:h-12 rounded-[14px] flex items-center justify-center flex-shrink-0"
                        style={{
                          background: 'rgba(209, 196, 233, 0.3)',
                          boxShadow: 'inset 2px 2px 4px rgba(180, 170, 210, 0.4)'
                        }}
                      >
                        <Lock className="w-5 h-5 md:w-6 md:h-6 text-purple-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm md:text-base text-purple-600 mb-1 break-words">{achievement.title}</h4>
                        <p className="text-xs md:text-sm text-purple-500 break-words">{achievement.description}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}