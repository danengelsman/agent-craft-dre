import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Trophy, Lock, CheckCircle, Star, Sparkles, ArrowRight, Zap, Clock, Gift, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Learn() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [completionModal, setCompletionModal] = useState(null);
  const [lessonStartTime, setLessonStartTime] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existingProgress = await base44.entities.UserProgress.filter({ user_email: user.email });
      if (existingProgress.length > 0) {
        return existingProgress[0];
      }
      // Create progress if it doesn't exist
      return await base44.entities.UserProgress.create({
        user_email: user.email,
        level: 1,
        xp: 0,
        unlocked_abilities: ["basic_chat"],
        completed_lessons: []
      });
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
    staleTime: 30000,
  });

  const { data: lessons = [] } = useQuery({
    queryKey: ['lessons'],
    queryFn: () => base44.entities.Lesson.list('order'),
    initialData: [],
    retry: 1,
    staleTime: 60000,
  });

  const completeLessonMutation = useMutation({
    mutationFn: async ({ lessonId, xpReward, unlocksAbility, bonusXP }) => {
      if (!progress || !progress.id) {
        throw new Error("User progress not found");
      }

      const totalXP = xpReward + bonusXP;
      const newXp = (progress?.xp || 0) + totalXP;
      const newLevel = Math.floor(newXp / 200) + 1;
      const updatedLessons = [...(progress?.completed_lessons || []), lessonId];
      const updatedAbilities = unlocksAbility 
        ? [...new Set([...(progress?.unlocked_abilities || []), unlocksAbility])]
        : progress?.unlocked_abilities || [];

      await base44.entities.UserProgress.update(progress.id, {
        xp: newXp,
        level: newLevel,
        completed_lessons: updatedLessons,
        unlocked_abilities: updatedAbilities,
      });

      return { xpReward, bonusXP, totalXP, unlocksAbility, newLevel };
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
      
      const currentLessonIndex = lessons.findIndex(l => l.id === variables.lessonId);
      const nextLesson = currentLessonIndex >= 0 && currentLessonIndex < lessons.length - 1 
        ? lessons[currentLessonIndex + 1] 
        : null;
      
      setCompletionModal({
        ...data,
        nextLesson,
        currentLesson: lessons.find(l => l.id === variables.lessonId)
      });
      setSelectedLesson(null);
    },
    retry: 1,
  });

  const handleCompleteLesson = async (lesson) => {
    if (!progress || !progress.id) {
      alert("Please wait for your profile to load before completing lessons.");
      return;
    }

    const completionTime = Date.now() - lessonStartTime;
    const completionMinutes = completionTime / (1000 * 60);
    
    let bonusXP = 0;
    const completedLessons = progress?.completed_lessons || [];
    
    const previousLessons = lessons.filter(l => l.order < lesson.order);
    const allPreviousCompleted = previousLessons.every(l => completedLessons.includes(l.id));
    if (allPreviousCompleted && previousLessons.length > 0) {
      bonusXP += 50;
    }
    
    if (completionMinutes < 3) {
      bonusXP += 30;
    }
    
    await completeLessonMutation.mutateAsync({
      lessonId: lesson.id,
      xpReward: lesson.xp_reward,
      unlocksAbility: lesson.unlocks_ability,
      bonusXP,
    });
  };

  const handleOpenLesson = (lesson) => {
    setSelectedLesson(lesson);
    setLessonStartTime(Date.now());
  };

  const completedLessons = progress?.completed_lessons || [];
  const userLevel = progress?.level || 1;

  const getLessonStatus = (lesson) => {
    const isCompleted = completedLessons.includes(lesson.id);
    const isLevelLocked = lesson.level_required > userLevel;
    
    const previousLessons = lessons.filter(l => l.order < lesson.order);
    const hasPrerequisites = previousLessons.length > 0;
    const prerequisitesCompleted = previousLessons.every(l => completedLessons.includes(l.id));
    
    return {
      isCompleted,
      isLevelLocked,
      isPrerequisiteLocked: hasPrerequisites && !prerequisitesCompleted,
      canStart: !isCompleted && !isLevelLocked && (!hasPrerequisites || prerequisitesCompleted),
      nextInSequence: !isCompleted && prerequisitesCompleted && !isLevelLocked && previousLessons.length === completedLessons.length,
      missingPrerequisites: hasPrerequisites ? previousLessons.filter(l => !completedLessons.includes(l.id)) : []
    };
  };

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
              <BookOpen className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                Learning Center
              </h1>
              <p className="text-gray-600">Master new skills, unlock new abilities</p>
            </div>
          </div>
        </motion.div>

        {progress && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <div className="premium-card p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Trophy className="w-8 h-8 text-gray-900" />
                  <div>
                    <div className="text-2xl font-bold text-gray-900">Level {progress.level}</div>
                    <div className="text-sm text-gray-600">
                      {completedLessons.length} / {lessons.length} lessons completed
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-gray-900">{progress.xp} XP</div>
                  <div className="text-sm text-gray-600">{200 - (progress.xp % 200)} XP to next level</div>
                </div>
              </div>
              <Progress 
                value={((progress.xp % 200) / 200) * 100} 
                className="h-2"
              />
            </div>
          </motion.div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {lessons.map((lesson, index) => {
              const status = getLessonStatus(lesson);

              return (
                <motion.div
                  key={lesson.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div
                    className={`premium-card overflow-hidden ${
                      status.canStart ? 'cursor-pointer hover:shadow-lg' : ''
                    } transition-all duration-300 ${
                      status.nextInSequence ? 'ring-2 ring-gray-900' : ''
                    }`}
                    onClick={() => status.canStart && handleOpenLesson(lesson)}
                    style={{
                      opacity: status.isLevelLocked || status.isPrerequisiteLocked ? 0.6 : 1
                    }}
                  >
                    {status.nextInSequence && (
                      <div className="px-3 py-1 text-xs font-bold bg-gray-900 text-white flex items-center gap-1">
                        <Zap className="w-3 h-3" />
                        NEXT UP
                      </div>
                    )}

                    <div className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          status.isCompleted ? 'bg-gray-100' :
                          status.isLevelLocked || status.isPrerequisiteLocked ? 'bg-gray-50' :
                          'bg-gray-100'
                        }`}>
                          {status.isCompleted ? (
                            <CheckCircle className="w-6 h-6 text-gray-900" />
                          ) : status.isLevelLocked || status.isPrerequisiteLocked ? (
                            <Lock className="w-6 h-6 text-gray-400" />
                          ) : (
                            <Star className="w-6 h-6 text-gray-900" />
                          )}
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-gray-900 flex items-center gap-1">
                            <Zap className="w-4 h-4 text-gray-600" />
                            +{lesson.xp_reward} XP
                          </div>
                          {lesson.unlocks_ability && (
                            <div className="text-xs text-gray-600 font-medium mt-1 flex items-center gap-1">
                              <Gift className="w-3 h-3" />
                              Unlocks ability
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <h3 className="text-lg font-bold text-gray-900 mb-2">{lesson.title}</h3>
                      <p className="text-gray-600 text-sm mb-3">
                        {lesson.description}
                      </p>

                      <div className="space-y-2">
                        {status.isCompleted && (
                          <div className="text-sm text-green-600 font-medium flex items-center gap-1">
                            <CheckCircle className="w-4 h-4" />
                            Completed
                          </div>
                        )}
                        
                        {status.isLevelLocked && (
                          <div className="text-sm text-purple-500 font-medium flex items-center gap-1">
                            <Lock className="w-4 h-4" />
                            Requires Level {lesson.level_required}
                          </div>
                        )}
                        
                        {status.isPrerequisiteLocked && (
                          <div className="text-sm text-purple-500 font-medium">
                            <div className="flex items-center gap-1 mb-1">
                              <Lock className="w-4 h-4" />
                              Complete previous lessons first
                            </div>
                            <div className="text-xs text-purple-400 ml-5">
                              {status.missingPrerequisites.map(l => l.title).join(', ')}
                            </div>
                          </div>
                        )}

                        {status.canStart && !status.isCompleted && (
                          <div className="text-sm text-blue-600 font-medium flex items-center gap-1">
                            <TrendingUp className="w-4 h-4" />
                            Ready to start
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Lesson Detail Modal */}
        <AnimatePresence>
          {selectedLesson && (
            <>
              {/* Premium Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50"
                style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                  backdropFilter: 'blur(40px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                }}
                onClick={() => setSelectedLesson(null)}
              />
              
              {/* Modal Content */}
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
                <motion.div
                  initial={{ scale: 0.95, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.95, opacity: 0, y: 20 }}
                  transition={{ type: "spring", damping: 30, stiffness: 300 }}
                  className="w-full max-w-2xl max-h-[85vh] overflow-y-auto pointer-events-auto rounded-[32px] shadow-2xl"
                  style={{
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdropFilter: 'blur(40px) saturate(180%)',
                    WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), 0 0 1px rgba(0, 0, 0, 0.1)',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="p-8 md:p-10">
                    {/* Header */}
                    <div className="flex items-start gap-5 mb-8">
                      <div 
                        className="w-20 h-20 rounded-[24px] flex items-center justify-center flex-shrink-0"
                        style={{
                          background: 'linear-gradient(145deg, #667eea 0%, #764ba2 100%)',
                          boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3), 0 2px 8px rgba(0, 0, 0, 0.1)',
                        }}
                      >
                        <Sparkles className="w-10 h-10 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h2 className="text-3xl md:text-4xl font-bold mb-3 text-gray-900 tracking-tight">
                          {selectedLesson.title}
                        </h2>
                        <p className="text-gray-600 text-base leading-relaxed">
                          {selectedLesson.description}
                        </p>
                      </div>
                    </div>

                    {/* Content Section */}
                    <div className="mb-8">
                      <div 
                        className="p-6 md:p-8 rounded-[24px]"
                        style={{
                          background: 'linear-gradient(145deg, rgba(249, 250, 251, 0.8), rgba(243, 244, 246, 0.8))',
                          border: '1px solid rgba(0, 0, 0, 0.05)',
                          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.04)',
                        }}
                      >
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
                          <BookOpen className="w-5 h-5 text-blue-500" />
                          What You'll Learn
                        </h3>
                        <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                          {selectedLesson.content}
                        </p>
                      </div>
                    </div>

                    {/* Info Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                      <div 
                        className="p-5 rounded-[20px]"
                        style={{
                          background: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
                          border: '1px solid rgba(245, 158, 11, 0.2)',
                          boxShadow: '0 4px 16px rgba(245, 158, 11, 0.1)',
                        }}
                      >
                        <div className="text-xs text-amber-800 mb-2 font-semibold uppercase tracking-wider">
                          Core Concept
                        </div>
                        <div className="font-bold text-amber-900 text-base leading-tight">
                          {selectedLesson.concept}
                        </div>
                      </div>
                      
                      <div 
                        className="p-5 rounded-[20px] flex flex-col justify-center"
                        style={{
                          background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
                          border: '1px solid rgba(59, 130, 246, 0.2)',
                          boxShadow: '0 4px 16px rgba(59, 130, 246, 0.1)',
                        }}
                      >
                        <div className="text-xs text-blue-800 mb-3 font-semibold uppercase tracking-wider">
                          Base Reward
                        </div>
                        <div 
                          className="inline-flex items-center gap-2 px-5 py-3 rounded-[16px] self-start"
                          style={{
                            background: 'linear-gradient(135deg, #f5f5f5 0%, #e5e5e5 50%, #f5f5f5 100%)',
                            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15), inset 0 1px 3px rgba(255, 255, 255, 0.9)',
                            border: '2px solid rgba(255, 255, 255, 0.8)',
                          }}
                        >
                          <Zap className="w-5 h-5 text-amber-500" />
                          <span className="font-black text-2xl text-gray-900">+{selectedLesson.xp_reward}</span>
                          <span className="font-bold text-base text-gray-700">XP</span>
                        </div>
                      </div>
                    </div>

                    {/* Bonus Section */}
                    <div 
                      className="mb-8 p-6 rounded-[20px]"
                      style={{
                        background: 'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 100%)',
                        border: '1px solid rgba(236, 72, 153, 0.2)',
                        boxShadow: '0 4px 16px rgba(236, 72, 153, 0.1)',
                      }}
                    >
                      <div className="flex items-center gap-2 mb-4 text-pink-900">
                        <Gift className="w-5 h-5" />
                        <h4 className="font-bold text-base">Bonus XP Opportunities</h4>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 flex-1">
                            <TrendingUp className="w-5 h-5 text-pink-700 flex-shrink-0" />
                            <span className="text-sm text-pink-800">Complete lessons in order</span>
                          </div>
                          <div 
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] flex-shrink-0"
                            style={{
                              background: 'linear-gradient(135deg, #f5f5f5 0%, #e5e5e5 50%, #f5f5f5 100%)',
                              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)',
                              border: '1.5px solid rgba(255, 255, 255, 0.8)',
                            }}
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-500" />
                            <span className="font-black text-sm text-gray-900">+50</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3 flex-1">
                            <Clock className="w-5 h-5 text-pink-700 flex-shrink-0" />
                            <span className="text-sm text-pink-800">Complete in under 3 minutes</span>
                          </div>
                          <div 
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] flex-shrink-0"
                            style={{
                              background: 'linear-gradient(135deg, #f5f5f5 0%, #e5e5e5 50%, #f5f5f5 100%)',
                              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1), inset 0 1px 2px rgba(255, 255, 255, 0.9)',
                              border: '1.5px solid rgba(255, 255, 255, 0.8)',
                            }}
                          >
                            <Zap className="w-3.5 h-3.5 text-amber-500" />
                            <span className="font-black text-sm text-gray-900">+30</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-col-reverse sm:flex-row gap-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedLesson(null);
                        }}
                        className="flex-1 h-14 px-6 rounded-[16px] font-semibold text-gray-700 transition-all active:scale-[0.98]"
                        style={{
                          background: 'rgba(0, 0, 0, 0.04)',
                          border: '1px solid rgba(0, 0, 0, 0.06)',
                        }}
                      >
                        Close
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!completedLessons.includes(selectedLesson.id) && progress && progress.id) {
                            handleCompleteLesson(selectedLesson);
                          }
                        }}
                        disabled={completedLessons.includes(selectedLesson.id) || !progress || !progress.id}
                        className="flex-1 h-14 px-6 rounded-[16px] font-semibold text-white transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
                        style={{
                          background: completedLessons.includes(selectedLesson.id) || !progress || !progress.id
                            ? 'rgba(0, 0, 0, 0.1)'
                            : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          boxShadow: completedLessons.includes(selectedLesson.id) || !progress || !progress.id
                            ? 'none'
                            : '0 4px 16px rgba(102, 126, 234, 0.4), 0 2px 8px rgba(0, 0, 0, 0.1)',
                          border: completedLessons.includes(selectedLesson.id) || !progress || !progress.id
                            ? '1px solid rgba(0, 0, 0, 0.06)'
                            : 'none',
                        }}
                      >
                        {completedLessons.includes(selectedLesson.id) 
                          ? '✓ Completed' 
                          : !progress || !progress.id 
                          ? 'Loading...' 
                          : 'Complete Lesson'}
                      </button>
                    </div>
                  </div>
                </motion.div>
              </div>
            </>
          )}
        </AnimatePresence>

        {/* Completion Modal */}
        <AnimatePresence>
          {completionModal && (
            <>
              {/* Premium Backdrop */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-50"
                style={{
                  background: 'rgba(0, 0, 0, 0.4)',
                  backdropFilter: 'blur(40px) saturate(180%)',
                  WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                }}
                onClick={() => setCompletionModal(null)}
              />
              
              {/* Modal Content */}
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
                <motion.div
                  initial={{ scale: 0.9, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.9, opacity: 0, y: 20 }}
                  transition={{ type: "spring", damping: 25, stiffness: 300 }}
                  className="w-full max-w-lg pointer-events-auto rounded-[32px] shadow-2xl overflow-hidden"
                  style={{
                    background: 'rgba(255, 255, 255, 0.98)',
                    backdropFilter: 'blur(40px) saturate(180%)',
                    WebkitBackdropFilter: 'blur(40px) saturate(180%)',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3), 0 0 1px rgba(0, 0, 0, 0.1)',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="p-8 md:p-10 text-center">
                    {/* Trophy Icon */}
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", damping: 15 }}
                      className="w-24 h-24 rounded-full mx-auto mb-8 relative"
                      style={{
                        background: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #d97706 100%)',
                        boxShadow: '0 8px 24px rgba(251, 191, 36, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -2px 8px rgba(0, 0, 0, 0.2)',
                        border: '3px solid rgba(255, 255, 255, 0.3)',
                      }}
                    >
                      <div className="absolute inset-0 rounded-full" style={{
                        background: 'radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.3) 0%, transparent 60%)',
                      }} />
                      <Trophy className="w-12 h-12 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" style={{
                        filter: 'drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))',
                      }} />
                    </motion.div>

                    {/* Title */}
                    <h2 className="text-3xl md:text-4xl font-bold mb-3 text-gray-900 tracking-tight">
                      Lesson Complete!
                    </h2>
                    <p className="text-gray-600 mb-8 text-base leading-relaxed">
                      {completionModal.currentLesson?.title}
                    </p>

                    {/* XP Badge - Realistic Metal Design */}
                    <motion.div
                      initial={{ scale: 0, rotate: 360 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.4, type: "spring", damping: 20 }}
                      className="mb-8"
                    >
                      <div 
                        className="inline-flex items-center gap-3 px-8 py-6 rounded-[24px] relative overflow-hidden"
                        style={{
                          background: 'linear-gradient(145deg, #e8e8e8 0%, #f5f5f5 25%, #ffffff 50%, #f5f5f5 75%, #e8e8e8 100%)',
                          boxShadow: `
                            0 1px 0 rgba(255, 255, 255, 0.9),
                            0 -1px 0 rgba(0, 0, 0, 0.1),
                            0 8px 24px rgba(0, 0, 0, 0.15),
                            inset 0 1px 3px rgba(255, 255, 255, 0.9),
                            inset 0 -1px 2px rgba(0, 0, 0, 0.15),
                            inset 0 0 20px rgba(0, 0, 0, 0.05)
                          `,
                          border: '1px solid rgba(0, 0, 0, 0.08)',
                        }}
                      >
                        {/* Subtle shine effect */}
                        <div 
                          className="absolute inset-0 opacity-30"
                          style={{
                            background: 'linear-gradient(135deg, transparent 0%, transparent 40%, rgba(255, 255, 255, 0.8) 50%, transparent 60%, transparent 100%)',
                          }}
                        />
                        
                        {/* Lightning bolt icon */}
                        <div className="relative">
                          <Zap 
                            className="w-8 h-8"
                            style={{
                              fill: '#fbbf24',
                              color: '#f59e0b',
                              filter: 'drop-shadow(0 2px 4px rgba(251, 191, 36, 0.4))',
                            }}
                          />
                        </div>
                        
                        {/* XP Value with embossed effect */}
                        <div className="relative flex items-baseline gap-1.5">
                          <span 
                            className="font-black text-5xl relative"
                            style={{
                              color: '#1f2937',
                              textShadow: `
                                0 1px 0 rgba(255, 255, 255, 0.9),
                                0 2px 3px rgba(0, 0, 0, 0.15),
                                0 -1px 0 rgba(0, 0, 0, 0.1)
                              `,
                              letterSpacing: '-0.02em',
                            }}
                          >
                            +{completionModal.totalXP}
                          </span>
                          <span 
                            className="font-bold text-xl"
                            style={{
                              color: '#4b5563',
                              textShadow: `
                                0 1px 0 rgba(255, 255, 255, 0.8),
                                0 1px 2px rgba(0, 0, 0, 0.1)
                              `,
                            }}
                          >
                            XP
                          </span>
                        </div>
                      </div>
                      
                      {/* Breakdown text */}
                      <div className="mt-4 text-sm text-gray-600">
                        Base: {completionModal.xpReward} XP
                        {completionModal.bonusXP > 0 && (
                          <span className="ml-2 text-amber-600 font-semibold">
                            • Bonus: +{completionModal.bonusXP} XP
                          </span>
                        )}
                      </div>
                    </motion.div>

                    {/* Bonus Badges */}
                    <div className="space-y-3 mb-8">
                      {completionModal.unlocksAbility && (
                        <motion.div
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.6 }}
                          className="p-5 rounded-[20px]"
                          style={{
                            background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
                            border: '1px solid rgba(59, 130, 246, 0.2)',
                            boxShadow: '0 4px 12px rgba(59, 130, 246, 0.15)',
                          }}
                        >
                          <div className="flex items-center justify-center gap-2 mb-2">
                            <Gift className="w-5 h-5 text-blue-600" />
                            <span className="font-bold text-blue-900">New Ability Unlocked!</span>
                          </div>
                          <div className="text-blue-700 capitalize font-medium">
                            {completionModal.unlocksAbility.replace('_', ' ')}
                          </div>
                        </motion.div>
                      )}

                      {completionModal.bonusXP > 0 && (
                        <motion.div
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.7 }}
                          className="p-4 rounded-[18px]"
                          style={{
                            background: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
                            border: '1px solid rgba(245, 158, 11, 0.2)',
                            boxShadow: '0 4px 12px rgba(245, 158, 11, 0.12)',
                          }}
                        >
                          <div className="font-bold text-amber-900 mb-1 flex items-center justify-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            Bonus Earned!
                          </div>
                          <div className="text-amber-700 text-sm">
                            {completionModal.bonusXP >= 50 && "✨ Completed in sequence"}
                            {completionModal.bonusXP >= 30 && completionModal.bonusXP < 50 && "⚡ Lightning fast!"}
                            {completionModal.bonusXP >= 80 && " • ⚡ Lightning fast!"}
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* Next Lesson Card */}
                    {completionModal.nextLesson && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 }}
                        className="mb-8 p-6 rounded-[24px] text-left"
                        style={{
                          background: 'linear-gradient(145deg, rgba(249, 250, 251, 0.8), rgba(243, 244, 246, 0.8))',
                          border: '1px solid rgba(0, 0, 0, 0.06)',
                          boxShadow: '0 4px 16px rgba(0, 0, 0, 0.04)',
                        }}
                      >
                        <div className="flex items-center gap-2 mb-3 text-gray-700">
                          <ArrowRight className="w-5 h-5" />
                          <span className="font-bold text-base">Up Next</span>
                        </div>
                        <div className="text-gray-900 font-semibold mb-1">
                          {completionModal.nextLesson.title}
                        </div>
                        <div className="text-gray-600 text-sm mb-4">
                          {completionModal.nextLesson.description}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setCompletionModal(null);
                            handleOpenLesson(completionModal.nextLesson);
                          }}
                          className="w-full h-12 px-6 rounded-[16px] font-semibold text-white transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                          style={{
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                            boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3), 0 1px 3px rgba(0, 0, 0, 0.1)',
                          }}
                        >
                          Continue Learning
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </motion.div>
                    )}

                    {/* Close Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setCompletionModal(null);
                      }}
                      className="w-full h-12 px-6 rounded-[16px] font-semibold text-gray-700 transition-all active:scale-[0.98]"
                      style={{
                        background: 'rgba(0, 0, 0, 0.03)',
                        border: '1px solid rgba(0, 0, 0, 0.06)',
                      }}
                    >
                      Back to Lessons
                    </button>
                  </div>
                </motion.div>
              </div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}