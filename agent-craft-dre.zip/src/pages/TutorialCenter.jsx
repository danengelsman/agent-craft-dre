import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { PageShell } from "@/components/ui/PageShell";
import { 
  BookOpen, Play, Check, Lock, Clock, Star, 
  ChevronRight, ArrowRight, Sparkles, Store,
  DollarSign, GitBranch, Key, X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const ICON_MAP = {
  Sparkles: Sparkles,
  Store: Store,
  DollarSign: DollarSign,
  GitBranch: GitBranch,
  Key: Key,
  BookOpen: BookOpen
};

export default function TutorialCenter() {
  const [user, setUser] = useState(null);
  const [selectedTutorial, setSelectedTutorial] = useState(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: tutorials = [] } = useQuery({
    queryKey: ['tutorials'],
    queryFn: () => base44.entities.Tutorial.list('order'),
    staleTime: 300000,
  });

  const { data: userProgress = [] } = useQuery({
    queryKey: ['tutorialProgress', user?.email],
    queryFn: () => base44.entities.UserTutorialProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email,
    staleTime: 60000,
  });

  const { data: userProgressData } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const progress = await base44.entities.UserProgress.filter({ user_email: user.email });
      return progress[0] || { level: 1, xp: 0, lessons_completed: 0 };
    },
    enabled: !!user?.email,
  });

  const completeTutorialMutation = useMutation({
    mutationFn: async (tutorial) => {
      // Check if already completed
      const existing = userProgress.find(p => p.tutorial_id === tutorial.id);
      if (existing?.completed) return existing;

      // Mark as completed
      if (existing) {
        await base44.entities.UserTutorialProgress.update(existing.id, {
          completed: true,
          completed_at: new Date().toISOString(),
          current_step: tutorial.steps.length
        });
      } else {
        await base44.entities.UserTutorialProgress.create({
          user_email: user.email,
          tutorial_id: tutorial.id,
          completed: true,
          completed_at: new Date().toISOString(),
          current_step: tutorial.steps.length
        });
      }

      // Award XP
      if (userProgressData) {
        const newXp = (userProgressData.xp || 0) + tutorial.completion_reward_xp;
        const newLevel = Math.floor(newXp / 500) + 1;
        await base44.entities.UserProgress.update(userProgressData.id, {
          xp: newXp,
          level: newLevel,
          lessons_completed: (userProgressData.lessons_completed || 0) + 1
        });
      }

      return tutorial;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutorialProgress'] });
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
    },
  });

  const getProgress = (tutorialId) => {
    return userProgress.find(p => p.tutorial_id === tutorialId);
  };

  const isCompleted = (tutorialId) => {
    const progress = getProgress(tutorialId);
    return progress?.completed === true;
  };

  const getCategoryColor = (category) => {
    const colors = {
      onboarding: "from-purple-500 to-pink-500",
      marketplace: "from-green-500 to-teal-500",
      advanced: "from-amber-500 to-orange-500",
      community: "from-blue-500 to-cyan-500",
      tips: "from-indigo-500 to-violet-500"
    };
    return colors[category] || "from-gray-500 to-gray-700";
  };

  const handleStartTutorial = (tutorial) => {
    setSelectedTutorial(tutorial);
    const progress = getProgress(tutorial.id);
    setCurrentStepIndex(progress?.current_step || 0);
  };

  const handleNextStep = async () => {
    if (currentStepIndex < selectedTutorial.steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
      
      // Save progress
      const existing = getProgress(selectedTutorial.id);
      if (existing) {
        await base44.entities.UserTutorialProgress.update(existing.id, {
          current_step: currentStepIndex + 1
        });
      } else {
        await base44.entities.UserTutorialProgress.create({
          user_email: user.email,
          tutorial_id: selectedTutorial.id,
          current_step: currentStepIndex + 1,
          completed: false
        });
      }
    } else {
      // Complete tutorial
      await completeTutorialMutation.mutateAsync(selectedTutorial);
      setSelectedTutorial(null);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const completedCount = userProgress.filter(p => p.completed).length;
  const totalXpEarned = tutorials
    .filter(t => isCompleted(t.id))
    .reduce((sum, t) => sum + t.completion_reward_xp, 0);

  return (
    <PageShell>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
              <BookOpen className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">Tutorial Center</h1>
              <p className="ui-muted">Step-by-step guides to master AgentCraft</p>
            </div>
          </div>
        </div>

        {/* Progress Summary */}
        <Card className="p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-lg">Your Progress</h3>
              <p className="ui-muted">
                {completedCount} of {tutorials.length} tutorials completed
              </p>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold">{totalXpEarned}</div>
                <div className="text-xs ui-muted">XP Earned</div>
              </div>
              <div className="w-32 bg-gray-100 rounded-full h-2 border border-gray-200">
                <div 
                  className="bg-gray-900 h-full rounded-full transition-all"
                  style={{ width: `${(completedCount / tutorials.length) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Tutorial Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tutorials.map((tutorial, index) => {
            const completed = isCompleted(tutorial.id);
            const Icon = ICON_MAP[tutorial.icon] || BookOpen;
            
            return (
              <Card key={tutorial.id} className="p-6 h-full flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                    <Icon className="w-6 h-6 text-gray-700" />
                  </div>
                    {completed && (
                      <div className="flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-semibold border border-green-200">
                        <Check className="w-3 h-3" />
                        Completed
                      </div>
                    )}
                    {tutorial.is_required && !completed && (
                      <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold border border-amber-200">
                        Required
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-lg mb-2">{tutorial.title}</h3>
                  <p className="text-sm ui-muted mb-4 flex-1">{tutorial.description}</p>

                  <div className="flex items-center gap-4 text-xs ui-muted mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {tutorial.estimated_time} min
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3" />
                      +{tutorial.completion_reward_xp} XP
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      tutorial.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                      tutorial.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {tutorial.difficulty}
                    </span>
                  </div>

                  <Button
                    onClick={() => handleStartTutorial(tutorial)}
                    variant={completed ? "secondary" : "primary"}
                    className="w-full"
                  >
                    {completed ? (
                      <>Review Tutorial</>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Start Tutorial
                      </>
                    )}
                  </Button>
              </Card>
            );
          })}
        </div>

        {/* Tutorial Modal */}
        <AnimatePresence>
          {selectedTutorial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedTutorial(null)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Header */}
                <div className="p-6 bg-gray-900">
                  <div className="flex items-start justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-white mb-1">
                        {selectedTutorial.title}
                      </h2>
                      <p className="text-white/80 text-sm">
                        Step {currentStepIndex + 1} of {selectedTutorial.steps.length}
                      </p>
                    </div>
                    <button
                      onClick={() => setSelectedTutorial(null)}
                      className="text-white/80 hover:text-white"
                    >
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="mt-4 bg-white/30 rounded-full h-2">
                    <div 
                      className="bg-white h-2 rounded-full transition-all"
                      style={{ width: `${((currentStepIndex + 1) / selectedTutorial.steps.length) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={currentStepIndex}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                    >
                      <h3 className="text-xl font-bold mb-4">
                        {selectedTutorial.steps[currentStepIndex].title}
                      </h3>
                      <p className="ui-muted leading-relaxed mb-6">
                        {selectedTutorial.steps[currentStepIndex].content}
                      </p>

                      {selectedTutorial.steps[currentStepIndex].action_required && (
                        <Card className="p-4 bg-amber-50 border-amber-200">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0">
                              <ChevronRight className="w-5 h-5 text-amber-600" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-amber-900 mb-1">Action Required</h4>
                              <p className="text-sm text-amber-700">
                                {selectedTutorial.steps[currentStepIndex].action_description}
                              </p>
                            </div>
                          </div>
                        </Card>
                      )}
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Footer */}
                <div className="p-6 border-t flex justify-between" style={{ borderColor: 'var(--border-subtle)' }}>
                  <Button
                    onClick={handlePrevStep}
                    disabled={currentStepIndex === 0}
                    variant="secondary"
                  >
                    Previous
                  </Button>
                  <Button
                    onClick={handleNextStep}
                    variant="primary"
                  >
                    {currentStepIndex === selectedTutorial.steps.length - 1 ? (
                      <>
                        Complete
                        <Check className="w-4 h-4 ml-2" />
                      </>
                    ) : (
                      <>
                        Next
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageShell>
  );
}