import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card, CardContent } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { PageShell } from "@/components/ui/PageShell";
import { Textarea } from "@/components/ui/Textarea";
import { Label } from "@/components/ui/label";
import { Sparkles, Save, MessageSquare, Loader2, Wand2, Lock, Heart, Crown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import AbilityPuzzlePiece from "../components/builder/AbilityPuzzlePiece";
import AgentPreview from "../components/builder/AgentPreview";
import AdminSimulationControls from "../components/AdminSimulationControls";
import { usePlanAccess } from "../components/PlanAccessProvider";
import HelpTooltip from "@/components/ui/HelpTooltip";
import ExplanationCard from "@/components/ui/ExplanationCard";

const ABILITIES = [
  {
    id: "basic_chat",
    name: "Chat",
    description: "Your agent can have conversations",
    icon: MessageSquare,
    color: "purple",
    levelRequired: 1,
    category: "core"
  },
  {
    id: "memory",
    name: "Memory",
    description: "Remember past conversations",
    icon: "Brain",
    color: "blue",
    levelRequired: 2,
    category: "core"
  },
  {
    id: "web_search",
    name: "Web Search",
    description: "Find information on the internet",
    icon: "Search",
    color: "green",
    levelRequired: 3,
    category: "tools"
  },
  {
    id: "file_handling",
    name: "File Helper",
    description: "Work with documents and files",
    icon: "FileText",
    color: "amber",
    levelRequired: 4,
    category: "tools"
  },
  {
    id: "email_compose",
    name: "Email Composer",
    description: "Draft and send professional emails",
    icon: "Mail",
    color: "indigo",
    levelRequired: 5,
    category: "tools"
  },
  {
    id: "personality",
    name: "Personality",
    description: "Give your agent unique character",
    icon: "Heart",
    color: "pink",
    levelRequired: 6,
    category: "advanced"
  },
  {
    id: "image_gen",
    name: "Image Creator",
    description: "Generate images from descriptions",
    icon: "Image",
    color: "coral",
    levelRequired: 7,
    category: "advanced"
  }
];

export default function Builder() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [agentName, setAgentName] = useState("");
  const [agentDescription, setAgentDescription] = useState("");
  const [agentPersonality, setAgentPersonality] = useState("");
  const [selectedAbilities, setSelectedAbilities] = useState(["basic_chat"]);
  const [isSaving, setIsSaving] = useState(false);
  const queryClient = useQueryClient();
  
  const { hasAbility, tier, isAdmin, isSimulating } = usePlanAccess();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: progress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existingProgress = await base44.entities.UserProgress.filter({ user_email: user.email });
      return existingProgress[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
    staleTime: 30000,
  });

  const saveAgentMutation = useMutation({
    mutationFn: async (agentData) => {
      if (!user?.email) throw new Error("User not logged in");
      
      const agent = await base44.entities.Agent.create(agentData);
      
      const moderationCheck = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a content moderation AI. Analyze this AI agent for any inappropriate, harmful, or spam content.
        
Agent Name: ${agentData.name}
Agent Description: ${agentData.description}
Agent Personality: ${agentData.personality || 'None'}

Score this content from 0-100 where:
- 0-30: Safe, appropriate content
- 31-70: Potentially problematic, needs human review
- 71-100: Clearly inappropriate, should be blocked

Consider:
1. Inappropriate language or hate speech
2. Spam or promotional content
3. Misleading or deceptive descriptions
4. Sexual, violent, or harmful content
5. Off-topic or low-quality content

Return ONLY a JSON object with your analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            score: {type: "number"},
            reasons: {
              type: "array",
              items: {type: "string"}
            },
            decision: {
              type: "string",
              enum: ["approved", "pending_review", "blocked"]
            }
          }
        }
      });

      let status = "approved";
      let autoDecision = true;
      
      if (moderationCheck.score > 70) {
        status = "blocked";
      } else if (moderationCheck.score > 30) {
        status = "pending_review";
      }

      await base44.entities.ContentModeration.create({
        content_type: "agent",
        content_id: agent.id,
        content_preview: `${agentData.name}: ${agentData.description.substring(0, 100)}`,
        moderation_score: moderationCheck.score,
        status: status,
        auto_decision: autoDecision,
        moderation_reasons: moderationCheck.reasons || [],
        author_email: user.email
      });

      return { agent, status, score: moderationCheck.score };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['agents'] });
      
      if (data.status === "blocked") {
        alert("⚠️ Your agent was automatically blocked due to policy violations. An admin will review it. Check your profile for details.");
      } else if (data.status === "pending_review") {
        alert("⏳ Your agent is under review. It will be visible once approved by our moderation team.");
      } else {
        alert("Agent Created! 🎉");
      }
      
      setAgentName("");
      setAgentDescription("");
      setAgentPersonality("");
      setSelectedAbilities(["basic_chat"]);
    },
    retry: 1,
  });

  const toggleAbility = (abilityId) => {
    // Check if ability is allowed by plan
    if (!hasAbility(abilityId) && !selectedAbilities.includes(abilityId)) {
      return; // Can't add abilities not in plan
    }
    
    if (selectedAbilities.includes(abilityId)) {
      if (abilityId === "basic_chat") return;
      setSelectedAbilities(selectedAbilities.filter(id => id !== abilityId));
    } else {
      setSelectedAbilities([...selectedAbilities, abilityId]);
    }
  };

  const handleSave = async () => {
    if (!user) {
      alert("Please wait for the page to load");
      return;
    }

    if (!agentName || !agentDescription) {
      alert("Please give your agent a name and description");
      return;
    }

    setIsSaving(true);
    try {
      await saveAgentMutation.mutateAsync({
        name: agentName,
        description: agentDescription,
        personality: agentPersonality,
        abilities: selectedAbilities,
        color_theme: "purple",
        is_active: true,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const unlockedAbilities = progress?.unlocked_abilities || ["basic_chat"];
  const userLevel = progress?.level || 1;
  
  const personalityAbility = ABILITIES.find(a => a.id === "personality");
  const hasPersonalityUnlocked = unlockedAbilities.includes("personality");
  const hasPersonalitySelected = selectedAbilities.includes("personality");

  if (isLoadingUser) {
    return (
      <PageShell>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-gray-900" />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="max-w-7xl mx-auto">
        {/* Admin Simulation Controls */}
        {(isAdmin || isSimulating) && <AdminSimulationControls />}

        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gray-900 rounded-xl flex items-center justify-center">
              <Wand2 className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold">
                AI Helper Builder
              </h1>
              <p className="ui-muted">Pick superpowers and create your helper</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  AI Helper Details
                  <HelpTooltip>
                    Give your helper a name and tell us what it does
                  </HelpTooltip>
                </h2>
                <ExplanationCard title="Getting Started">
                  Think of this like naming a pet! Pick a friendly name and describe what tasks your AI Helper will handle for you.
                </ExplanationCard>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="name">Name Your Helper</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Study Buddy, Recipe Helper..."
                    value={agentName}
                    onChange={(e) => setAgentName(e.target.value)}
                    className="mt-2 ui-control"
                    />
                    </div>
                    <div>
                    <Label htmlFor="description">What Does It Do?</Label>
                    <Textarea
                    id="description"
                    placeholder="Describe what your agent helps with..."
                    value={agentDescription}
                    onChange={(e) => setAgentDescription(e.target.value)}
                    className="mt-2 h-24 ui-control"
                    />
                    </div>
                <div>
                  <Label htmlFor="personality">Personality (Optional)</Label>
                  <Input
                    id="personality"
                    placeholder="e.g., friendly, professional, funny..."
                    value={agentPersonality}
                    onChange={(e) => setAgentPersonality(e.target.value)}
                    className="mt-2 ui-control"
                    disabled={!hasPersonalitySelected}
                    />
                    {!hasPersonalitySelected && (
                    <div className="mt-2 p-3 rounded-lg bg-gray-50 border border-gray-200">
                      {!hasPersonalityUnlocked ? (
                        <p className="text-xs ui-muted flex items-center gap-2">
                          <Lock className="w-4 h-4" />
                          <span>
                            Unlock the <strong>Personality ability</strong> (requires Level {personalityAbility?.levelRequired}) from the Learn page, then select it below to customize your agent's personality.
                          </span>
                        </p>
                      ) : (
                        <p className="text-xs ui-muted flex items-center gap-2">
                          <Heart className="w-4 h-4" />
                          <span>
                            Click the <strong>Personality ability</strong> below to enable this field and give your agent a unique character!
                          </span>
                        </p>
                      )}
                    </div>
                    )}
                    </div>
                    </div>
                    </CardContent>
                    </Card>

            <Button
              onClick={handleSave}
              disabled={isSaving}
              variant="primary"
              className="w-full h-12 text-lg"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5 mr-2" />
                  Create AI Helper
                </>
              )}
            </Button>
            </div>

            <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                  Available Superpowers
                  <HelpTooltip>
                    Click superpowers to add them to your helper
                  </HelpTooltip>
                </h2>
                <ExplanationCard title="How Superpowers Work">
                  Each superpower gives your AI Helper a new skill. Chat is included by default. Click any unlocked superpower to add it, then click again to remove it. Complete tutorials to unlock more!
                </ExplanationCard>
                <p className="ui-muted text-sm mt-4 mb-6">
                Click to add superpowers to your helper. Complete lessons to unlock more!
              </p>

              <div className="space-y-6">
                {["core", "tools", "advanced"].map((category) => (
                  <div key={category}>
                    <h3 className="text-sm font-semibold ui-muted uppercase tracking-wider mb-3">
                      {category === "core" ? "🧩 Essential" : category === "tools" ? "🛠️ Tools" : "✨ Advanced"}
                    </h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <AnimatePresence>
                        {ABILITIES.filter(a => a.category === category).map((ability) => {
                          const isUnlocked = unlockedAbilities.includes(ability.id);
                          const isSelected = selectedAbilities.includes(ability.id);
                          const isLocked = ability.levelRequired > userLevel;
                          const isPlanLocked = !hasAbility(ability.id);

                          return (
                            <AbilityPuzzlePiece
                              key={ability.id}
                              ability={ability}
                              isUnlocked={isUnlocked && !isPlanLocked}
                              isSelected={isSelected}
                              isLocked={isLocked || isPlanLocked}
                              onClick={() => (isUnlocked && !isPlanLocked) && toggleAbility(ability.id)}
                              planLocked={isPlanLocked}
                              currentTier={tier}
                            />
                          );
                        })}
                      </AnimatePresence>
                    </div>
                  </div>
                ))}
              </div>

              {/* Plan Upgrade Notice */}
              {tier === "free" && (
                <div className="mt-6 p-4 rounded-xl bg-gray-50 border border-gray-200">
                  <div className="flex items-start gap-3">
                    <Crown className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-bold mb-1">Unlock More Abilities</h4>
                      <p className="text-sm ui-muted mb-3">
                        Upgrade to Pro or Business to unlock advanced abilities like Memory, Web Search, File Handling, and more!
                      </p>
                      <Link to={createPageUrl("Pricing")}>
                        <Button size="sm" variant="primary">
                          View Plans
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )}
              </CardContent>
              </Card>

            <AgentPreview
              name={agentName}
              description={agentDescription}
              abilities={selectedAbilities}
              allAbilities={ABILITIES}
            />
          </div>
        </div>
      </div>
    </PageShell>
  );
}