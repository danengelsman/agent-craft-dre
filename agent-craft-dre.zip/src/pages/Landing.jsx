import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Sparkles, ArrowRight, Check, Star, Zap, Shield, 
  BarChart3, Users, Globe, ChevronRight, Play,
  MessageSquare, Clock, TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/Button";

// Mark this page as public (no authentication required)
export const PUBLIC_PAGE = true;

const JOURNEY_STAGES = [
  {
    stage: "problem",
    title: "Scattered tools. No strategy. Rapid burnout.",
    subtitle: "Beginners drown in complexity",
    image: "https://images.unsplash.com/photo-1551836022-4c4c79ecde51?w=1200&h=800&fit=crop&q=80",
  },
  {
    stage: "solution",
    title: "AgentCraft: AI Agent Builder for Beginners",
    subtitle: "Personalized agents that generate, schedule, and learn your style",
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&h=800&fit=crop&q=80",
  },
  {
    stage: "result",
    title: "Turn beginner creators into consistent content producers",
    subtitle: "Nothing acts FOR them or teaches them while they create — until now",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1200&h=800&fit=crop&q=80",
  }
];

const FEATURES = [
  {
    icon: Sparkles,
    title: "Beginner-First",
    description: "No coding. No overwhelm. Just results."
  },
  {
    icon: MessageSquare,
    title: "Agent Memory",
    description: "Your agent learns your style and improves over time"
  },
  {
    icon: Zap,
    title: "Unified Workflow",
    description: "Scripts, captions, edits, schedules — all in one place"
  },
  {
    icon: TrendingUp,
    title: "Education Built-In",
    description: "Learn while you create with guided tutorials"
  },
  {
    icon: BarChart3,
    title: "Analytics Brain",
    description: "Real-time feedback to optimize your content"
  },
  {
    icon: Globe,
    title: "Agent Marketplace",
    description: "Discover and share agents with the community"
  }
];

const TESTIMONIALS = [
  {
    quote: "Finally, an AI tool that doesn't overwhelm me. I went from 0 to publishing daily in two weeks.",
    author: "Alex Rivera",
    role: "YouTube Creator",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
  },
  {
    quote: "My agent remembers my brand voice and generates content that actually sounds like me.",
    author: "Jordan Lee",
    role: "Instagram Influencer",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop"
  },
  {
    quote: "I'm learning AI while building my content business. This is what I've been looking for.",
    author: "Morgan Taylor",
    role: "Newsletter Writer",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop"
  }
];

const STATS = [
  { value: "$70B+", label: "Creator Tools Market" },
  { value: "85%", label: "Revenue Share" },
  { value: "6 Steps", label: "To First Agent" },
  { value: "24/7", label: "AI Learning" }
];

export default function Landing() {
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStage((prev) => (prev + 1) % JOURNEY_STAGES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="app-container">
      {/* Navigation */}
      <nav className="landing-nav">
        <div className="nav-logo">AgentCraft</div>
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-gray-700 hover:text-gray-900 transition">Features</a>
          <a href="#testimonials" className="text-gray-700 hover:text-gray-900 transition">Testimonials</a>
          <Link to={createPageUrl("Pricing")} className="text-gray-700 hover:text-gray-900 transition">Pricing</Link>
        </div>
        <Link to={createPageUrl("Dashboard")} className="btn-glossy">
          Start Free
        </Link>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>AI Agents for Beginner Creators</h1>
          <p>
            No coding. No overwhelm. Build intelligent agents that generate content, 
            schedule posts, and learn your unique style—all in one beginner-friendly platform.
          </p>
          <Link to={createPageUrl("Dashboard")} className="btn-glossy">
            Start Building Free
          </Link>
        </div>
        <div className="logo-container">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/d96aa49bb_agent-logopng.png" 
            alt="AgentCraft Logo" 
            className="logo-img"
          />
        </div>
      </section>

      {/* Journey Stages Section */}
      <section className="py-24 px-6 relative overflow-hidden bg-white/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          {/* Journey Stages Carousel */}
          <div className="relative h-[600px] md:h-[700px] rounded-3xl overflow-hidden mb-12">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStage}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
                className="absolute inset-0"
              >
                {/* Background Image */}
                <div className="absolute inset-0">
                  <img 
                    src={JOURNEY_STAGES[currentStage].image}
                    alt={JOURNEY_STAGES[currentStage].stage}
                    className="w-full h-full object-cover"
                    style={{ 
                      filter: currentStage === 0 ? 'grayscale(40%) brightness(0.8)' : 
                              currentStage === 1 ? 'brightness(1.05)' : 
                              'brightness(1.1) saturate(1.1)'
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                </div>

                {/* Text Overlay */}
                <div className="absolute inset-0 flex items-end">
                  <div className="w-full p-8 md:p-16">
                    <motion.div
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="max-w-4xl"
                    >
                      <div className="text-sm font-semibold text-white/80 mb-3 uppercase tracking-wider">
                        {currentStage === 0 ? 'The Problem' : currentStage === 1 ? 'The Solution' : 'The Result'}
                      </div>
                      <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">
                        {JOURNEY_STAGES[currentStage].title}
                      </h1>
                      <p className="text-xl md:text-2xl text-white/90 mb-8">
                        {JOURNEY_STAGES[currentStage].subtitle}
                      </p>
                      
                      {currentStage === 1 && (
                        <Link to={createPageUrl("Dashboard")} className="btn-glossy">
                          Start Building Free →
                        </Link>
                      )}
                    </motion.div>
                  </div>
                </div>

                {/* Stage Indicators */}
                <div className="absolute bottom-8 right-8 flex gap-2">
                  {JOURNEY_STAGES.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentStage(idx)}
                      className={`h-1.5 rounded-full transition-all ${
                        idx === currentStage ? 'w-8 bg-white' : 'w-1.5 bg-white/40'
                      }`}
                    />
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Key Message */}
          <div className="text-center max-w-3xl mx-auto mb-12">
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-sm text-gray-600 mb-2 uppercase tracking-wider font-semibold"
            >
              How It Works
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-2xl md:text-3xl font-bold text-gray-900 leading-snug"
            >
              Onboard → Agent builds → Scripts & edits → Approve → Schedule → Analytics feedback
            </motion.h2>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/50 backdrop-blur-sm border-y border-gray-200/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl md:text-5xl font-bold text-gray-900 tracking-tight">
                  {stat.value}
                </div>
                <div className="text-gray-600 mt-1 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 bg-white/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-sm text-gray-600 mb-3 uppercase tracking-wider font-semibold"
            >
              Competitive Differentiators
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-bold mb-4 text-gray-900"
            >
              Built for creators, not corporations
            </motion.h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="p-8 rounded-2xl bg-white border border-gray-200 hover:shadow-lg transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-gray-900">{feature.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 px-6 bg-white/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-gray-900">
              From beginners to consistent creators
            </h2>
            <p className="text-xl text-gray-600">
              Real stories from the community
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((testimonial, index) => (
              <motion.div
                key={testimonial.author}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="p-8 rounded-2xl bg-white border border-gray-200"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 text-base leading-relaxed">"{testimonial.quote}"</p>
                <div className="flex items-center gap-3">
                  <img 
                    src={testimonial.avatar} 
                    alt={testimonial.author}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.author}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="p-12 rounded-3xl bg-gray-900"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Start creating today
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Free tier includes 3 agents. No credit card. Join beginner creators already transforming their workflow.
            </p>
            <Link to={createPageUrl("Dashboard")} className="btn-glossy">
              Build Your First Agent →
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-gray-200 pb-24">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gray-900 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-xl">AgentCraft</span>
              </div>
              <p className="text-gray-600 text-sm">
                AI Agents for beginner creators.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#features" className="hover:text-gray-900">Features</a></li>
                <li><Link to={createPageUrl("Pricing")} className="hover:text-gray-900">Pricing</Link></li>
                <li><a href="#" className="hover:text-gray-900">Security</a></li>
                <li><Link to={createPageUrl("Pricing")} className="hover:text-gray-900">FAQ</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-600">
                <li><a href="#" className="hover:text-gray-900">About</a></li>
                <li><Link to={createPageUrl("Blog")} className="hover:text-gray-900">Blog</Link></li>
                <li><a href="#" className="hover:text-gray-900">Careers</a></li>
                <li><Link to={createPageUrl("Contact")} className="hover:text-gray-900">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-600">
                <li><Link to={createPageUrl("Privacy")} className="hover:text-gray-900">Privacy</Link></li>
                <li><Link to={createPageUrl("Terms")} className="hover:text-gray-900">Terms</Link></li>
              </ul>
            </div>
          </div>
          <div className="pt-8 border-t border-gray-200 text-center text-gray-500 text-sm">
            © 2024 AgentCraft. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}