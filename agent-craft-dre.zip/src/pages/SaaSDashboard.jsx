import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { 
  TrendingUp, TrendingDown, Users, DollarSign, Activity, 
  ArrowUpRight, MoreHorizontal, Download, Filter,
  Calendar, ChevronDown, Bell, Search, Settings,
  BarChart3, PieChart, FileText, Zap
} from "lucide-react";
import { motion } from "framer-motion";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPie, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const REVENUE_DATA = [
  { month: 'Jan', revenue: 4000, users: 240 },
  { month: 'Feb', revenue: 5200, users: 310 },
  { month: 'Mar', revenue: 4800, users: 280 },
  { month: 'Apr', revenue: 6100, users: 390 },
  { month: 'May', revenue: 7200, users: 480 },
  { month: 'Jun', revenue: 8400, users: 520 },
  { month: 'Jul', revenue: 9100, users: 610 },
];

const ACTIVITY_DATA = [
  { day: 'Mon', active: 1200, new: 180 },
  { day: 'Tue', active: 1400, new: 220 },
  { day: 'Wed', active: 1100, new: 150 },
  { day: 'Thu', active: 1600, new: 280 },
  { day: 'Fri', active: 1800, new: 320 },
  { day: 'Sat', active: 900, new: 120 },
  { day: 'Sun', active: 800, new: 90 },
];

const PLAN_DISTRIBUTION = [
  { name: 'Free', value: 45, color: '#94a3b8' },
  { name: 'Starter', value: 30, color: '#8b5cf6' },
  { name: 'Pro', value: 20, color: '#3b82f6' },
  { name: 'Enterprise', value: 5, color: '#10b981' },
];

const RECENT_ACTIVITY = [
  { id: 1, user: 'Sarah Chen', action: 'Upgraded to Pro', time: '2 min ago', type: 'upgrade' },
  { id: 2, user: 'Marcus Johnson', action: 'New signup', time: '5 min ago', type: 'signup' },
  { id: 3, user: 'Emily Rodriguez', action: 'Completed onboarding', time: '12 min ago', type: 'milestone' },
  { id: 4, user: 'David Kim', action: 'Submitted feedback', time: '25 min ago', type: 'feedback' },
  { id: 5, user: 'Lisa Wang', action: 'Invited 3 team members', time: '1 hour ago', type: 'invite' },
];

export default function SaaSDashboard() {
  const [user, setUser] = useState(null);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const stats = [
    { 
      title: 'Total Revenue', 
      value: '$48,200', 
      change: '+12.5%', 
      trend: 'up',
      icon: DollarSign,
      color: 'from-green-500 to-emerald-600'
    },
    { 
      title: 'Active Users', 
      value: '2,847', 
      change: '+8.2%', 
      trend: 'up',
      icon: Users,
      color: 'from-blue-500 to-cyan-600'
    },
    { 
      title: 'Conversion Rate', 
      value: '3.24%', 
      change: '-0.4%', 
      trend: 'down',
      icon: Activity,
      color: 'from-purple-500 to-pink-600'
    },
    { 
      title: 'Avg. Session', 
      value: '4m 32s', 
      change: '+18.7%', 
      trend: 'up',
      icon: BarChart3,
      color: 'from-amber-500 to-orange-600'
    },
  ];

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app pb-24" style={{ maxWidth: '80rem' }}>
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600">Welcome back, {user?.full_name || 'there'}! Here's what's happening.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 bg-white rounded-lg border border-gray-200">
              <Calendar className="w-4 h-4 text-gray-500" />
              <select 
                value={timeRange} 
                onChange={(e) => setTimeRange(e.target.value)}
                className="bg-transparent text-sm font-medium focus:outline-none"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
              </select>
            </div>
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              Export
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center overflow-hidden`}>
                    <img 
                      src={
                        stat.icon.name === 'DollarSign' || stat.icon.name === 'Users'
                          ? "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/f0259eb9b_IMG_0013.jpeg"
                          : stat.icon.name === 'BarChart3' || stat.icon.name === 'Activity'
                          ? "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/bd622c784_IMG_0015.jpeg"
                          : "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/ab13e1317_IMG_0014.jpg"
                      }
                      alt={stat.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className={`flex items-center gap-1 text-sm font-medium ${
                    stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {stat.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    {stat.change}
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.title}</div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Revenue Chart */}
          <Card className="lg:col-span-2 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-bold text-lg">Revenue Overview</h3>
                <p className="text-sm text-gray-500">Monthly revenue and user growth</p>
              </div>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={REVENUE_DATA}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                  <YAxis stroke="#94a3b8" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorRevenue)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Plan Distribution */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-bold text-lg">Plan Distribution</h3>
                <p className="text-sm text-gray-500">Users by plan type</p>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPie>
                  <Pie
                    data={PLAN_DISTRIBUTION}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {PLAN_DISTRIBUTION.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </RechartsPie>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {PLAN_DISTRIBUTION.map((plan) => (
                <div key={plan.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: plan.color }} />
                  <span className="text-sm text-gray-600">{plan.name}</span>
                  <span className="text-sm font-medium ml-auto">{plan.value}%</span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Second Row */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Activity Chart */}
          <Card className="lg:col-span-2 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-bold text-lg">User Activity</h3>
                <p className="text-sm text-gray-500">Daily active and new users</p>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ACTIVITY_DATA}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="day" stroke="#94a3b8" fontSize={12} />
                  <YAxis stroke="#94a3b8" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Legend />
                  <Bar dataKey="active" name="Active Users" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="new" name="New Users" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          {/* Recent Activity */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-lg">Recent Activity</h3>
              <Button variant="ghost" size="sm">View All</Button>
            </div>
            <div className="space-y-4">
              {RECENT_ACTIVITY.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    activity.type === 'upgrade' ? 'bg-green-100 text-green-600' :
                    activity.type === 'signup' ? 'bg-blue-100 text-blue-600' :
                    activity.type === 'milestone' ? 'bg-purple-100 text-purple-600' :
                    activity.type === 'invite' ? 'bg-amber-100 text-amber-600' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {activity.type === 'upgrade' && <Zap className="w-4 h-4" />}
                    {activity.type === 'signup' && <Users className="w-4 h-4" />}
                    {activity.type === 'milestone' && <Activity className="w-4 h-4" />}
                    {activity.type === 'feedback' && <FileText className="w-4 h-4" />}
                    {activity.type === 'invite' && <Users className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{activity.user}</p>
                    <p className="text-sm text-gray-500">{activity.action}</p>
                  </div>
                  <span className="text-xs text-gray-400 whitespace-nowrap">{activity.time}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}