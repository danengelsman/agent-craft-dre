import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { 
  Sparkles, 
  ArrowRight, 
  ArrowLeft,
  Briefcase,
  TrendingUp,
  Heart,
  Compass,
  Code,
  Zap,
  User,
  Bot,
  MessageSquare,
  FileText,
  Cog,
  BarChart,
  Check,
  Loader2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const STEPS = {
  WELCOME: 0,
  GOAL: 1,
  EXPERIENCE: 2,
  INTEREST: 3,
  PLAN: 4
};

const GOALS = [
  {
    id: "business",
    label: "Build agents for my business",
    description: "Automate tasks and improve efficiency",
    icon: Briefcase,
    color: "from-blue-500 to-cyan-600"
  },
  {
    id: "career",
    label: "Learn AI for career growth",
    description: "Add AI skills to your resume",
    icon: TrendingUp,
    color: "from-purple-500 to-pink-600"
  },
  {
    id: "personal",
    label: "Personal projects",
    description: "Build cool stuff for yourself",
    icon: Heart,
    color: "from-rose-500 to-orange-600"
  },
  {
    id: "exploring",
    label: "Just exploring",
    description: "Curious about AI possibilities",
    icon: Compass,
    color: "from-green-500 to-teal-600"
  }
];

const EXPERIENCE_LEVELS = [
  {
    id: "beginner",
    label: "Complete beginner",
    description: "Never worked with AI before",
    icon: User,
    color: "from-blue-500 to-purple-600"
  },
  {
    id: "some_tech",
    label: "Some tech knowledge",
    description: "Familiar with software but new to AI",
    icon: Code,
    color: "from-purple-500 to-pink-600"
  },
  {
    id: "developer",
    label: "Developer looking to learn AI",
    description: "I code, want to understand AI",
    icon: Zap,
    color: "from-amber-500 to-orange-600"
  }
];

const INTERESTS = [
  {
    id: "customer_service",
    label: "Customer service bots",
    description: "Handle inquiries and support",
    icon: MessageSquare,
    color: "from-blue-500 to-cyan-600"
  },
  {
    id: "content_creation",
    label: "Content creation",
    description: "Writing, ideas, and creativity",
    icon: FileText,
    color: "from-purple-500 to-pink-600"
  },
  {
    id: "task_automation",
    label: "Task automation",
    description: "Automate repetitive workflows",
    icon: Cog,
    color: "from-green-500 to-teal-600"
  },
  {
    id: "data_analysis",
    label: "Data analysis",
    description: "Insights and analytics",
    icon: BarChart,
    color: "from-amber-500 to-orange-600"
  }
];

const PLANS = [
  {
    id: "free",
    name: "Free",
    price: 0,
    description: "Perfect for getting started",
    features: [
      "3 AI agents",
      "Basic lessons",
      "Community access",
      "Visual builder",
      "Export agents"
    ],
    cta: "Start Learning Free",
    popular: false
  },
  {
    id: "starter",
    name: "Starter",
    price: 19,
    description: "For serious learners",
    features: [
      "Unlimited agents",
      "All lessons & tutorials",
      "Priority support",
      "Advanced templates",
      "Remove branding"
    ],
    cta: "Subscribe to Starter",
    popular: true
  },
  {
    id: "pro",
    name: "Pro",
    price: 49,
    description: "For professionals",
    features: [
      "Everything in Starter",
      "1-on-1 coaching",
      "Custom integrations",
      "White-label options",
      "API access"
    ],
    cta: "Subscribe to Pro",
    popular: false
  }
];

export default function Onboarding() {
  const [step, setStep] = useState(STEPS.WELCOME);
  const [user, setUser] = useState(null);
  const [selections, setSelections] = useState({
    mainGoal: null,
    experienceLevel: null,
    interestArea: null,
    selectedPlan: "free"
  });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  const saveOnboardingMutation = useMutation({
    mutationFn: async (data) => {
      // Check if onboarding progress already exists
      const existing = await base44.entities.OnboardingProgress.filter({ 
        user_email: user.email 
      });
      
      if (existing.length > 0) {
        // Update existing
        return await base44.entities.OnboardingProgress.update(existing[0].id, data);
      } else {
        // Create new
        return await base44.entities.OnboardingProgress.create({
          user_email: user.email,
          ...data
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingProgress'] });
    }
  });

  const handleNext = () => {
    if (step < STEPS.PLAN) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > STEPS.WELCOME) {
      setStep(step - 1);
    }
  };

  const handlePlanSelection = async (planId) => {
    const finalSelections = {
      main_goal: selections.mainGoal,
      experience_level: selections.experienceLevel,
      interest_area: selections.interestArea,
      selected_plan: planId,
      has_completed_onboarding: true,
      completed_at: new Date().toISOString()
    };

    await saveOnboardingMutation.mutateAsync(finalSelections);
    queryClient.invalidateQueries({ queryKey: ['onboardingProgress'] });

    if (planId === "free") {
      navigate(createPageUrl("Dashboard"));
    } else {
      alert(`Stripe checkout for ${planId} plan would happen here. For now, redirecting to dashboard.`);
      navigate(createPageUrl("Dashboard"));
    }
  };

  const renderWelcome = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="text-center max-w-2xl mx-auto"
    >
      <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mx-auto mb-8 shadow-2xl">
        <Sparkles className="w-12 h-12 text-white" />
      </div>
      <h1 className="text-4xl md:text-5xl font-bold mb-6">
        Welcome to AgentCraft! 🎉
      </h1>
      <p className="text-xl text-gray-600 mb-12">
        Let's personalize your learning experience in just a few quick questions
      </p>
      <Button
        onClick={handleNext}
        size="lg"
        className="bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700 h-14 px-8"
      >
        Get Started
        <ArrowRight className="w-5 h-5 ml-2" />
      </Button>
    </motion.div>
  );

  const renderGoalSelection = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-4xl mx-auto"
    >
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">What's your main goal?</h2>
        <p className="text-gray-600">This helps us customize your learning path</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        {GOALS.map((goal) => {
          const Icon = goal.icon;
          const isSelected = selections.mainGoal === goal.id;
          return (
            <motion.button
              key={goal.id}
              onClick={() => setSelections({ ...selections, mainGoal: goal.id })}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`p-8 rounded-3xl text-left transition-all ${
                isSelected 
                  ? 'bg-white ring-2 ring-blue-500 shadow-xl' 
                  : 'bg-white shadow-lg hover:shadow-xl'
              }`}
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${goal.color} flex items-center justify-center mb-4`}>
                <Icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">{goal.label}</h3>
              <p className="text-gray-600">{goal.description}</p>
              {isSelected && (
                <div className="mt-4 flex items-center gap-2 text-blue-600 font-semibold">
                  <Check className="w-5 h-5" />
                  Selected
                </div>
              )}
            </motion.button>
          );
        })}
      </div>
      <div className="flex justify-between">
        <Button onClick={handleBack} variant="outline" size="lg">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleNext}
          disabled={!selections.mainGoal}
          size="lg"
          className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
        >
          Continue
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </motion.div>
  );

  const renderExperienceLevel = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-4xl mx-auto"
    >
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">What's your experience level?</h2>
        <p className="text-gray-600">No judgment - we'll meet you where you are!</p>
      </div>
      <div className="grid gap-6 mb-12">
        {EXPERIENCE_LEVELS.map((level) => {
          const Icon = level.icon;
          const isSelected = selections.experienceLevel === level.id;
          return (
            <motion.button
              key={level.id}
              onClick={() => setSelections({ ...selections, experienceLevel: level.id })}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              className={`p-8 rounded-3xl text-left transition-all flex items-center gap-6 ${
                isSelected 
                  ? 'bg-white ring-2 ring-blue-500 shadow-xl' 
                  : 'bg-white shadow-lg hover:shadow-xl'
              }`}
            >
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${level.color} flex items-center justify-center flex-shrink-0`}>
                <Icon className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold mb-2">{level.label}</h3>
                <p className="text-gray-600">{level.description}</p>
              </div>
              {isSelected && (
                <div className="flex items-center gap-2 text-blue-600 font-semibold flex-shrink-0">
                  <Check className="w-6 h-6" />
                </div>
              )}
            </motion.button>
          );
        })}
      </div>
      <div className="flex justify-between">
        <Button onClick={handleBack} variant="outline" size="lg">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleNext}
          disabled={!selections.experienceLevel}
          size="lg"
          className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
        >
          Continue
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </motion.div>
  );

  const renderInterestArea = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-4xl mx-auto"
    >
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">What interests you most?</h2>
        <p className="text-gray-600">We'll highlight relevant templates and examples</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6 mb-12">
        {INTERESTS.map((interest) => {
          const Icon = interest.icon;
          const isSelected = selections.interestArea === interest.id;
          return (
            <motion.button
              key={interest.id}
              onClick={() => setSelections({ ...selections, interestArea: interest.id })}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`p-8 rounded-3xl text-left transition-all ${
                isSelected 
                  ? 'bg-white ring-2 ring-blue-500 shadow-xl' 
                  : 'bg-white shadow-lg hover:shadow-xl'
              }`}
            >
              <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${interest.color} flex items-center justify-center mb-4`}>
                <Icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">{interest.label}</h3>
              <p className="text-gray-600">{interest.description}</p>
              {isSelected && (
                <div className="mt-4 flex items-center gap-2 text-blue-600 font-semibold">
                  <Check className="w-5 h-5" />
                  Selected
                </div>
              )}
            </motion.button>
          );
        })}
      </div>
      <div className="flex justify-between">
        <Button onClick={handleBack} variant="outline" size="lg">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
        <Button 
          onClick={handleNext}
          disabled={!selections.interestArea}
          size="lg"
          className="bg-gradient-to-r from-blue-500 to-purple-600 text-white"
        >
          Continue
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </motion.div>
  );

  const renderPlanSelection = () => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-6xl mx-auto"
    >
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Perfect! Choose your plan</h2>
        <p className="text-gray-600">You can upgrade or downgrade anytime</p>
      </div>
      <div className="grid md:grid-cols-3 gap-8 mb-12">
        {PLANS.map((plan) => (
          <motion.div
            key={plan.id}
            whileHover={{ scale: 1.02 }}
            className={`bg-white rounded-3xl shadow-lg p-8 relative ${
              plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                Recommended
              </div>
            )}
            <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
            <p className="text-gray-600 mb-6">{plan.description}</p>
            <div className="mb-6">
              <span className="text-5xl font-bold">${plan.price}</span>
              {plan.price > 0 && <span className="text-gray-600">/month</span>}
            </div>
            <ul className="space-y-3 mb-8">
              {plan.features.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
            <Button
              onClick={() => handlePlanSelection(plan.id)}
              disabled={saveOnboardingMutation.isLoading}
              className={`w-full h-12 ${
                plan.popular
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700'
                  : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
              }`}
            >
              {saveOnboardingMutation.isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Setting up...
                </>
              ) : (
                plan.cta
              )}
            </Button>
          </motion.div>
        ))}
      </div>
      <div className="text-center">
        <Button onClick={handleBack} variant="outline" size="lg">
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
      </div>
    </motion.div>
  );

  const progressPercentage = (step / STEPS.PLAN) * 100;

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen py-12 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-12">
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden max-w-md mx-auto">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progressPercentage}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <div className="text-center mt-3 text-sm text-gray-600">
            Step {step + 1} of {STEPS.PLAN + 1}
          </div>
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {step === STEPS.WELCOME && renderWelcome()}
          {step === STEPS.GOAL && renderGoalSelection()}
          {step === STEPS.EXPERIENCE && renderExperienceLevel()}
          {step === STEPS.INTEREST && renderInterestArea()}
          {step === STEPS.PLAN && renderPlanSelection()}
        </AnimatePresence>
      </div>
    </div>
  );
}