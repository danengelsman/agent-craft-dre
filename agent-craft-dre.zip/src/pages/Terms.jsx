import { PageShell } from "@/components/ui/PageShell";
import { Card, CardContent } from "@/components/ui/Card";

export default function Terms() {
  return (
    <PageShell>
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Terms of Service</h1>
          <p className="text-gray-600">Last updated: December 2025</p>
        </div>

        <Card>
          <CardContent className="p-8 space-y-6">
            <section>
              <h2 className="text-2xl font-semibold mb-3">Agreement to Terms</h2>
              <p className="text-gray-700 leading-relaxed">
                By accessing or using AgentCraft, you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you may not access the service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Use of Service</h2>
              <p className="text-gray-700 leading-relaxed mb-2">
                You agree to use AgentCraft only for lawful purposes and in accordance with these Terms. You agree not to:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 ml-4">
                <li>Use the service in any way that violates applicable laws or regulations</li>
                <li>Create AI agents that generate harmful, abusive, or illegal content</li>
                <li>Attempt to gain unauthorized access to our systems or networks</li>
                <li>Interfere with or disrupt the service or servers</li>
                <li>Use the service to transmit spam or malicious code</li>
                <li>Impersonate another user or provide false information</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">User Accounts</h2>
              <p className="text-gray-700 leading-relaxed">
                You are responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account. You must notify us immediately of any unauthorized use of your account.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Content and Intellectual Property</h2>
              <p className="text-gray-700 leading-relaxed">
                You retain all rights to the AI agents and content you create using AgentCraft. By making your agents public or selling them on our marketplace, you grant us a license to display and distribute them on our platform. AgentCraft and its original content, features, and functionality remain the exclusive property of AgentCraft.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Subscription and Payments</h2>
              <p className="text-gray-700 leading-relaxed">
                Some aspects of the service are provided on a subscription basis. You will be billed in advance on a recurring basis. Subscriptions automatically renew unless cancelled. Refunds are provided at our discretion based on our refund policy.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Termination</h2>
              <p className="text-gray-700 leading-relaxed">
                We may terminate or suspend your account immediately, without prior notice, for any breach of these Terms. Upon termination, your right to use the service will immediately cease. You may also terminate your account at any time through your account settings.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Disclaimers and Limitations of Liability</h2>
              <p className="text-gray-700 leading-relaxed">
                The service is provided "as is" without warranties of any kind. AgentCraft shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the service. AI-generated content may contain errors or inaccuracies, and you are responsible for verifying any information before relying on it.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Changes to Terms</h2>
              <p className="text-gray-700 leading-relaxed">
                We reserve the right to modify or replace these Terms at any time. We will provide notice of any material changes. Your continued use of the service after such changes constitutes acceptance of the new Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-3">Contact Us</h2>
              <p className="text-gray-700 leading-relaxed">
                If you have any questions about these Terms, please contact us through our Contact page or email us at legal@agentcraft.com.
              </p>
            </section>
          </CardContent>
        </Card>
      </div>
    </PageShell>
  );
}