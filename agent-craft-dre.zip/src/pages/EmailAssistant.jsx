import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Mail, Sparkles, Send, Clock, CheckCircle, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import EmailComposer from "../components/EmailComposer";

export default function EmailAssistant() {
  const [user, setUser] = useState(null);
  const [showComposer, setShowComposer] = useState(false);
  const [emailTemplates] = useState([
    {
      name: "Meeting Request",
      subject: "Meeting Request - [Topic]",
      body: "I'd like to schedule a meeting to discuss..."
    },
    {
      name: "Follow-up",
      subject: "Following up on [Topic]",
      body: "I wanted to follow up on our previous conversation about..."
    },
    {
      name: "Introduction",
      subject: "Introduction - [Your Name]",
      body: "I'm reaching out to introduce myself and explore..."
    },
    {
      name: "Thank You",
      subject: "Thank you for [Occasion]",
      body: "I wanted to express my gratitude for..."
    }
  ]);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser);
  }, []);

  const handleUseTemplate = (template) => {
    setSelectedTemplate(template);
    setShowComposer(true);
  };

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                <Mail className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  Email Assistant
                </h1>
                <p className="text-gray-600">Compose professional emails with AI help</p>
              </div>
            </div>
            <Button
              onClick={() => {
                setSelectedTemplate(null);
                setShowComposer(true);
              }}
              className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white"
            >
              <Plus className="w-5 h-5 mr-2" />
              New Email
            </Button>
          </div>

          {/* Info Card */}
          <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/80 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-900 mb-2">AI-Powered Email Writing</h3>
                <p className="text-gray-700 mb-3">
                  Start with a template or write from scratch, then let AI help you craft the perfect message. 
                  The AI can expand your ideas, improve tone, and make your emails more professional.
                </p>
                <div className="flex flex-wrap gap-2">
                  <div className="px-3 py-1 rounded-full bg-white/80 text-sm text-gray-700 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Professional tone
                  </div>
                  <div className="px-3 py-1 rounded-full bg-white/80 text-sm text-gray-700 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    AI enhancement
                  </div>
                  <div className="px-3 py-1 rounded-full bg-white/80 text-sm text-gray-700 flex items-center gap-1">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    Quick templates
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Email Templates */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4 text-gray-900">Quick Start Templates</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {emailTemplates.map((template, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card
                  className="p-5 cursor-pointer hover:shadow-lg transition-all group"
                  onClick={() => handleUseTemplate(template)}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mail className="w-5 h-5 text-indigo-600" />
                    </div>
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{template.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{template.subject}</p>
                  <div className="flex items-center text-xs text-indigo-600 font-medium">
                    Use template
                    <Send className="w-3 h-3 ml-1 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* How It Works */}
        <Card className="p-6 md:p-8">
          <h2 className="text-2xl font-bold mb-6 text-gray-900">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-indigo-600">1</span>
              </div>
              <h3 className="font-bold mb-2">Choose or Write</h3>
              <p className="text-sm text-gray-600">
                Pick a template or start from scratch with your own draft
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-indigo-600" />
              </div>
              <h3 className="font-bold mb-2">Enhance with AI</h3>
              <p className="text-sm text-gray-600">
                Let AI improve your message, add details, and polish the tone
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
                <Send className="w-8 h-8 text-indigo-600" />
              </div>
              <h3 className="font-bold mb-2">Send</h3>
              <p className="text-sm text-gray-600">
                Review and send your professional email with confidence
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Email Composer Modal */}
      <AnimatePresence>
        {showComposer && (
          <EmailComposer
            agent={{ name: "Email Assistant" }}
            prefilledData={selectedTemplate}
            onClose={() => {
              setShowComposer(false);
              setSelectedTemplate(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}