import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { 
  Sparkles, ArrowRight, ArrowLeft, Check, Rocket, 
  Store, DollarSign, BookOpen, Zap, Target,
  User, Briefcase, Code, Compass
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import AgentTemplates, { STARTER_TEMPLATES } from "../components/AgentTemplates";

const FLOW_STEPS = [
  { id: "welcome", title: "Welcome" },
  { id: "goal", title: "Your Goal" },
  { id: "experience", title: "Experience" },
  { id: "interest", title: "Interest" },
  { id: "first_agent", title: "First Agent" },
  { id: "complete", title: "Complete" }
];

const GOALS = [
  { id: "business", label: "Business Automation", description: "Automate customer service, sales, or operations", icon: Briefcase },
  { id: "career", label: "Career Growth", description: "Learn AI skills to advance professionally", icon: Target },
  { id: "personal", label: "Personal Projects", description: "Build AI assistants for personal use", icon: User },
  { id: "exploring", label: "Just Exploring", description: "Curious about what AI agents can do", icon: Compass }
];

const EXPERIENCE_LEVELS = [
  { id: "beginner", label: "Complete Beginner", description: "Never worked with AI before" },
  { id: "some_tech", label: "Some Tech Background", description: "Familiar with software but not AI" },
  { id: "developer", label: "Developer/Technical", description: "Comfortable with coding and APIs" }
];

const INTEREST_AREAS = [
  { id: "customer_service", label: "Customer Service", icon: "💬" },
  { id: "content_creation", label: "Content Creation", icon: "✍️" },
  { id: "task_automation", label: "Task Automation", icon: "⚡" },
  { id: "data_analysis", label: "Data Analysis", icon: "📊" }
];

export default function OnboardingFlow() {
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [selections, setSelections] = useState({
    goal: null,
    experience: null,
    interest: null,
    template: null
  });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  const { data: onboarding } = useQuery({
    queryKey: ['onboarding', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existing = await base44.entities.OnboardingProgress.filter({ user_email: user.email });
      if (existing.length > 0) {
        return existing[0];
      }
      return await base44.entities.OnboardingProgress.create({
        user_email: user.email,
        tour_step: 0
      });
    },
    enabled: !!user?.email,
  });

  const updateOnboardingMutation = useMutation({
    mutationFn: (data) => {
      if (!onboarding?.id) return Promise.reject("No onboarding record");
      return base44.entities.OnboardingProgress.update(onboarding.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding'] });
    },
  });

  const createAgentMutation = useMutation({
    mutationFn: async (template) => {
      return await base44.entities.Agent.create({
        name: template.name,
        description: template.description,
        personality: template.personality || "friendly",
        abilities: template.abilities || ["basic_chat"],
        color_theme: "purple",
        is_active: true,
        category: template.category || "other"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agents'] });
    },
  });

  const handleNext = async () => {
    const stepId = FLOW_STEPS[currentStep].id;
    
    // Save progress based on current step
    if (stepId === "goal" && selections.goal) {
      await updateOnboardingMutation.mutateAsync({ main_goal: selections.goal });
    } else if (stepId === "experience" && selections.experience) {
      await updateOnboardingMutation.mutateAsync({ experience_level: selections.experience });
    } else if (stepId === "interest" && selections.interest) {
      await updateOnboardingMutation.mutateAsync({ interest_area: selections.interest });
    } else if (stepId === "first_agent" && selections.template) {
      await createAgentMutation.mutateAsync(selections.template);
      await updateOnboardingMutation.mutateAsync({ has_created_agent: true });
    }

    if (currentStep < FLOW_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleComplete = async () => {
    await updateOnboardingMutation.mutateAsync({
      has_completed_onboarding: true,
      completed_at: new Date().toISOString()
    });
    queryClient.invalidateQueries({ queryKey: ['onboarding'] });
    navigate(createPageUrl("Dashboard"));
  };

  const handleSkip = () => {
    if (currentStep < FLOW_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const canProceed = () => {
    const stepId = FLOW_STEPS[currentStep].id;
    switch (stepId) {
      case "welcome": return true;
      case "goal": return !!selections.goal;
      case "experience": return !!selections.experience;
      case "interest": return !!selections.interest;
      case "first_agent": return !!selections.template;
      case "complete": return true;
      default: return true;
    }
  };

  // Get recommended templates based on interest
  const getRecommendedTemplates = () => {
    const interestToTemplate = {
      customer_service: ["template_customer_support"],
      content_creation: ["template_content_writer"],
      task_automation: ["template_meeting_scheduler", "template_sales_assistant"],
      data_analysis: ["template_data_analyst", "template_research_assistant"]
    };
    
    const recommended = interestToTemplate[selections.interest] || [];
    return STARTER_TEMPLATES.filter(t => recommended.includes(t.id) || recommended.length === 0);
  };

  if (!user) return null;

  const stepId = FLOW_STEPS[currentStep].id;

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ background: 'var(--primary-bg)' }}>
      <div className="max-w-4xl w-full">
        {/* Progress */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {FLOW_STEPS.map((step, idx) => (
            <div key={step.id} className="flex items-center">
              <div
                className={`w-3 h-3 rounded-full transition-all ${
                  idx < currentStep
                    ? 'bg-gray-900'
                    : idx === currentStep
                    ? 'bg-gray-900 w-4 h-4'
                    : 'bg-gray-300'
                }`}
              />
              {idx < FLOW_STEPS.length - 1 && (
                <div className={`w-8 h-0.5 ${idx < currentStep ? 'bg-gray-900' : 'bg-gray-300'}`} />
              )}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Welcome */}
          {stepId === "welcome" && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <div className="w-24 h-24 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-6">
                <Sparkles className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-4xl font-bold mb-4 text-gray-900">Welcome to AgentCraft!</h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg mx-auto">
                Let's set up your workspace and create your first AI agent in just a few minutes.
              </p>
              <div className="flex flex-col items-center gap-4">
                <Button
                  onClick={handleNext}
                  size="lg"
                  className="bg-gray-900 hover:bg-gray-800 text-white px-8"
                >
                  Let's Get Started
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <button
                  onClick={async () => {
                    if (onboarding) {
                      await updateOnboardingMutation.mutateAsync({
                        has_completed_onboarding: true,
                        completed_at: new Date().toISOString()
                      });
                      queryClient.invalidateQueries({ queryKey: ['onboarding'] });
                    }
                    navigate(createPageUrl("Dashboard"));
                  }}
                  className="text-sm text-gray-500 hover:text-gray-700"
                >
                  Skip onboarding
                </button>
              </div>
            </motion.div>
          )}

          {/* Goal Selection */}
          {stepId === "goal" && (
            <motion.div
              key="goal"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <h2 className="text-3xl font-bold mb-2 text-gray-900">What brings you here?</h2>
              <p className="text-gray-600 mb-8">We'll customize your experience based on your goals</p>
              
              <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto mb-8">
                {GOALS.map((goal) => {
                  const Icon = goal.icon;
                  return (
                    <button
                      key={goal.id}
                      onClick={() => setSelections({ ...selections, goal: goal.id })}
                      className={`p-6 rounded-xl text-left transition-all border-2 ${
                        selections.goal === goal.id
                          ? 'border-gray-900 bg-gray-50'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          selections.goal === goal.id ? 'bg-gray-900' : 'bg-gray-100'
                        }`}>
                          <Icon className={`w-6 h-6 ${selections.goal === goal.id ? 'text-white' : 'text-gray-600'}`} />
                        </div>
                        <div>
                          <h3 className="font-bold text-lg text-gray-900">{goal.label}</h3>
                          <p className="text-sm text-gray-600">{goal.description}</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Experience Level */}
          {stepId === "experience" && (
            <motion.div
              key="experience"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <h2 className="text-3xl font-bold mb-2 text-gray-900">What's your experience with AI?</h2>
              <p className="text-gray-600 mb-8">This helps us show you the right tutorials</p>
              
              <div className="flex flex-col gap-4 max-w-md mx-auto mb-8">
                {EXPERIENCE_LEVELS.map((level) => (
                  <button
                    key={level.id}
                    onClick={() => setSelections({ ...selections, experience: level.id })}
                    className={`p-5 rounded-xl text-left transition-all border-2 ${
                      selections.experience === level.id
                        ? 'border-gray-900 bg-gray-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-gray-900">{level.label}</h3>
                        <p className="text-sm text-gray-600">{level.description}</p>
                      </div>
                      {selections.experience === level.id && (
                        <div className="w-6 h-6 rounded-full bg-gray-900 flex items-center justify-center">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Interest Area */}
          {stepId === "interest" && (
            <motion.div
              key="interest"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <h2 className="text-3xl font-bold mb-2 text-gray-900">What do you want to automate?</h2>
              <p className="text-gray-600 mb-8">We'll recommend the best templates for you</p>
              
              <div className="grid grid-cols-2 gap-4 max-w-md mx-auto mb-8">
                {INTEREST_AREAS.map((area) => (
                  <button
                    key={area.id}
                    onClick={() => setSelections({ ...selections, interest: area.id })}
                    className={`p-6 rounded-xl text-center transition-all border-2 ${
                      selections.interest === area.id
                        ? 'border-gray-900 bg-gray-50'
                        : 'border-gray-200 bg-white hover:border-gray-300'
                    }`}
                  >
                    <div className="text-4xl mb-3">{area.icon}</div>
                    <h3 className="font-bold text-sm text-gray-900">{area.label}</h3>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* First Agent */}
          {stepId === "first_agent" && (
            <motion.div
              key="first_agent"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold mb-2 text-gray-900">Create your first agent!</h2>
                <p className="text-gray-600 mb-6">
                  Choose a template to get started. You can customize it later.
                </p>
                
                {/* Action Required Card */}
                <div className="max-w-2xl mx-auto mb-8 p-6 rounded-xl bg-amber-50 border-2 border-amber-200">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-6 h-6 text-amber-600" />
                    </div>
                    <div className="text-left flex-1">
                      <h3 className="font-bold text-lg text-amber-900 mb-2">Action Required</h3>
                      <p className="text-amber-800 mb-4">
                        Select one of the templates below to create your first agent
                      </p>
                      <div className="flex items-center gap-2 text-sm text-amber-700">
                        <div className="w-6 h-6 rounded-full bg-amber-200 flex items-center justify-center text-amber-900 font-bold">1</div>
                        <span>Choose a template</span>
                        <ArrowRight className="w-4 h-4" />
                        <div className="w-6 h-6 rounded-full bg-amber-200 flex items-center justify-center text-amber-900 font-bold">2</div>
                        <span>Click Continue</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-3 gap-4 mb-8">
                {getRecommendedTemplates().slice(0, 3).map((template) => (
                  <button
                    key={template.id}
                    onClick={() => setSelections({ ...selections, template: template })}
                    className={`p-6 rounded-xl text-left transition-all border-2 ${
                      selections.template?.id === template.id
                        ? 'border-gray-900 bg-gray-50 shadow-lg'
                        : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-md'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center mb-4 text-xl`}>
                      {template.icon}
                    </div>
                    <h3 className="font-bold mb-1 text-gray-900">{template.name}</h3>
                    <p className="text-xs text-gray-600 line-clamp-2">{template.description}</p>
                    
                    {selections.template?.id === template.id && (
                      <div className="mt-3 flex items-center gap-2 text-gray-900 text-sm font-semibold">
                        <Check className="w-4 h-4" />
                        Selected
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Complete */}
          {stepId === "complete" && (
            <motion.div
              key="complete"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <div className="w-24 h-24 rounded-2xl bg-gray-900 flex items-center justify-center mx-auto mb-6">
                <Rocket className="w-12 h-12 text-white" />
              </div>
              <h1 className="text-4xl font-bold mb-4 text-gray-900">You're all set! 🎉</h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg mx-auto">
                Your first agent has been created. Here's what you can do next:
              </p>
              
              <div className="grid md:grid-cols-3 gap-4 max-w-3xl mx-auto mb-8">
                <div className="p-6 rounded-xl bg-white border border-gray-200">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="w-6 h-6 text-gray-900" />
                  </div>
                  <h3 className="font-bold mb-1 text-gray-900">Chat with your agent</h3>
                  <p className="text-sm text-gray-600">Test and interact with your new AI assistant</p>
                </div>
                <div className="p-6 rounded-xl bg-white border border-gray-200">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center mx-auto mb-3">
                    <Store className="w-6 h-6 text-gray-900" />
                  </div>
                  <h3 className="font-bold mb-1 text-gray-900">Explore marketplace</h3>
                  <p className="text-sm text-gray-600">Discover agents built by the community</p>
                </div>
                <div className="p-6 rounded-xl bg-white border border-gray-200">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center mx-auto mb-3">
                    <DollarSign className="w-6 h-6 text-gray-900" />
                  </div>
                  <h3 className="font-bold mb-1 text-gray-900">Start earning</h3>
                  <p className="text-sm text-gray-600">Sell your agents and keep 85% revenue</p>
                </div>
              </div>
              
              <Button
                onClick={handleComplete}
                size="lg"
                className="bg-gray-900 hover:bg-gray-800 text-white px-8"
              >
                Go to Dashboard
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        {stepId !== "welcome" && stepId !== "complete" && (
          <div className="flex justify-between items-center mt-8 max-w-2xl mx-auto">
            <Button
              onClick={() => setCurrentStep(currentStep - 1)}
              variant="outline"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            
            <div className="flex gap-3">
              <button
                onClick={handleSkip}
                className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2"
              >
                Skip
              </button>
              <Button
                onClick={handleNext}
                disabled={!canProceed()}
                className={canProceed() ? 'bg-gray-900 hover:bg-gray-800 text-white' : ''}
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}