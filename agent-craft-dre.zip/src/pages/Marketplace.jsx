import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { PageShell } from "@/components/ui/PageShell";
import { Store, Search, Download, Star, TrendingUp, DollarSign, Filter, Crown, Lock, Tag, CheckCircle, HelpCircle, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { usePlanAccess } from "../components/PlanAccessProvider";

const ReviewSubmission = lazy(() => import("../components/ReviewSubmission"));
const AdminSimulationControls = lazy(() => import("../components/AdminSimulationControls"));
const AgentPackageCard = lazy(() => import("../components/marketplace/AgentPackageCard"));
const AgentDetailModal = lazy(() => import("../components/marketplace/AgentDetailModal"));
const ContextualHelp = lazy(() => import("../components/ContextualHelp"));

export default function Marketplace() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [priceFilter, setPriceFilter] = useState("all");
  const [sortBy, setSortBy] = useState("popular");
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [certifiedOnly, setCertifiedOnly] = useState(false);
  const queryClient = useQueryClient();
  
  const { canSellMarketplace, tier, isAdmin, isSimulating } = usePlanAccess();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: publicAgents = [] } = useQuery({
    queryKey: ['publicAgents', sortBy],
    queryFn: async () => {
      const sortField = sortBy === 'recent' ? '-created_date' : 
                       sortBy === 'rating' ? '-average_rating' :
                       sortBy === 'price_low' ? 'price' :
                       sortBy === 'price_high' ? '-price' : '-download_count';
      return await base44.entities.Agent.filter({ is_public: true }, sortField);
    },
    staleTime: 300000,
  });

  const { data: myPurchases = [] } = useQuery({
    queryKey: ['myPurchases', user?.email],
    queryFn: () => base44.entities.AgentPurchase.filter({ buyer_email: user?.email }),
    enabled: !!user?.email,
    staleTime: 300000,
  });

  const purchaseAgentMutation = useMutation({
    mutationFn: async (agent) => {
      if (!user?.email) throw new Error("Please log in to purchase");

      const agentCopy = await base44.entities.Agent.create({
        name: `${agent.name} (Copy)`,
        description: agent.description,
        personality: agent.personality,
        abilities: agent.abilities,
        color_theme: agent.color_theme,
        is_active: true,
        is_public: false,
        is_template: false
      });

      if (agent.price > 0) {
        const platformFee = agent.price * 0.15;
        const sellerRevenue = agent.price * 0.85;

        await base44.entities.AgentPurchase.create({
          agent_id: agent.id,
          buyer_email: user.email,
          seller_email: agent.created_by,
          price: agent.price,
          platform_fee: platformFee,
          seller_revenue: sellerRevenue
        });
      }

      await base44.entities.Agent.update(agent.id, {
        download_count: (agent.download_count || 0) + 1
      });

      return agentCopy;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['publicAgents'] });
      queryClient.invalidateQueries({ queryKey: ['myPurchases'] });
      queryClient.invalidateQueries({ queryKey: ['agents'] });
      alert("Agent added to your collection! 🎉");
    },
  });

  const handlePurchase = async (agent) => {
    const alreadyPurchased = myPurchases.some(p => p.agent_id === agent.id);
    if (alreadyPurchased) {
      alert("You already own this agent!");
      return;
    }

    if (agent.price > 0) {
      const confirm = window.confirm(
        `Purchase "${agent.name}" for $${agent.price}?\n\nNote: This is a demo. In production, this would redirect to Stripe checkout.`
      );
      if (!confirm) return;
    }

    await purchaseAgentMutation.mutateAsync(agent);
  };

  const filteredAgents = useMemo(() => publicAgents.filter(agent => {
    const matchesSearch = agent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         agent.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         agent.tags?.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPrice = priceFilter === "all" ||
                        (priceFilter === "free" && agent.price === 0) ||
                        (priceFilter === "paid" && agent.price > 0);
    const matchesCategory = categoryFilter === "all" || agent.category === categoryFilter;
    const matchesCertified = !certifiedOnly || agent.certification_status === "certified" || agent.certification_status === "premium";
    return matchesSearch && matchesPrice && matchesCategory && matchesCertified;
  }), [publicAgents, searchQuery, priceFilter, categoryFilter, certifiedOnly]);

  const sortedAgents = useMemo(() => [...filteredAgents].sort((a, b) => {
    if (sortBy === 'popular') return (b.download_count || 0) - (a.download_count || 0);
    if (sortBy === 'rating') return (b.average_rating || 0) - (a.average_rating || 0);
    if (sortBy === 'recent') return new Date(b.created_date) - new Date(a.created_date);
    if (sortBy === 'price_low') return (a.price || 0) - (b.price || 0);
    if (sortBy === 'price_high') return (b.price || 0) - (a.price || 0);
    return 0;
  }), [filteredAgents, sortBy]);

  return (
    <PageShell>
      <div className="max-w-7xl mx-auto">
        {/* Admin Simulation Controls */}
        {(isAdmin || isSimulating) && (
          <Suspense fallback={<div className="h-16" />}>
            <AdminSimulationControls />
          </Suspense>
        )}

        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gray-900 flex items-center justify-center">
                <Store className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold">AI Helper Marketplace</h1>
                <p className="ui-muted flex items-center gap-1">
                  Download helpers made by the community
                  <Suspense fallback={null}>
                    <ContextualHelp helpKey="marketplace_certification" position="right" />
                  </Suspense>
                </p>
              </div>
            </div>
            {canSellMarketplace ? (
              <Link to={createPageUrl("CreatorDashboard")}>
                <Button variant="primary">
                  <DollarSign className="w-5 h-5 mr-2" />
                  Sell Your Helpers
                </Button>
              </Link>
            ) : (
              <div className="text-right">
                <Button disabled className="opacity-50 cursor-not-allowed mb-2">
                  <Lock className="w-5 h-5 mr-2" />
                  Selling Locked
                </Button>
                <p className="text-xs ui-muted">Upgrade to Pro to sell</p>
              </div>
            )}
          </div>

          {/* Marketplace Selling Notice for Free Users */}
          {!canSellMarketplace && (
            <Card className="bg-green-50 border-green-200 mb-6 p-6">
              <div className="flex items-start gap-4">
                <Crown className="w-8 h-8 text-green-700 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-green-900 mb-2">Start Selling Your AI Helpers</h3>
                  <p className="text-green-800 mb-4 flex items-center gap-1">
                    Upgrade to Pro or Business to sell your helpers on the marketplace and earn revenue!
                    Keep 85% of every sale.
                    <Suspense fallback={null}>
                      <ContextualHelp helpKey="revenue_share" position="right" />
                    </Suspense>
                  </p>
                  <Link to={createPageUrl("Pricing")}>
                    <Button variant="primary" className="bg-green-700 hover:bg-green-800">
                      View Plans
                    </Button>
                  </Link>
                </div>
              </div>
            </Card>
          )}

          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search helpers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="ui-control px-4 py-2 text-sm font-medium"
              >
                <option value="all">All Categories</option>
                <option value="productivity">Productivity</option>
                <option value="customer_service">Customer Service</option>
                <option value="sales">Sales</option>
                <option value="content">Content</option>
                <option value="data">Data</option>
                <option value="other">Other</option>
              </select>
              <select
                value={priceFilter}
                onChange={(e) => setPriceFilter(e.target.value)}
                className="ui-control px-4 py-2 text-sm font-medium"
              >
                <option value="all">All Prices</option>
                <option value="free">Free</option>
                <option value="paid">Paid</option>
              </select>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="ui-control px-4 py-2 text-sm font-medium"
              >
                <option value="popular">Most Popular</option>
                <option value="rating">Highest Rated</option>
                <option value="recent">Most Recent</option>
                <option value="price_low">Price: Low to High</option>
                <option value="price_high">Price: High to Low</option>
              </select>
              <Button
                onClick={() => setCertifiedOnly(!certifiedOnly)}
                variant={certifiedOnly ? "primary" : "secondary"}
                className="flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Certified Only
              </Button>
            </div>
          </div>
        </div>

        <Suspense fallback={
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="p-6 h-64 animate-pulse bg-gray-100" />
            ))}
          </div>
        }>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedAgents.map((agent) => {
              const isPurchased = myPurchases.some(p => p.agent_id === agent.id);
              const isOwn = agent.created_by === user?.email;

              return (
                <AgentPackageCard
                  key={agent.id}
                  agent={agent}
                  isPurchased={isPurchased}
                  isOwn={isOwn}
                  onPurchase={handlePurchase}
                  onReview={(a) => {
                    setSelectedAgent(a);
                    setShowReviewModal(true);
                  }}
                  onViewDetails={(a) => {
                    setSelectedAgent(a);
                    setShowDetailModal(true);
                  }}
                  isLoading={purchaseAgentMutation.isLoading}
                />
              );
            })}
          </div>
        </Suspense>

        {showReviewModal && selectedAgent && (
          <Suspense fallback={null}>
            <ReviewSubmission
              agent={selectedAgent}
              user={user}
              isPurchased={myPurchases.some(p => p.agent_id === selectedAgent.id)}
              onClose={() => {
                setShowReviewModal(false);
                setSelectedAgent(null);
              }}
            />
          </Suspense>
        )}

        {showDetailModal && selectedAgent && (
          <Suspense fallback={null}>
            <AgentDetailModal
              agent={selectedAgent}
              onClose={() => {
                setShowDetailModal(false);
                setSelectedAgent(null);
              }}
              onPurchase={handlePurchase}
              isPurchased={myPurchases.some(p => p.agent_id === selectedAgent.id)}
              isOwn={selectedAgent.created_by === user?.email}
            />
          </Suspense>
        )}
      </div>
    </PageShell>
  );
}