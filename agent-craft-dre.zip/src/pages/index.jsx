import Layout from "./Layout.jsx";

import ActionBuilder from "./ActionBuilder";

import AdminDashboard from "./AdminDashboard";

import AdminModeration from "./AdminModeration";

import AgentEvolution from "./AgentEvolution";

import AgentOrchestration from "./AgentOrchestration";

import AgentTraining from "./AgentTraining";

import ApiSettings from "./ApiSettings";

import Blog from "./Blog";

import BlogPost from "./BlogPost";

import Builder from "./Builder";

import Chat from "./Chat";

import CollaborationBuilder from "./CollaborationBuilder";

import CollaborationDashboard from "./CollaborationDashboard";

import Community from "./Community";

import Contact from "./Contact";

import CostDashboard from "./CostDashboard";

import CreatorDashboard from "./CreatorDashboard";

import Dashboard from "./Dashboard";

import EmailAssistant from "./EmailAssistant";

import FeedbackDashboard from "./FeedbackDashboard";

import Gallery from "./Gallery";

import GuidedBuilder from "./GuidedBuilder";

import Home from "./Home";

import HubSpotIntegration from "./HubSpotIntegration";

import Landing from "./Landing";

import Learn from "./Learn";

import Marketplace from "./Marketplace";

import Onboarding from "./Onboarding";

import OnboardingFlow from "./OnboardingFlow";

import Pricing from "./Pricing";

import Privacy from "./Privacy";

import Profile from "./Profile";

import SaaSDashboard from "./SaaSDashboard";

import SaaSPricing from "./SaaSPricing";

import Sandbox from "./Sandbox";

import SecurityDashboard from "./SecurityDashboard";

import Settings from "./Settings";

import Terms from "./Terms";

import TraceDashboard from "./TraceDashboard";

import TutorialCenter from "./TutorialCenter";

import Tutorials from "./Tutorials";

import VideoTutorials from "./VideoTutorials";

import WorkflowBuilder from "./WorkflowBuilder";

import ActionMarketplace from "./ActionMarketplace";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    ActionBuilder: ActionBuilder,
    
    AdminDashboard: AdminDashboard,
    
    AdminModeration: AdminModeration,
    
    AgentEvolution: AgentEvolution,
    
    AgentOrchestration: AgentOrchestration,
    
    AgentTraining: AgentTraining,
    
    ApiSettings: ApiSettings,
    
    Blog: Blog,
    
    BlogPost: BlogPost,
    
    Builder: Builder,
    
    Chat: Chat,
    
    CollaborationBuilder: CollaborationBuilder,
    
    CollaborationDashboard: CollaborationDashboard,
    
    Community: Community,
    
    Contact: Contact,
    
    CostDashboard: CostDashboard,
    
    CreatorDashboard: CreatorDashboard,
    
    Dashboard: Dashboard,
    
    EmailAssistant: EmailAssistant,
    
    FeedbackDashboard: FeedbackDashboard,
    
    Gallery: Gallery,
    
    GuidedBuilder: GuidedBuilder,
    
    Home: Home,
    
    HubSpotIntegration: HubSpotIntegration,
    
    Landing: Landing,
    
    Learn: Learn,
    
    Marketplace: Marketplace,
    
    Onboarding: Onboarding,
    
    OnboardingFlow: OnboardingFlow,
    
    Pricing: Pricing,
    
    Privacy: Privacy,
    
    Profile: Profile,
    
    SaaSDashboard: SaaSDashboard,
    
    SaaSPricing: SaaSPricing,
    
    Sandbox: Sandbox,
    
    SecurityDashboard: SecurityDashboard,
    
    Settings: Settings,
    
    Terms: Terms,
    
    TraceDashboard: TraceDashboard,
    
    TutorialCenter: TutorialCenter,
    
    Tutorials: Tutorials,
    
    VideoTutorials: VideoTutorials,
    
    WorkflowBuilder: WorkflowBuilder,
    
    ActionMarketplace: ActionMarketplace,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<ActionBuilder />} />
                
                
                <Route path="/ActionBuilder" element={<ActionBuilder />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminModeration" element={<AdminModeration />} />
                
                <Route path="/AgentEvolution" element={<AgentEvolution />} />
                
                <Route path="/AgentOrchestration" element={<AgentOrchestration />} />
                
                <Route path="/AgentTraining" element={<AgentTraining />} />
                
                <Route path="/ApiSettings" element={<ApiSettings />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/Builder" element={<Builder />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/CollaborationBuilder" element={<CollaborationBuilder />} />
                
                <Route path="/CollaborationDashboard" element={<CollaborationDashboard />} />
                
                <Route path="/Community" element={<Community />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/CostDashboard" element={<CostDashboard />} />
                
                <Route path="/CreatorDashboard" element={<CreatorDashboard />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/EmailAssistant" element={<EmailAssistant />} />
                
                <Route path="/FeedbackDashboard" element={<FeedbackDashboard />} />
                
                <Route path="/Gallery" element={<Gallery />} />
                
                <Route path="/GuidedBuilder" element={<GuidedBuilder />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/HubSpotIntegration" element={<HubSpotIntegration />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/Learn" element={<Learn />} />
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/OnboardingFlow" element={<OnboardingFlow />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/Privacy" element={<Privacy />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/SaaSDashboard" element={<SaaSDashboard />} />
                
                <Route path="/SaaSPricing" element={<SaaSPricing />} />
                
                <Route path="/Sandbox" element={<Sandbox />} />
                
                <Route path="/SecurityDashboard" element={<SecurityDashboard />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Terms" element={<Terms />} />
                
                <Route path="/TraceDashboard" element={<TraceDashboard />} />
                
                <Route path="/TutorialCenter" element={<TutorialCenter />} />
                
                <Route path="/Tutorials" element={<Tutorials />} />
                
                <Route path="/VideoTutorials" element={<VideoTutorials />} />
                
                <Route path="/WorkflowBuilder" element={<WorkflowBuilder />} />
                
                <Route path="/ActionMarketplace" element={<ActionMarketplace />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}