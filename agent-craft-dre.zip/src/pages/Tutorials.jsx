import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Card } from "@/components/ui/Card";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Sparkles, Zap, CheckCircle, Clock, Star, TrendingUp, Users, Store, ArrowRight, ArrowLeft, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const CATEGORY_INFO = {
  onboarding: { label: "Getting Started", icon: Sparkles, color: { bg: 'linear-gradient(145deg, #d4b9f5, #e6d5ff)', shadow: 'rgba(180, 150, 220, 0.3)' } },
  advanced: { label: "Advanced", icon: TrendingUp, color: { bg: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)', shadow: 'rgba(240, 200, 150, 0.3)' } },
  marketplace: { label: "Marketplace", icon: Store, color: { bg: 'linear-gradient(145deg, #b8f0c8, #d5f7de)', shadow: 'rgba(160, 220, 180, 0.3)' } },
  community: { label: "Community", icon: Users, color: { bg: 'linear-gradient(145deg, #ffb8d9, #ffd5e8)', shadow: 'rgba(240, 170, 200, 0.3)' } },
  tips: { label: "Pro Tips", icon: Zap, color: { bg: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)', shadow: 'rgba(150, 200, 240, 0.3)' } },
};

export default function Tutorials() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [selectedTutorial, setSelectedTutorial] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const { data: tutorials = [] } = useQuery({
    queryKey: ['tutorials'],
    queryFn: () => base44.entities.Tutorial.list('order'),
    initialData: [],
    retry: 1,
    staleTime: 60000,
  });

  const { data: progress = [] } = useQuery({
    queryKey: ['tutorialProgress', user?.email],
    queryFn: () => base44.entities.UserTutorialProgress.filter({ user_email: user?.email }),
    enabled: !!user?.email && !isLoadingUser,
    initialData: [],
    retry: 1,
    staleTime: 30000,
  });

  const { data: userProgress } = useQuery({
    queryKey: ['userProgress', user?.email],
    queryFn: async () => {
      if (!user?.email) return null;
      const existingProgress = await base44.entities.UserProgress.filter({ user_email: user.email });
      return existingProgress[0] || null;
    },
    enabled: !!user?.email && !isLoadingUser,
    retry: 1,
    staleTime: 30000,
  });

  const startTutorialMutation = useMutation({
    mutationFn: async (tutorial) => {
      if (!user?.email) throw new Error("User not logged in");
      const existing = progress.find(p => p.tutorial_id === tutorial.id);
      if (existing) {
        return existing;
      }
      return await base44.entities.UserTutorialProgress.create({
        user_email: user.email,
        tutorial_id: tutorial.id,
        current_step: 0,
        is_completed: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutorialProgress'] });
    },
    retry: 1,
  });

  const completeTutorialMutation = useMutation({
    mutationFn: async ({ tutorialId, progressId }) => {
      await base44.entities.UserTutorialProgress.update(progressId, {
        is_completed: true,
        completed_at: new Date().toISOString()
      });

      const tutorial = tutorials.find(t => t.id === tutorialId);
      if (tutorial?.completion_reward_xp && userProgress) {
        const newXp = (userProgress.xp || 0) + tutorial.completion_reward_xp;
        const newLevel = Math.floor(newXp / 200) + 1;
        await base44.entities.UserProgress.update(userProgress.id, {
          xp: newXp,
          level: newLevel
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutorialProgress'] });
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
    },
    retry: 1,
  });

  const updateStepMutation = useMutation({
    mutationFn: ({ progressId, step }) => 
      base44.entities.UserTutorialProgress.update(progressId, { current_step: step }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutorialProgress'] });
    },
    retry: 1,
  });

  const handleStartTutorial = async (tutorial) => {
    if (!user) {
      alert("Please log in to start tutorials");
      return;
    }
    
    const tutorialProgress = progress.find(p => p.tutorial_id === tutorial.id);
    if (tutorialProgress) {
      setCurrentStep(tutorialProgress.current_step || 0);
    } else {
      await startTutorialMutation.mutateAsync(tutorial);
      setCurrentStep(0);
    }
    setSelectedTutorial(tutorial);
  };

  const handleNextStep = async () => {
    const tutorialProgress = progress.find(p => p.tutorial_id === selectedTutorial.id);
    const nextStep = currentStep + 1;
    
    if (nextStep >= selectedTutorial.steps.length) {
      await completeTutorialMutation.mutateAsync({
        tutorialId: selectedTutorial.id,
        progressId: tutorialProgress.id
      });
      alert(`🎉 Tutorial Complete! You earned ${selectedTutorial.completion_reward_xp} XP!`);
      setSelectedTutorial(null);
      setCurrentStep(0);
    } else {
      setCurrentStep(nextStep);
      if (tutorialProgress) {
        await updateStepMutation.mutateAsync({
          progressId: tutorialProgress.id,
          step: nextStep
        });
      }
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const getTutorialProgress = (tutorialId) => {
    return progress.find(p => p.tutorial_id === tutorialId);
  };

  const filteredTutorials = tutorials.filter(t => 
    selectedCategory === "all" || t.category === selectedCategory
  );

  const completedCount = progress.filter(p => p.is_completed).length;
  const totalXpEarned = tutorials.reduce((sum, t) => {
    const isCompleted = progress.find(p => p.tutorial_id === t.id && p.is_completed);
    return sum + (isCompleted ? t.completion_reward_xp : 0);
  }, 0);

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '72rem' }}>
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-[20px] flex items-center justify-center" style={{
              background: 'linear-gradient(145deg, #a8d8ff, #c9e7ff)',
              boxShadow: '8px 8px 16px rgba(150, 200, 240, 0.3), -8px -8px 16px rgba(255, 255, 255, 0.9)'
            }}>
              <BookOpen className="w-7 h-7 text-blue-600" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-purple-800">Tutorials & Guides</h1>
              <p className="text-purple-600">Interactive guides to master AgentCraft</p>
            </div>
          </div>

          {/* Progress Stats */}
          <Card className="p-6 mb-6">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-800">{completedCount}</div>
                <div className="text-sm text-purple-600">Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-800">{tutorials.length - completedCount}</div>
                <div className="text-sm text-purple-600">Remaining</div>
              </div>
              <div className="text-center col-span-2 md:col-span-1">
                <div className="text-3xl font-bold text-purple-800">{totalXpEarned} XP</div>
                <div className="text-sm text-purple-600">Earned from Tutorials</div>
              </div>
            </div>
          </Card>

          {/* Category Filter */}
          <div className="flex gap-3 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                selectedCategory === "all" ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              All Tutorials
            </button>
            {Object.entries(CATEGORY_INFO).map(([key, info]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(key)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap flex items-center gap-2 transition-all ${
                  selectedCategory === key ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'
                }`}
              >
                <info.icon className="w-4 h-4" />
                {info.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Tutorials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTutorials.map((tutorial, index) => {
            const tutorialProgress = getTutorialProgress(tutorial.id);
            const isCompleted = tutorialProgress?.is_completed;
            const categoryInfo = CATEGORY_INFO[tutorial.category];

            return (
              <motion.div
                key={tutorial.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="ui-card p-6 cursor-pointer hover:shadow-lg transition-all"
                onClick={() => handleStartTutorial(tutorial)}
                >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-14 h-14 rounded-[16px] flex items-center justify-center" style={{
                    background: categoryInfo.color.bg,
                    boxShadow: `6px 6px 12px ${categoryInfo.color.shadow}, -6px -6px 12px rgba(255, 255, 255, 0.8)`
                  }}>
                    <categoryInfo.icon className="w-7 h-7 text-purple-600" />
                  </div>
                  {isCompleted && (
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{
                      background: 'linear-gradient(145deg, #b8f0c8, #d5f7de)',
                      boxShadow: '3px 3px 6px rgba(160, 220, 180, 0.3)'
                    }}>
                      <CheckCircle className="w-5 h-5 text-green-700" />
                    </div>
                  )}
                </div>

                <h3 className="text-lg font-bold text-purple-800 mb-2">{tutorial.title}</h3>
                <p className="text-purple-600 text-sm mb-4 line-clamp-2">{tutorial.description}</p>

                <div className="flex items-center justify-between text-xs text-purple-600 mb-3">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{tutorial.estimated_time} min</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Zap className="w-4 h-4 text-amber-500" />
                    <span>+{tutorial.completion_reward_xp} XP</span>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                    tutorial.difficulty === 'beginner' ? 'bg-green-100 text-green-700' :
                    tutorial.difficulty === 'intermediate' ? 'bg-amber-100 text-amber-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {tutorial.difficulty}
                  </div>
                </div>

                {tutorialProgress && !isCompleted && (
                  <div>
                    <div className="flex justify-between text-xs text-purple-600 mb-1">
                      <span>Progress</span>
                      <span>{tutorialProgress.current_step + 1} / {tutorial.steps.length}</span>
                    </div>
                    <Progress 
                      value={((tutorialProgress.current_step + 1) / tutorial.steps.length) * 100}
                      className="h-2"
                    />
                  </div>
                )}

                {!tutorialProgress && (
                  <Button
                    className="w-full rounded-[14px] font-semibold text-white border-none mt-2"
                    style={{
                      background: 'linear-gradient(145deg, #3b82f6, #2563eb)',
                      boxShadow: '4px 4px 8px rgba(59, 130, 246, 0.3)'
                    }}
                  >
                    Start Tutorial
                  </Button>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Tutorial Modal */}
        <AnimatePresence>
          {selectedTutorial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50"
              onClick={() => setSelectedTutorial(null)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="ui-card max-w-3xl w-full max-h-[85vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="p-6 md:p-8">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h2 className="text-2xl md:text-3xl font-bold text-purple-800 mb-2">
                        {selectedTutorial.title}
                      </h2>
                      <p className="text-purple-600">{selectedTutorial.description}</p>
                    </div>
                    <Button
                      onClick={() => setSelectedTutorial(null)}
                      variant="ghost"
                      size="icon"
                    >
                      <X className="w-5 h-5 text-purple-700" />
                    </Button>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-6">
                    <div className="flex justify-between text-sm text-purple-600 mb-2">
                      <span>Step {currentStep + 1} of {selectedTutorial.steps.length}</span>
                      <span>{Math.round(((currentStep + 1) / selectedTutorial.steps.length) * 100)}%</span>
                    </div>
                    <Progress 
                      value={((currentStep + 1) / selectedTutorial.steps.length) * 100}
                      className="h-3"
                    />
                  </div>

                  {/* Current Step Content */}
                  {selectedTutorial.steps[currentStep] && (
                    <div className="mb-8">
                      <div className="p-6 rounded-[20px] mb-6" style={{
                        background: 'linear-gradient(145deg, #f5f3ff, #e8e6f7)',
                        boxShadow: 'inset 4px 4px 8px rgba(209, 196, 233, 0.2), inset -2px -2px 6px rgba(255, 255, 255, 0.7)'
                      }}>
                        <h3 className="text-xl font-bold text-purple-800 mb-4">
                          {selectedTutorial.steps[currentStep].title}
                        </h3>
                        <div className="text-purple-700 whitespace-pre-wrap">
                          {selectedTutorial.steps[currentStep].content}
                        </div>
                      </div>

                      {selectedTutorial.steps[currentStep].action_required && (
                        <div className="p-4 rounded-[16px] flex items-start gap-3" style={{
                          background: 'linear-gradient(145deg, #ffd9a8, #ffe8c9)',
                          boxShadow: '4px 4px 8px rgba(240, 200, 150, 0.3)'
                        }}>
                          <Sparkles className="w-5 h-5 text-orange-600 flex-shrink-0 mt-1" />
                          <div>
                            <div className="font-bold text-orange-800 mb-1">Action Required</div>
                            <div className="text-orange-700 text-sm">
                              {selectedTutorial.steps[currentStep].action_description}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Navigation Buttons */}
                  <div className="flex gap-3">
                    <Button
                      onClick={handlePrevStep}
                      disabled={currentStep === 0}
                      variant="outline"
                      className="flex-1 px-6 py-3 text-purple-700 font-semibold disabled:opacity-50"
                    >
                      <ArrowLeft className="w-5 h-5 mr-2" />
                      Previous
                    </Button>
                    <Button
                      onClick={handleNextStep}
                      className="flex-1 px-6 py-3 rounded-[18px] font-semibold text-white border-none"
                      style={{
                        background: 'linear-gradient(145deg, #3b82f6, #2563eb)',
                        boxShadow: '6px 6px 12px rgba(59, 130, 246, 0.4)'
                      }}
                    >
                      {currentStep === selectedTutorial.steps.length - 1 ? (
                        <>
                          Complete <CheckCircle className="w-5 h-5 ml-2" />
                        </>
                      ) : (
                        <>
                          Next <ArrowRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}