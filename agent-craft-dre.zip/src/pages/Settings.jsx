import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { User, Shield, Bell, CreditCard, Loader2, LogOut } from "lucide-react";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/Card";
import AdminSimulationControls from "../components/AdminSimulationControls";
import { usePlanAccess } from "../components/PlanAccessProvider";
import HelpTooltip from "@/components/ui/HelpTooltip";
import ExplanationCard from "@/components/ui/ExplanationCard";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const [fullName, setFullName] = useState("");
  const [profileVisible, setProfileVisible] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  const [payoutEmail, setPayoutEmail] = useState("");
  const [bankAccountHolder, setBankAccountHolder] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [routingNumber, setRoutingNumber] = useState("");
  const queryClient = useQueryClient();
  
  const { tier, isAdmin, isSimulating } = usePlanAccess();

  useEffect(() => {
    base44.auth.me()
      .then((userData) => {
        setUser(userData);
        setFullName(userData.full_name || "");
        setProfileVisible(userData.profile_visible !== false);
        setEmailNotifications(userData.email_notifications !== false);
        setMarketingEmails(userData.marketing_emails === true);
        setPayoutEmail(userData.payout_email || "");
        setBankAccountHolder(userData.bank_account_holder || "");
        setBankName(userData.bank_name || "");
        setAccountNumber(userData.account_number || "");
        setRoutingNumber(userData.routing_number || "");
      })
      .catch(() => setUser(null))
      .finally(() => setIsLoadingUser(false));
  }, []);

  const updateSettingsMutation = useMutation({
    mutationFn: (settings) => base44.auth.updateMe(settings),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      alert("Settings saved successfully!");
    },
  });

  const handleSave = async () => {
    await updateSettingsMutation.mutateAsync({
      full_name: fullName,
      profile_visible: profileVisible,
      email_notifications: emailNotifications,
      marketing_emails: marketingEmails,
      payout_email: payoutEmail,
      bank_account_holder: bankAccountHolder,
      bank_name: bankName,
      account_number: accountNumber,
      routing_number: routingNumber
    });
  };

  const handleLogout = () => {
    base44.auth.logout(createPageUrl("Landing"));
  };

  if (isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="bg-app min-h-screen">
      <div className="container-app" style={{ maxWidth: '56rem' }}>
        {/* Admin Simulation Controls */}
        {(isAdmin || isSimulating) && <AdminSimulationControls />}

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Settings</h1>
          <p className="text-gray-600">Manage your account preferences</p>
        </motion.div>

        <div className="space-y-6">
          {/* Profile Information */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <User className="w-5 h-5 text-gray-700" />
              <h2 className="text-xl font-bold">Profile Information</h2>
            </div>
            <div className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  value={user?.email || ""}
                  disabled
                  className="mt-2 bg-gray-50"
                />
                <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
              </div>
              <div>
                <Label>Current Plan</Label>
                <div className="mt-2 px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 font-semibold">
                  {tier.charAt(0).toUpperCase() + tier.slice(1)}
                </div>
              </div>
            </div>
          </Card>

          {/* Privacy & Visibility */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-5 h-5 text-gray-700" />
              <h2 className="text-xl font-bold flex items-center gap-2">
                Privacy & Visibility
                <HelpTooltip>
                  Control who can see your profile and AI Helpers in the marketplace
                </HelpTooltip>
              </h2>
            </div>
            <ExplanationCard icon={Shield} title="Why we ask this">
              If you want to share or sell your AI Helpers in the marketplace, enable Public Profile. Otherwise, keep it private and only you can see your helpers.
            </ExplanationCard>
            <div className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">Public Profile</div>
                  <div className="text-sm text-gray-600">
                    Allow others to see your profile and agents
                  </div>
                </div>
                <Switch
                  checked={profileVisible}
                  onCheckedChange={setProfileVisible}
                />
              </div>
            </div>
          </Card>

          {/* Notifications */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-gray-700" />
              <h2 className="text-xl font-bold flex items-center gap-2">
                Notifications
                <HelpTooltip>
                  Choose what emails you want to receive from us
                </HelpTooltip>
              </h2>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">Email Notifications</div>
                  <div className="text-sm text-gray-600">
                    Receive updates about your account
                  </div>
                </div>
                <Switch
                  checked={emailNotifications}
                  onCheckedChange={setEmailNotifications}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">Marketing Emails</div>
                  <div className="text-sm text-gray-600">
                    Receive tips and feature updates
                  </div>
                </div>
                <Switch
                  checked={marketingEmails}
                  onCheckedChange={setMarketingEmails}
                />
              </div>
            </div>
          </Card>

          {/* Payout Information (for creators) */}
          {(tier === "pro" || tier === "business") && (
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <CreditCard className="w-5 h-5 text-gray-700" />
                <h2 className="text-xl font-bold flex items-center gap-2">
                  Payout Information
                  <HelpTooltip>
                    Where we send your earnings from selling AI Helpers
                  </HelpTooltip>
                </h2>
              </div>
              <ExplanationCard icon={CreditCard} title="Why we need this">
                When people buy your AI Helpers from the marketplace, we send your earnings (85% of the sale) to your PayPal account or bank account. Add your payment details so we know where to send your money!
              </ExplanationCard>
              <div className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="payoutEmail">PayPal Email</Label>
                  <Input
                    id="payoutEmail"
                    type="email"
                    placeholder="your-paypal@example.com"
                    value={payoutEmail}
                    onChange={(e) => setPayoutEmail(e.target.value)}
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Used for receiving marketplace earnings via PayPal
                  </p>
                </div>

                <div className="border-t border-gray-200 pt-4 mt-6">
                  <h3 className="font-semibold mb-4">Bank Account Information</h3>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="bankAccountHolder">Account Holder Name</Label>
                      <Input
                        id="bankAccountHolder"
                        placeholder="John Doe"
                        value={bankAccountHolder}
                        onChange={(e) => setBankAccountHolder(e.target.value)}
                        className="mt-2"
                      />
                    </div>
                    <div>
                      <Label htmlFor="bankName">Bank Name</Label>
                      <Input
                        id="bankName"
                        placeholder="Chase Bank"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        className="mt-2"
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="accountNumber">Account Number</Label>
                        <Input
                          id="accountNumber"
                          type="password"
                          placeholder="••••••••"
                          value={accountNumber}
                          onChange={(e) => setAccountNumber(e.target.value)}
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="routingNumber">Routing Number</Label>
                        <Input
                          id="routingNumber"
                          placeholder="123456789"
                          value={routingNumber}
                          onChange={(e) => setRoutingNumber(e.target.value)}
                          className="mt-2"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">
                      Your bank information is encrypted and secure
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button
              onClick={handleSave}
              disabled={updateSettingsMutation.isLoading}
              className="bg-gray-900 hover:bg-gray-800 text-white"
            >
              {updateSettingsMutation.isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="text-red-600 border-red-200 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}