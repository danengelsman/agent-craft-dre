import { PageShell } from "@/components/ui/PageShell";
import { Card, CardContent } from "@/components/ui/Card";
import { Calendar, User, Tag, ArrowLeft, Clock, Share2 } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Mark this page as public (no authentication required)
export const PUBLIC_PAGE = true;

const calculateReadingTime = (content) => {
  const wordsPerMinute = 200;
  const wordCount = content.split(/\s+/).length;
  const minutes = Math.ceil(wordCount / wordsPerMinute);
  return minutes;
};

const AUTHOR_BIO = "Creator advocate and AI builder passionate about community-driven innovation. Love helping beginners unlock AI's power and learning from the AgentCraft community.";

const BLOG_POSTS = [
  {
    id: 1,
    title: "Welcome to AgentCraft: The Future of AI Agent Creation",
    excerpt: "Discover how AgentCraft is revolutionizing the way creators build intelligent AI agents. Learn about our mission to make AI accessible to everyone, from complete beginners to advanced users.",
    content: `Welcome to AgentCraft, where we're democratizing AI agent creation for creators worldwide. Our platform combines powerful AI capabilities with an intuitive interface, making it easier than ever to build, deploy, and monetize intelligent agents.

## The Challenge

For too long, AI has been locked behind technical barriers. Building intelligent agents required deep knowledge of machine learning, natural language processing, and complex coding. This left countless creators with brilliant ideas unable to bring their visions to life.

## Our Solution

AgentCraft changes everything. Our guided builder walks you through every step of agent creation, from defining personality to configuring capabilities. No coding required. No technical jargon. Just simple, powerful tools that let you focus on what matters: creating agents that solve real problems.

## What Makes AgentCraft Different

- **Beginner-Friendly**: Start creating in minutes, not months
- **Evolution System**: Agents learn and improve over time
- **Marketplace**: Monetize your creations and discover others
- **Community-Driven**: Learn from thousands of creators worldwide

## Join the Movement

Whether you're a content creator, business owner, or just curious about AI, AgentCraft is your gateway to the future. Start building today and join the community that's redefining what's possible with AI agents.`,
    date: "2024-12-15",
    author: "Daniel Engelsman",
    category: "Announcements",
    tags: ["Getting Started", "Platform"],
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 2,
    title: "Building Your First Agent: A Complete Guide",
    excerpt: "From zero to deployed in minutes. Follow our comprehensive guide to creating your first AI agent with AgentCraft's intuitive builder.",
    content: `Creating your first AI agent doesn't have to be complicated. With AgentCraft's guided builder, you'll go from idea to deployed agent in just a few simple steps. Choose your agent's personality, define its capabilities, and watch it come to life.

## Step 1: Choose Your Intent

The first step is understanding what you want your agent to do. Are you building a customer service agent? A content creator? A data analyst? Our intent selector helps you define your agent's primary purpose.

## Step 2: Define Personality

Personality is what makes your agent unique. Choose from our presets or customize every detail:

- **Tone**: Professional, friendly, or somewhere in between
- **Verbosity**: Concise responses or detailed explanations
- **Style**: Formal, casual, or technical

## Step 3: Add Capabilities

Give your agent superpowers by selecting from our library of abilities:

- Knowledge Base Integration
- Web Search
- Email Sending
- Calendar Management
- And many more...

## Step 4: Test and Deploy

Before going live, use our interactive preview to test your agent. Have conversations, adjust settings, and ensure everything works perfectly. When you're ready, deploy with a single click.

## Tips for Success

1. Start simple - add complexity gradually
2. Test thoroughly before deploying
3. Use the community forums for inspiration
4. Monitor performance and iterate

Your first agent is just the beginning. As you gain confidence, explore advanced features like evolution, collaboration, and monetization.`,
    date: "2024-12-10",
    author: "Daniel Engelsman",
    category: "Tutorials",
    tags: ["Getting Started", "Agent Builder", "Beginner"],
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 3,
    title: "Agent Best Practices: Optimize Your AI Workflow",
    excerpt: "Master the art of agent creation with proven strategies for personality design, prompt engineering, and workflow optimization.",
    content: `Get the most out of your AI agents with these expert tips. Learn how to craft effective personalities, structure conversations, and leverage advanced features like evolution and collaboration.

## Personality Design

The foundation of a great agent is its personality. Here's how to nail it:

### Be Specific
Generic personalities lead to generic results. Instead of "friendly," try "warm and encouraging, like a supportive mentor."

### Match Your Audience
Enterprise clients need professional agents. Creative communities prefer conversational ones. Know your users.

### Test Extensively
What sounds good on paper might not work in practice. Test your personality with real users and iterate.

## Prompt Engineering

Your agent's instructions are crucial. Follow these guidelines:

1. **Be Clear**: Ambiguous instructions lead to unpredictable results
2. **Provide Examples**: Show your agent what good looks like
3. **Set Boundaries**: Define what your agent should NOT do
4. **Iterate**: Refine based on actual performance

## Performance Optimization

### Monitor Metrics
Track response times, success rates, and user satisfaction. Use this data to guide improvements.

### Use Evolution Wisely
Let your agent learn from successful interactions, but review changes before applying them.

### Leverage Collaboration
Complex tasks often need multiple specialized agents working together. Don't try to build one agent that does everything.

## Common Pitfalls

- Over-engineering: Start simple, add complexity only when needed
- Ignoring feedback: Users tell you what's working and what isn't
- Static agents: Let your agents evolve and improve over time

Remember: great agents are built iteratively. Start with a solid foundation and improve continuously based on real-world performance.`,
    date: "2024-12-05",
    author: "Daniel Engelsman",
    category: "Best Practices",
    tags: ["Advanced", "Optimization", "Tips"],
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 4,
    title: "Understanding Agent Evolution: How Your AI Gets Smarter",
    excerpt: "Explore the cutting-edge evolution system that allows your agents to learn, adapt, and improve over time based on real interactions.",
    content: `AgentCraft's evolution system is a game-changer. Your agents can automatically improve their performance through genetic algorithms, learning from successful interactions and adapting their behavior to better serve your needs.

## How Evolution Works

Think of agent evolution like natural selection for AI. Successful traits are preserved and enhanced, while ineffective ones are phased out. Here's the process:

### 1. Performance Tracking
Every interaction is monitored for key metrics:
- Response quality
- User satisfaction
- Task completion rate
- Response time

### 2. Pattern Recognition
The system identifies what makes certain interactions successful. Is it the tone? The level of detail? The structure of responses?

### 3. Genetic Mutations
Promising traits are isolated and enhanced. Multiple variations are tested to find optimal combinations.

### 4. Selective Application
Only improvements that show measurable gains are applied to your agent. Regressions are automatically rolled back.

## Evolution Strategies

### Personality Refinement
Your agent's tone and style adapt to user preferences over time.

### Prompt Tuning
Instructions are optimized for clarity and effectiveness.

### Ability Optimization
Capability usage patterns inform which features to enhance or remove.

## Configuration Options

Control how your agents evolve:

- **Auto-Evolution**: Let changes apply automatically
- **Manual Review**: Approve each evolution before it goes live
- **Evolution Frequency**: Daily, weekly, or threshold-based
- **Performance Targets**: Set specific goals for improvement

## Best Practices

1. Start with manual review to understand the process
2. Set realistic performance thresholds
3. Monitor evolution outcomes closely
4. Use the gene pool to share successful traits across agents

Evolution transforms good agents into great ones. Enable it today and watch your AI grow smarter with every interaction.`,
    date: "2024-11-28",
    author: "Daniel Engelsman",
    category: "Features",
    tags: ["Evolution", "Advanced", "AI"],
    image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 5,
    title: "Monetize Your Agents: Creator Economy Guide",
    excerpt: "Turn your AI expertise into revenue. Learn how to package, price, and sell your agents in the AgentCraft marketplace.",
    content: `The creator economy is here, and AgentCraft puts you at the center. Discover strategies for creating valuable agents, pricing them effectively, and building a sustainable business around your AI creations.

## The Marketplace Opportunity

Thousands of users need agents but lack the time or expertise to build them. That's where you come in. By creating and selling high-quality agents, you can:

- Generate passive income
- Build your reputation as an AI expert
- Help others solve real problems
- Grow a community around your creations

## Creating Valuable Agents

### Identify Pain Points
The best-selling agents solve specific, common problems. Research what users need:

- Customer service automation
- Content creation assistants
- Data analysis tools
- Scheduling coordinators

### Build with Quality
Marketplace success requires:
- Clear documentation
- Thorough testing
- Professional presentation
- Responsive support

### Add Unique Value
Stand out by offering something competitors don't:
- Specialized industry knowledge
- Unique personality traits
- Custom integrations
- Superior performance

## Pricing Strategy

### Free Tier
Offer a basic version to build trust and gather feedback.

### Premium Features
Charge for:
- Advanced capabilities
- Priority support
- Custom configurations
- Commercial licenses

### Market Research
Study competitors' pricing and adjust based on:
- Your agent's capabilities
- Your target audience
- The value provided
- Market demand

## Marketing Your Agents

### Compelling Descriptions
Write clear, benefit-focused copy that shows exactly what your agent does.

### Video Demonstrations
Show your agent in action. Nothing sells better than seeing it work.

### User Testimonials
Social proof is powerful. Collect and showcase positive reviews.

### Community Engagement
Be active in forums, answer questions, and provide value beyond just selling.

## Building a Business

Start small, deliver quality, and reinvest earnings into creating more agents. Many successful creators now earn full-time income from AgentCraft. Your journey starts today.`,
    date: "2024-11-20",
    author: "Daniel Engelsman",
    category: "Monetization",
    tags: ["Marketplace", "Revenue", "Business"],
    image: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 6,
    title: "Agent Collaboration: Building Multi-Agent Workflows",
    excerpt: "Unlock new possibilities by having multiple agents work together. Learn how to orchestrate complex workflows with agent collaboration.",
    content: `Single agents are powerful, but agent collaboration takes things to the next level. Design workflows where multiple specialized agents work together, each contributing their unique capabilities to solve complex problems.

## Why Collaborate?

Complex tasks often require multiple specialized skills. Rather than building one massive agent that does everything (poorly), collaboration lets you:

- Create focused, expert agents
- Combine capabilities dynamically
- Scale workflows efficiently
- Maintain and update easily

## Collaboration Patterns

### Sequential Workflows
Agents work in sequence, each building on the previous agent's output.

**Example**: Content Creation Pipeline
1. Research Agent gathers information
2. Writing Agent creates draft
3. Editing Agent refines and polishes
4. Publishing Agent formats and schedules

### Parallel Processing
Multiple agents work simultaneously on different aspects.

**Example**: Market Analysis
- Agent 1: Analyzes competitor pricing
- Agent 2: Reviews customer sentiment
- Agent 3: Evaluates market trends
- Orchestrator: Synthesizes findings

### Conditional Routing
Different agents handle different scenarios based on context.

**Example**: Customer Support
- Classification Agent routes to:
  - Technical Support Agent
  - Billing Agent
  - Product Information Agent

## Building Collaborations

### 1. Define the Workflow
Map out the entire process. What needs to happen? In what order?

### 2. Identify Specializations
Break the workflow into distinct tasks. Each task gets its own agent.

### 3. Configure Handoffs
Determine how agents pass information and trigger each other.

### 4. Set Up Monitoring
Track each agent's performance and the overall workflow success.

## Best Practices

### Keep Agents Focused
Resist the urge to add "just one more feature." Specialized agents perform better.

### Design Clear Interfaces
Agents need to communicate effectively. Standardize data formats.

### Handle Failures Gracefully
What happens if an agent fails? Build in fallbacks and error handling.

### Test Thoroughly
Complex workflows need extensive testing. Verify edge cases.

## Advanced Techniques

### Shared Knowledge Base
Let agents learn from each other's interactions and share insights.

### Dynamic Orchestration
Adjust workflows in real-time based on context and performance.

### Feedback Loops
Use results to improve both individual agents and the collaboration itself.

Agent collaboration represents the future of AI workflows. Start experimenting today and discover what's possible when agents work together.`,
    date: "2024-11-15",
    author: "Daniel Engelsman",
    category: "Advanced",
    tags: ["Collaboration", "Workflows", "Advanced"],
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&h=400&fit=crop&q=80",
  },
  {
    id: 7,
    title: "What is AgentCraft? A Beginner's Guide to AI Assistants",
    excerpt: "Never used AI before? No problem. Learn what AgentCraft is, how it works, and why it's the easiest way for anyone to create smart AI helpers.",
    content: `If you've heard about ChatGPT but aren't quite sure what it does or how to use AI, you're in the right place. AgentCraft makes creating your own AI assistant simple enough for anyone to do—no technical knowledge required.

## What is ChatGPT (The Simple Version)

Think of ChatGPT like having a really smart friend who can write, answer questions, and help you with tasks. You type something, and it types back helpful responses. That's it! It's like texting someone who knows a lot about many topics.

## So What is AgentCraft?

AgentCraft lets you create your own personal version of that smart friend—called an "agent"—and customize it exactly how you want. Instead of just chatting with ChatGPT, you can:

- Build an AI helper that knows YOUR business
- Create assistants that match YOUR personality
- Make helpers that do specific tasks the way YOU want them done

## Why Would I Want This?

Imagine having a personal assistant who:

- Answers customer questions for your business (while you sleep!)
- Writes social media posts in your unique style
- Helps you organize your schedule and reminds you of important stuff
- Creates content for your blog or newsletter
- And learns to do things better over time

That's what an AgentCraft agent does. It's like having a team member who never gets tired, works 24/7, and costs way less than hiring someone.

## How Does It Work? (The Easy Explanation)

### Step 1: Tell Us What You Need
Just answer simple questions like "What should your agent help with?" No coding. No complicated setup. Just normal conversation.

### Step 2: Give It a Personality
Want it to sound professional? Friendly? Casual? You decide. Make it match your style.

### Step 3: Pick Its Skills
Choose what your agent can do—send emails, create content, answer questions, schedule things. It's like picking toppings on a pizza.

### Step 4: Test & Launch
Chat with your agent to see if it works the way you want. Adjust anything that's not perfect. Then let it loose!

## Real Examples (What People Actually Use It For)

### Sarah's Customer Service Agent
Sarah runs a small online shop. Her agent answers common customer questions about shipping, returns, and product details—even at 2 AM when she's sleeping.

### Mike's Content Creator
Mike's a fitness coach who needs to post daily tips. His agent writes motivational posts in his voice, so he doesn't have to spend hours every day writing.

### Jessica's Scheduling Assistant
Jessica manages multiple clients. Her agent handles booking calls, sends reminders, and even reschedules when conflicts happen.

## What Makes AgentCraft Different?

Unlike just using ChatGPT directly, AgentCraft agents:

- **Remember Your Preferences**: They learn how you like things done
- **Work Automatically**: Set them up once, and they keep working
- **Handle Specific Tasks**: Built for your exact needs, not generic responses
- **Get Smarter**: They improve based on what works and what doesn't
- **Stay Consistent**: Always respond the same way you want

## Do I Need to Know Anything About Technology?

Nope! If you can:
- Answer questions
- Type in a text box
- Click buttons

You can build an agent. Seriously, that's all you need to know.

## What Can't Agents Do?

Let's be realistic. Agents are smart, but they:

- Can't replace human creativity and emotion entirely
- Need clear instructions to work well
- Work best for repetitive or structured tasks
- Can't physically do things (they're digital helpers)

Think of them as super-capable assistants, not magic.

## How Much Does It Cost?

We have a free plan to get started! You can create your first agents and see if you like it without spending a penny. As you need more features or want to build multiple agents, there are affordable paid plans.

## Getting Started is Easy

1. Sign up (takes 2 minutes)
2. Answer a few questions about what you need
3. Watch your agent come to life
4. Start using it right away

That's it. No training required. No manual to read. Just simple, guided setup.

## What's Next?

Ready to build your first AI assistant? Here's what to do:

1. Click "Start Building" on our homepage
2. Follow the step-by-step builder (it's like a friendly quiz)
3. Test your agent
4. Launch it and watch it work

Still confused about something? That's okay! We have:
- Video tutorials showing exactly how everything works
- A friendly community of other beginners
- Support team ready to help
- Templates you can copy and customize

## The Bottom Line

AgentCraft helps you create smart AI helpers that do tasks for you—no tech skills needed. If you can describe what you want, we can help you build it. And the best part? Your agents get smarter and better at their jobs over time.

Think of it as having a personal team of AI assistants, customized just for you, working around the clock to make your life easier.

Ready to meet your first agent?`,
    date: "2024-12-21",
    author: "Daniel Engelsman",
    category: "Getting Started",
    tags: ["Beginner", "Introduction", "AI Basics"],
    image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?w=800&h=400&fit=crop&q=80",
  },
];

export default function BlogPost() {
  const [searchParams] = useSearchParams();
  const postId = parseInt(searchParams.get("id"));
  const post = BLOG_POSTS.find(p => p.id === postId);
  const canShare = typeof navigator !== 'undefined' && navigator.share;

  if (!post) {
    return (
      <PageShell title="Post Not Found">
        <div className="text-center py-12">
          <p className="text-gray-600 mb-4">The blog post you're looking for doesn't exist.</p>
          <Link to={createPageUrl("Blog")} className="text-blue-600 hover:underline">
            ← Back to Blog
          </Link>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="max-w-4xl mx-auto">
        {/* Back Button */}
        <Link 
          to={createPageUrl("Blog")} 
          className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Blog
        </Link>

        {/* Hero Image */}
        <img 
          src={post.image} 
          alt={post.title}
          className="w-full h-96 object-cover rounded-2xl mb-8"
        />

        {/* Post Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs font-semibold text-gray-900 bg-gray-100 px-3 py-1 rounded-full">
              {post.category}
            </span>
          </div>
          
          <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
          
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>{calculateReadingTime(post.content)} min read</span>
            </div>
            {canShare && (
              <button
                onClick={async () => {
                  try {
                    await navigator.share({
                      title: post.title,
                      text: post.excerpt,
                      url: window.location.href,
                    });
                  } catch (err) {
                    if (err.name !== 'AbortError') {
                      console.error('Error sharing:', err);
                    }
                  }
                }}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            )}
          </div>

          {post.tags && post.tags.length > 0 && (
            <div className="flex items-center gap-2 mt-4">
              <Tag className="w-4 h-4 text-gray-500" />
              <div className="flex gap-2 flex-wrap">
                {post.tags.map((tag, idx) => (
                  <span key={idx} className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Author Bio */}
        <Card className="mb-8 bg-gray-50">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68fe2cb8db081a9a5225599e/897086d49_IMG_0217.jpg"
                alt="Daniel Engelsman"
                className="w-16 h-16 rounded-full object-cover flex-shrink-0"
              />
              <div>
                <h3 className="font-semibold text-lg mb-1">{post.author}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{AUTHOR_BIO}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Post Content */}
        <Card>
          <CardContent className="p-8">
            <div className="prose prose-lg max-w-none">
              {post.content.split('\n\n').map((paragraph, idx) => {
                if (paragraph.startsWith('## ')) {
                  return <h2 key={idx} className="text-2xl font-bold mt-8 mb-4">{paragraph.replace('## ', '')}</h2>;
                } else if (paragraph.startsWith('### ')) {
                  return <h3 key={idx} className="text-xl font-semibold mt-6 mb-3">{paragraph.replace('### ', '')}</h3>;
                } else if (paragraph.startsWith('- ')) {
                  const items = paragraph.split('\n');
                  return (
                    <ul key={idx} className="list-disc list-inside space-y-2 my-4">
                      {items.map((item, i) => (
                        <li key={i}>{item.replace('- ', '')}</li>
                      ))}
                    </ul>
                  );
                } else if (/^\d+\. /.test(paragraph)) {
                  const items = paragraph.split('\n');
                  return (
                    <ol key={idx} className="list-decimal list-inside space-y-2 my-4">
                      {items.map((item, i) => (
                        <li key={i}>{item.replace(/^\d+\. /, '')}</li>
                      ))}
                    </ol>
                  );
                } else if (paragraph.trim()) {
                  return <p key={idx} className="mb-4 leading-relaxed text-gray-700">{paragraph}</p>;
                }
                return null;
              })}
            </div>
          </CardContent>
        </Card>

        {/* Back to Blog CTA */}
        <div className="mt-12 text-center">
          <Link 
            to={createPageUrl("Blog")} 
            className="inline-flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to all posts
          </Link>
        </div>
      </div>
    </PageShell>
  );
}