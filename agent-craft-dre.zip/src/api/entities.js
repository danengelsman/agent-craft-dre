import { base44 } from './base44Client';


export const Agent = base44.entities.Agent;

export const UserProgress = base44.entities.UserProgress;

export const Lesson = base44.entities.Lesson;

export const ForumPost = base44.entities.ForumPost;

export const ForumComment = base44.entities.ForumComment;

export const AgentReview = base44.entities.AgentReview;

export const AgentPurchase = base44.entities.AgentPurchase;

export const Tutorial = base44.entities.Tutorial;

export const UserTutorialProgress = base44.entities.UserTutorialProgress;

export const ContentModeration = base44.entities.ContentModeration;

export const VideoTutorial = base44.entities.VideoTutorial;

export const UserSubscription = base44.entities.UserSubscription;

export const OnboardingProgress = base44.entities.OnboardingProgress;

export const SecurityLog = base44.entities.SecurityLog;

export const SecurityAlert = base44.entities.SecurityAlert;

export const UserFeedback = base44.entities.UserFeedback;

export const PlanConfiguration = base44.entities.PlanConfiguration;

export const Contact = base44.entities.Contact;

export const Company = base44.entities.Company;

export const Deal = base44.entities.Deal;

export const HubSpotFieldMapping = base44.entities.HubSpotFieldMapping;

export const HubSpotSyncLog = base44.entities.HubSpotSyncLog;

export const TrainingDataset = base44.entities.TrainingDataset;

export const TrainingJob = base44.entities.TrainingJob;

export const AgentAuditReport = base44.entities.AgentAuditReport;

export const AgentSimulationResult = base44.entities.AgentSimulationResult;

export const ArchitectLearning = base44.entities.ArchitectLearning;

export const AgentCollaboration = base44.entities.AgentCollaboration;

export const AgentMessage = base44.entities.AgentMessage;

export const SharedKnowledge = base44.entities.SharedKnowledge;

export const ImprovementProposal = base44.entities.ImprovementProposal;

export const AgentAction = base44.entities.AgentAction;

export const ActionExecution = base44.entities.ActionExecution;

export const Workflow = base44.entities.Workflow;

export const WorkflowRun = base44.entities.WorkflowRun;

export const UsageTracking = base44.entities.UsageTracking;

export const BudgetLimit = base44.entities.BudgetLimit;

export const AgentTrace = base44.entities.AgentTrace;

export const ApiKey = base44.entities.ApiKey;

export const Webhook = base44.entities.Webhook;

export const AgentEvolution = base44.entities.AgentEvolution;

export const AgentGenePool = base44.entities.AgentGenePool;

export const EvolutionSettings = base44.entities.EvolutionSettings;



// auth sdk:
export const User = base44.auth;